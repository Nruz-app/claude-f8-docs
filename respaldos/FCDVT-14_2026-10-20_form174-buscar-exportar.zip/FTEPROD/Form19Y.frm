VERSION 5.00
Object = "{5E9E78A0-531B-11CF-91F6-C2863C385E30}#1.0#0"; "MSFLXGRD.OCX"
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomct2.ocx"
Begin VB.Form Form19Y 
   BackColor       =   &H00E6E8E8&
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   " Ingreso de Cierres de Terminal Y"
   ClientHeight    =   9330
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   12525
   Icon            =   "Form19Y.frx":0000
   LinkTopic       =   "Form19Y"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   9330
   ScaleWidth      =   12525
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      BackColor       =   &H00A4E8CB&
      Caption         =   "&Validar Identificaci�n"
      Height          =   375
      Left            =   7680
      Style           =   1  'Graphical
      TabIndex        =   1
      ToolTipText     =   "Valida Informaci�n de identificaci�n"
      Top             =   3000
      Width           =   2415
   End
   Begin MSComCtl2.DTPicker DTPicker1 
      Height          =   255
      Left            =   3495
      TabIndex        =   2
      Top             =   1275
      Width           =   2250
      _ExtentX        =   3969
      _ExtentY        =   450
      _Version        =   393216
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      CalendarBackColor=   16119285
      CalendarForeColor=   128
      CalendarTitleBackColor=   12632256
      CalendarTitleForeColor=   128
      CalendarTrailingForeColor=   8421504
      Format          =   143785985
      CurrentDate     =   37776
   End
   Begin MSFlexGridLib.MSFlexGrid Grid1 
      Height          =   4935
      Left            =   240
      TabIndex        =   3
      Top             =   3840
      Width           =   11685
      _ExtentX        =   20611
      _ExtentY        =   8705
      _Version        =   393216
      Cols            =   3
      FixedCols       =   0
      BackColor       =   16119285
      ForeColor       =   128
      BackColorFixed  =   10807499
      ForeColorFixed  =   3560496
      BackColorBkg    =   15132904
      ScrollBars      =   2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin MSFlexGridLib.MSFlexGrid Grid0 
      Height          =   2535
      Left            =   240
      TabIndex        =   0
      Top             =   930
      Width           =   5685
      _ExtentX        =   10028
      _ExtentY        =   4471
      _Version        =   393216
      Cols            =   3
      FixedCols       =   0
      BackColor       =   16119285
      ForeColor       =   128
      BackColorFixed  =   10807499
      ForeColorFixed  =   3560496
      BackColorBkg    =   15132904
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.PictureBox Picture2 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   810
      Left            =   9580
      Picture         =   "Form19Y.frx":030A
      ScaleHeight     =   810
      ScaleWidth      =   2295
      TabIndex        =   8
      Top             =   -260
      Width           =   2295
   End
   Begin VB.CommandButton Command2 
      BackColor       =   &H00A4E8CB&
      Caption         =   "&Cancelar"
      Height          =   375
      Left            =   10560
      Style           =   1  'Graphical
      TabIndex        =   5
      ToolTipText     =   "Salir"
      Top             =   8880
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00A4E8CB&
      Caption         =   "&Aceptar"
      Enabled         =   0   'False
      Height          =   375
      Left            =   9120
      Style           =   1  'Graphical
      TabIndex        =   4
      ToolTipText     =   "Grabar informaci�n"
      Top             =   8880
      Width           =   1335
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Caption         =   "DETALLE DE MONTOS"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000080&
      Height          =   255
      Left            =   240
      TabIndex        =   7
      Top             =   3600
      Width           =   2175
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "IDENTIFICACION"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000080&
      Height          =   255
      Left            =   240
      TabIndex        =   6
      Top             =   600
      Width           =   1455
   End
   Begin VB.Image Image3 
      Height          =   1500
      Left            =   9320
      Picture         =   "Form19Y.frx":194E
      Top             =   480
      Width           =   2745
   End
   Begin VB.Label Label12 
      BackColor       =   &H00C0C0C0&
      Height          =   1245
      Left            =   11700
      TabIndex        =   10
      Top             =   -60
      Width           =   1005
   End
   Begin VB.Label Label11 
      BackColor       =   &H00C0C0C0&
      Height          =   8475
      Left            =   12040
      TabIndex        =   9
      Top             =   1080
      Width           =   495
   End
   Begin VB.Image Image1 
      Height          =   810
      Left            =   2940
      Picture         =   "Form19Y.frx":1C3A
      Top             =   -230
      Width           =   13590
   End
   Begin VB.Image Image2 
      Height          =   1830
      Left            =   -180
      Picture         =   "Form19Y.frx":1D12
      Top             =   -1250
      Width           =   4665
   End
End
Attribute VB_Name = "Form19Y"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim VF_ExisteTerminaY As Boolean
Function arma_query_rec(tk) As String
Dim sumacobros As Double
On Error GoTo Error
sq3 = ""
sq3 = "insert into vta_" & Flg_Pais$ & "zzz "
sq3 = sq3 & "      (rec_techkey ,rec_fechaproceso"
For i = 2 To Grid1.Rows - 1
    If Grid1.TextMatrix(i, 3) <> "" Then
    '    MsgBox "Grabando"
        If Grid1.TextMatrix(i, 2) = 0 Or Grid1.TextMatrix(i, 2) = 3 Then
            If InStr(UCase(Grid1.TextMatrix(i, 3)), "VTA_") < 1 Then
              sq3 = sq3 & ",     " & LCase(Grid1.TextMatrix(i, 3)) & " "
            Else
               If InStr(UCase(Grid1.TextMatrix(i, 3)), "MVTA_") >= 1 Then
                    sq3 = sq3 & ",     " & LCase(Grid1.TextMatrix(i, 3)) & " "
               End If
            End If
        End If
    End If
Next i
If Flg_Pais$ = "ARG" Or Flg_Pais$ = "SOAR" Or Flg_Pais$ = "SOUY" Then
   sq3 = sq3 & ",  MTOTAL_COBROS_ABONO      "
   
End If
sq3 = sq3 & "      ) "
  
  sq3 = sq3 & " values ( " & tk & ", to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')  "
  For i = 2 To Grid1.Rows - 1
    If Grid1.TextMatrix(i, 3) <> "" Then
'            MsgBox "Grabando"
        If Grid1.TextMatrix(i, 2) = 0 Or Grid1.TextMatrix(i, 2) = 3 Then
            If InStr(UCase(Grid1.TextMatrix(i, 3)), "VTA_") < 1 Then
                   sq3 = sq3 & ",     " & Change_Char(CDbl(Grid1.TextMatrix(i, 1)), ",", ".") & " "
            Else
               If InStr(UCase(Grid1.TextMatrix(i, 3)), "MVTA_") >= 1 Then
                        sq3 = sq3 & ",     " & Change_Char(CDbl(Grid1.TextMatrix(i, 1)), ",", ".") & " "
               End If
            End If
            If Flg_Pais$ = "ARG" Or Flg_Pais$ = "SOAR" Or Flg_Pais$ = "SOUY" Then
                   Select Case Trim(Grid1.TextMatrix(i, 3))
                    ' se cambia "MTOTAL_CHEQUE_DIA" por "MTOTAL_CHEQUE_FAL" fecha 30-03-2010
                      Case "MTOTAL_PAG_EUR", "MTOTAL_PAG_DOL", "MTOTAL_CMR", "MTOTAL_CHEQUE_FAL", "MTOTAL_EFECTIVO"
                        sumacobros = sumacobros + CDbl(Grid1.TextMatrix(i, 1))
                   End Select
            End If
        End If
    End If
  Next i
    If Flg_Pais$ = "ARG" Or Flg_Pais$ = "SOAR" Or Flg_Pais$ = "SOUY" Then
     sq3 = sq3 & ",     " & Change_Char(CDbl(sumacobros), ",", ".") & " "
  End If
  sq3 = sq3 & " )"
  
arma_query_rec = sq3
Exit Function

Error:
    arma_query_rec = ""
    Exit Function
    
End Function

Private Function definegrid()
Dim f As Integer
Dim Vtiempo As String

   Grid0.Clear
   Grid0.Cols = 2
   Grid0.Rows = 10
   Grid0.RowHeight(0) = 300
   Grid0.ColWidth(0) = 3230
   Grid0.ColWidth(1) = 2350
   Grid0.ColAlignment(0) = 1
   Grid0.ColAlignment(1) = 1
   Grid0.FixedAlignment(0) = 4
   Grid0.FixedAlignment(1) = 4
   Grid0.TextMatrix(0, 0) = "Concepto"
   Grid0.TextMatrix(0, 1) = "Valor"
   

   
   
   
   Grid0.TextMatrix(1, 0) = "FECHA (ddmmaaaa)"
   Grid0.TextMatrix(2, 0) = "LOCAL"
   Grid0.TextMatrix(3, 0) = "TERMINAL"
   Grid0.TextMatrix(4, 0) = "N� DE CIERRE DE Y"
   Grid0.TextMatrix(5, 0) = "HORA"
   Grid0.TextMatrix(6, 0) = "SECUENCIA"
   Grid0.TextMatrix(7, 0) = "N� BOLETA        "
   Grid0.TextMatrix(8, 0) = "VENDEDOR"
   Grid0.TextMatrix(9, 0) = "CONT. REPOSICION "
   
   DTPicker1.Value = FormVariable.DTPicker1.Value
   Vtiempo = Format(Time, "Hh:mm:ss AMPM")
 '  Vtiempo = Format(Vtiempo, "Hh:mm:ss AMPM") '
   Grid0.TextMatrix(2, 1) = FormVariable.Combo2.Text
   Grid0.TextMatrix(3, 1) = FormVariable.Combo3.Text ' "TERMINAL"
   Grid0.TextMatrix(4, 1) = 0 '"N� DE CIERRE DE Y"
   Grid0.TextMatrix(5, 1) = Mid(Vtiempo, 1, 5)
   Grid0.TextMatrix(6, 1) = "" ' "SECUENCIA"
   Grid0.TextMatrix(7, 1) = "" '"N� BOLETA        "
   Grid0.TextMatrix(8, 1) = "" '"VENDEDOR"
   Grid0.TextMatrix(9, 1) = "" '"CONT. REPOSICION "
   
End Function
Sub definegrid1()
   Grid1.Clear
   Grid1.Cols = 7
   Grid1.Rows = 55
   Grid1.RowHeight(0) = 300
   Grid1.ColWidth(0) = 3230
   Grid1.ColWidth(1) = 2050
   Grid1.ColWidth(4) = 2000
   Grid1.ColWidth(5) = 2000
   Grid1.ColWidth(6) = 2020
   
   Grid1.ColAlignment(0) = 1
   Grid1.ColAlignment(1) = 7
   Grid1.ColAlignment(4) = 7
   Grid1.ColAlignment(5) = 7
   Grid1.ColAlignment(6) = 7
   Grid1.FixedAlignment(0) = 4
   Grid1.FixedAlignment(1) = 4
   Grid1.FixedAlignment(4) = 4
   Grid1.FixedAlignment(5) = 4
   Grid1.FixedAlignment(6) = 4
   Grid1.TextMatrix(0, 0) = "Concepto"
   Grid1.TextMatrix(0, 1) = "Monto"
   Grid1.ColWidth(2) = 0
   Grid1.ColWidth(3) = 0
   Grid1.TextMatrix(0, 4) = "Valor Z"
   Grid1.TextMatrix(0, 5) = "Sumatoria S(Y)"
   Grid1.TextMatrix(0, 6) = "Diferencia(Z - S(Y))"
   Grid0.row = 2
   Grid0.col = 1
   Grid1.Enabled = False
 
 
End Sub

Private Function Oklt() As Integer
   Oklt = 0
Set Consulta = CreateObject("ADODB.Recordset")
With Consulta
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With

   sq = "select count(*) " & _
        "From   vta_" & Flg_Pais$ & "terminales " & _
        "where  ter_local = " & Grid0.TextMatrix(2, 1) & " " & _
        " and   (ter_fechabaja >= to_date('" & Format(FormVariable.DTPicker1.Value, VgFormatoFechaWhere) & "','" & VgFormatoFechaWhere & "') or ter_fechabaja is null  )" & _
        " and    ter_terminal = " & Grid0.TextMatrix(3, 1) & " "
   
   On Error GoTo oraerror
   Call Consulta.Open(sq)
   Oklt = Consulta.Fields(0)
   Set Consulta.ActiveConnection = Nothing
   Exit Function
oraerror:
End Function
'xintec NR 11-03-2019
Private Function LeeVendedor() As Integer
   LeeVendedor = 0
Set Consulta = CreateObject("ADODB.Recordset")
With Consulta
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With

   sq = "select count(*) " & _
        "From   vta_" & Flg_Pais$ & "relvendedor " & _
        "where  vta_local = " & Grid0.TextMatrix(2, 1) & " " & _
        " and   (ter_fechabaja >= to_date('" & Format(FormVariable.DTPicker1.Value, VgFormatoFechaWhere) & "','" & VgFormatoFechaWhere & "') or ter_fechabaja is null  )" & _
        " and    ter_terminal = " & Grid0.TextMatrix(3, 1) & " "
   
   On Error GoTo oraerror
   Call Consulta.Open(sq)
   LeeVendedor = Consulta.Fields(0)
   Set Consulta.ActiveConnection = Nothing
   Exit Function
oraerror:
End Function


Private Function LeeZactual(boli, nrollo, repini)
   boli = 0
   nrollo = 0
   repini = 0
Set Consulta = CreateObject("ADODB.Recordset")
With Consulta
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With
   sq = "select decode(vta_bolinicial,null,0,vta_bolinicial)  " & _
        ",      decode(vta_nrollo,null,0,vta_nrollo) " & _
        ",      decode(vta_crepo_inicial,null,0,vta_crepo_inicial) " & _
        "From   vta_" & Flg_Pais$ & "libvta " & _
        "where  vta_tiporeg = 'Y' " & _
        "and    vta_fecha_venta = to_date('" & Format(DTPicker1.Value, VgFormatoFechaWhere) & "','" & VgFormatoFechaWhere & "') " & _
        "and    vta_local = " & Grid0.TextMatrix(2, 1) & " " & _
        "and    vta_terminal = " & Grid0.TextMatrix(3, 1) & " " & _
        "and    vta_secuencia =" & Grid0.TextMatrix(4, 1) & " "
   
   On Error GoTo oraerror
   Call Consulta.Open(sq)
   If Consulta.RecordCount <> 0 Then
      boli = Consulta.Fields(0).Value
      nrollo = Consulta.Fields(1).Value
      repini = Consulta.Fields(2).Value
   End If
   Set Consulta.ActiveConnection = Nothing
   Exit Function
oraerror:
End Function

Private Function GrabaZZZ()
Dim Glosay, estadoy, estadoz As String
Dim sq, sq1, sq2, sq3 As String
Dim tk As Double

   Call LeeZactual(boli, nrollo, repini)
   qbol = Grid0.TextMatrix(7, 1) - boli + 1
   tk = GrabarPrimeraZZZ(boli, nrollo, repini)
   If tk <> -1 Then
      If GrabarSegundaZZZ Then
          If GrabarTerceraZZZ(boli, nrollo, qbol, tk) Then
             If GrabarCuartoZZZ(tk) Then
                 If Not FuncExisteEst_TermStatY(DTPicker1.Value, Grid0.TextMatrix(2, 1), Grid0.TextMatrix(3, 1), Grid0.TextMatrix(4, 1)) Then
                    Glosay = "INGRESO MANUAL POR CIERRE DE Y"
                    estadoy = -1
                    'CK: 160531 Modificaciones F8 ARG
                    If Flg_Pais$ = "ARG" Then
                        estadoz = ObtenerEstadoZZZ
                        If estadoz = "-2" Then
                            estadoy = estadoz
                            Glosay = "Z MODIF. POR CUAD. DE VENTAS"
                        End If
                    End If
                    'Fin CK: 160531
                    If GrabarQuintoZZZ(Grid0.TextMatrix(2, 1), Grid0.TextMatrix(3, 1), DTPicker1.Value, Grid0.TextMatrix(4, 1), estadoy, Glosay, LOGINUSER) Then
'                       Command3.Enabled = False
'                       Command1.Enabled = False
'                       Call definegrid
                        Unload Me
                    End If
                 Else
'                    Command3.Enabled = False
'                    Command1.Enabled = False
'                    Call definegrid
                     Unload Me
                 End If
            End If
         End If
      End If
   End If
End Function
Private Function GrabarCuartoZZZ(ByVal tk) As Boolean
 Set ConsultaCuartoZZZ = CreateObject("ADODB.Recordset")
With ConsultaCuartoZZZ
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With

 If Flg_Pais$ = "FACO" Then
  sq2 = Borrar_tk_faco(tk)
 
 End If

  sq = arma_query_rec(tk)
   
   On Error GoTo oraerror
   If Flg_Pais$ = "FACO" Then
        Call ConsultaCuartoZZZ.Open(sq2)
   End If
   Call ConsultaCuartoZZZ.Open(sq)
   
   GrabarCuartoZZZ = True
   Set ConsultaCuartoZZZ.ActiveConnection = Nothing
   Exit Function
oraerror:
    GrabarCuartoZZZ = False
    SystemMsg = "No se pudo Obtener Secuencia "
    frmLogOraError.Show 1
End Function

  Function Borrar_tk_faco(tk) As String
On Error GoTo Error
  
      sq = "" & _
         "delete vta_" & Flg_Pais$ & "zzz " & _
         "where  rec_techkey = " & tk & " "
   
Borrar_tk_faco = sq
Exit Function

Error:
    Borrar_tk_faco = ""
    Exit Function

  
End Function
Private Function GrabarPrimeraZZZ(ByVal boli, ByVal nrollo, ByVal repini) As Double
Set ConsultaPrimeraZZZ = CreateObject("ADODB.Recordset")
With ConsultaPrimeraZZZ
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With

 '  qbol = Grid0.TextMatrix(6, 1) - boli + 1
  
   'sq = "select  " & IIf(Flg_Pais$ = "ARG" or Flg_Pais$ = "SOAR" or  Flg_Pais$ = "SOUY", "SEQ_VTA_ARGTEC", "VTA_RET_SEC") & ".nextval    From dual "
   sq = "select " & IIf((Flg_Pais$ <> "" And Flg_Pais$ <> "CHI" And Flg_Pais$ <> "PER" And Flg_Pais$ <> "SOPE" And Flg_Pais$ <> "SPOR" And Flg_Pais$ <> "MAPE" And Flg_Pais$ <> "MPAM"), "SEQ_VTA_" & Flg_Pais$ & "TEC", "VTA_TEC_SEC") & ".nextval    From dual "
   On Error GoTo oraerror
   GrabarPrimeraZZZ = -1
   
   Call ConsultaPrimeraZZZ.Open(sq)
   
   If ConsultaPrimeraZZZ.RecordCount > 0 Then
      GrabarPrimeraZZZ = ConsultaPrimeraZZZ.Fields(0)
      
   End If
   Set ConsultaPrimeraZZZ.ActiveConnection = Nothing
   Exit Function
oraerror:
    SystemMsg = "No se pudo Obtener Secuencia "
   frmLogOraError.Show 1
End Function
Private Function GrabarSegundaZZZ() As Boolean
Set ConsultaSegundaZZZ = CreateObject("ADODB.Recordset")
With ConsultaSegundaZZZ
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With

   
  
      sq = "" & _
        " delete vta_" & Flg_Pais$ & "libvta " & _
        " where  vta_fecha_venta = to_date('" & Format(DTPicker1.Value, VgFormatoFechaWhere) & "','" & VgFormatoFechaWhere & "') " & _
        " and    vta_tiporeg = 'Y' " & _
        " and    vta_local = " & Grid0.TextMatrix(2, 1) & " " & _
        " and    vta_terminal = " & Grid0.TextMatrix(3, 1) & _
        " and    vta_secuencia = " & Grid0.TextMatrix(4, 1)
   On Error GoTo oraerror
   GrabarSegundaZZZ = -1
 
   Call ConsultaSegundaZZZ.Open(sq)
   GrabarSegundaZZZ = True
   Set ConsultaSegundaZZZ.ActiveConnection = Nothing
   Exit Function
oraerror:
    GrabarSegundaZZZ = False
    SystemMsg = "No se pudo Eliminar registro de cierre"
    frmLogOraError.Show 1
End Function
Private Function GrabarQuintoZZZ(ByVal vTER_LOCAL As String, ByVal vTER_TERMINAL As String, ByVal vTER_FECHA As String, ByVal vTER_CIERREY As String, ByVal vTER_ESTADO As String, ByVal vTER_NOTAS As String, ByVal vTER_CERRADOPOR As String) As Boolean
Set ConsultaQuintoZZZ = CreateObject("ADODB.Recordset")
With ConsultaQuintoZZZ
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With

   ' to_date('" & Format(vTER_FECHA , VgFormatoFecha) & "','yyyymmdd')"
  
      sq = "" & _
        " Insert Into  vta_" & Flg_Pais$ & "termstaty(   " & _
        "  TER_LOCAL    ,    TER_TERMINAL ,   TER_FECHA  ,     TER_CIERREY    , TER_ESTADO    ,  TER_NOTAS     ,  TER_CERRADOPOR   " & _
        " ) " & _
        " Values ( " & _
        " " & vTER_LOCAL & "," & vTER_TERMINAL & "," & " to_date('" & Format(vTER_FECHA, VgFormatoFecha) & "','" & VgFormatoFecha & "')" & "," & vTER_CIERREY & "," & vTER_ESTADO & ", '" & vTER_NOTAS & "' , '" & vTER_CERRADOPOR & "' " & _
        " ) "
   On Error GoTo oraerror
   GrabarQuintoZZZ = -1
 
   Call ConsultaQuintoZZZ.Open(sq)
   GrabarQuintoZZZ = True
   Set ConsultaQuintoZZZ.ActiveConnection = Nothing
   Exit Function
oraerror:
    GrabarQuintoZZZ = False
    SystemMsg = "Error de grabaci�n de registro de terminar Y "
    frmLogOraError.Show 1
End Function
Private Function GrabarTerceraZZZ(ByVal boli, ByVal nrollo, ByVal qbol, ByVal tk) As Boolean
Dim Vtiempo  As String

Vtiempo = Mid(Trim(Grid1.TextMatrix(5, 1)), 1, 2) + Mid(Trim(Grid1.TextMatrix(5, 1)), 4, 2)

Set ConsultaTerceraZZZ = CreateObject("ADODB.Recordset")
With ConsultaTerceraZZZ
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With

If Trim(Grid1.TextMatrix(11, 1)) <> "" Then
   valor11 = IIf(Trim(Grid1.TextMatrix(18, 1)) = "", "0", Change_Char(Round(CDbl(Grid1.TextMatrix(18, 1)), 2), ",", "."))
Else
   valor11 = "0"
End If
If Flg_Pais$ = "ARG" Then
   Vtiempo = Mid(Trim(Grid0.TextMatrix(5, 1)), 1, 2) + Mid(Trim(Grid0.TextMatrix(5, 1)), 4, 2)

  sq2 = "       insert into VTA_" & Flg_Pais$ & "LIBVTA("
  sq2 = sq2 & "   VTA_FECHA          , VTA_LOCAL      "
  sq2 = sq2 & " ,VTA_TERMINAL        ,VTA_TIPOREG     "
  sq2 = sq2 & " ,VTA_SECUENCIA       ,VTA_FECHA_VENTA "
  sq2 = sq2 & " ,VTA_MONTOBOL        ,VTA_MONTOFAC    "
  sq2 = sq2 & " ,VTA_MONTONCR        ,VTA_TOTALVTA    "
  sq2 = sq2 & " ,VTA_NUMBOL          ,VTA_NUMFAC      "
  sq2 = sq2 & " ,VTA_NUMNCR          ,VTA_MONBOL_IVA  "
  sq2 = sq2 & " ,VTA_MONBOL_AD       ,VTA_MONBOL_EX   "
  sq2 = sq2 & " ,VTA_MONIVA          ,VTA_MONADIC     "
  sq2 = sq2 & " ,VTA_BOLINICIAL      ,VTA_BOLFINAL    "
  sq2 = sq2 & " ,VTA_CANTBOL         ,VTA_NROLLO      "
  sq2 = sq2 & " ,VTA_CREPO_INICIAL   ,VTA_CREPO_FINAL "
  sq2 = sq2 & " ,VTA_ESTADO          ,VTA_TIPOF8      "
  sq2 = sq2 & " ,VTA_TRASPASO        ,VTA_FECHA_TRASPASO"
'  sq2 = sq2 & " ,VTA_TRASPASADO_AL   ,VTA_TRASPASADO_POR"
  sq2 = sq2 & " ,VTA_SECUENCIA_SRX   ,VTA_HORA        "
  sq2 = sq2 & " ,VTA_VENDEDOR        ,VTA_TECHKEY     "
  sq2 = sq2 & " ,VTA_CONSOLIDADO     ,VTA_MMONTOBOLPER"
  sq2 = sq2 & " ,VTA_MMONTOTKRUC     ,VTA_MMONTONDB   "
  sq2 = sq2 & " ,VTA_MNETOTKT        ,VTA_MMONTOTROSIMP"
  sq2 = sq2 & " ,VTA_MTICKET         ,VTA_MTKTFACA    "
  sq2 = sq2 & " ,VTA_MTKTFACB        ,VTA_MFACA       "
  sq2 = sq2 & " ,VTA_MFACB           ,VTA_MNCRA       "
  sq2 = sq2 & " ,VTA_MNCRB           ,VTA_MONTKT_NG   "
  sq2 = sq2 & " ,VTA_MONTKT_PC1      ,VTA_MONTKT_PC2  "
  sq2 = sq2 & " ,VTA_MONTKT_PC3      ,VTA_MONTKT_ICINE "
  sq2 = sq2 & " ,vta_mtotal_ndebitoa "
  sq2 = sq2 & " ,vta_mtotal_ndebitob "
  sq2 = sq2 & " ,vta_mtotal_fact_elec_b "
  sq2 = sq2 & " ,vta_mtotal_fact_elec_a "
  sq2 = sq2 & " ,vta_mtotal_nc_elec_b "
  sq2 = sq2 & " ,vta_mtotal_nc_elec_a "
  sq2 = sq2 & " ) "
  sq2 = sq2 & " Values (        "
  sq2 = sq2 & " to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')" & ", " & Grid0.TextMatrix(2, 1)
  sq2 = sq2 & " , " & Grid0.TextMatrix(3, 1) & ",  'Y'     "
  sq2 = sq2 & " , " & Trim(Grid0.TextMatrix(4, 1)) & "  ,   to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')"
  sq2 = sq2 & " ,0 ,0 "      ',VTA_MONTOBOL        ,VTA_MONTOFAC    "
  sq2 = sq2 & " ,0 , " & CStr(valor11)  ',VTA_MONTONCR        ,VTA_TOTALVTA    "
  sq2 = sq2 & " ," & IIf(Change_Char(Round(CDbl(Grid0.TextMatrix(7, 1)), 2), ",", ".") = "", "0", Change_Char(Round(CDbl(Grid0.TextMatrix(7, 1)), 2), ",", ".")) & ",0 "  ' ,VTA_NUMBOL          ,VTA_NUMFAC      "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_NUMNCR          ,VTA_MONBOL_IVA  "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MONBOL_AD       ,VTA_MONBOL_EX   "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MONIVA          ,VTA_MONADIC     "
  sq2 = sq2 & " , " & boli & " , " & qbol       ' ,VTA_BOLINICIAL      ,VTA_BOLFINAL    "
  sq2 = sq2 & " ,0 ," & nrollo       ' ,VTA_CANTBOL         ,VTA_NROLLO      "
  sq2 = sq2 & " ,0 , " & Grid0.TextMatrix(9, 1)    ' ,VTA_CREPO_INICIAL   ,VTA_CREPO_FINAL "
  sq2 = sq2 & " ,'A' ,'N' "      ' ,VTA_ESTADO          ,VTA_TIPOF8      "
  sq2 = sq2 & " ,0  ,   to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')"      ' ,VTA_TRASPASO        ,VTA_FECHA_TRASPASO"
 ' sq2 = sq2 & " ,' ',' ' "      ' ,VTA_TRASPASADO_AL   ,VTA_TRASPASADO_POR"
  sq2 = sq2 & " ," & Grid0.TextMatrix(6, 1) & "  , " & Vtiempo & "     "   ' ,VTA_SECUENCIA_SRX   ,VTA_HORA        "
  sq2 = sq2 & " ," & Grid0.TextMatrix(8, 1) & "  , " & tk     ' ,VTA_VENDEDOR        ,VTA_TECHKEY     "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_CONSOLIDADO     ,VTA_MMONTOBOLPER"
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MMONTOTKRUC     ,VTA_MMONTONDB   "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MNETOTKT        ,VTA_MMONTOTROSIMP"
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(4, 1)), 2), ",", ".") & ", " & Change_Char(Round(CDbl(Grid1.TextMatrix(5, 1)), 2), ",", ".") & " "      ' ,VTA_MTICKET         ,VTA_MTKTFACA    "
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(6, 1)), 2), ",", ".") & ", " & Change_Char(Round(CDbl(Grid1.TextMatrix(7, 1)), 2), ",", ".") & " "      ' ,VTA_MTKTFACB        ,VTA_MFACA       "
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(8, 1)), 2), ",", ".") & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(9, 1)), 2), ",", ".") & " "     ' ,VTA_MFACB           ,VTA_MNCRA       "
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(10, 1)), 2), ",", ".") & ",0 "      ' ,VTA_MNCRB           ,VTA_MONTKT_NG   "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MONTKT_PC1      ,VTA_MONTKT_PC2  "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MONTKT_PC3      ,VTA_MONTKT_ICINE "
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(11, 1)), 2), ",", ".")
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(12, 1)), 2), ",", ".")
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(14, 1)), 2), ",", ".")
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(13, 1)), 2), ",", ".")
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(16, 1)), 2), ",", ".")
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(15, 1)), 2), ",", ".")
  sq2 = sq2 & " ) "
  
ElseIf Flg_Pais$ = "SOAR" Or Flg_Pais$ = "SOUY" Then

Vtiempo = Mid(Trim(Grid0.TextMatrix(5, 1)), 1, 2) + Mid(Trim(Grid0.TextMatrix(5, 1)), 4, 2)

  sq2 = "       insert into VTA_" & Flg_Pais$ & "LIBVTA("
  sq2 = sq2 & "   VTA_FECHA          , VTA_LOCAL      "
  sq2 = sq2 & " ,VTA_TERMINAL        ,VTA_TIPOREG     "
  sq2 = sq2 & " ,VTA_SECUENCIA       ,VTA_FECHA_VENTA "
  sq2 = sq2 & " ,VTA_MONTOBOL        ,VTA_MONTOFAC    "
  sq2 = sq2 & " ,VTA_MONTONCR        ,VTA_TOTALVTA    "
  sq2 = sq2 & " ,VTA_NUMBOL          ,VTA_NUMFAC      "
  sq2 = sq2 & " ,VTA_NUMNCR          ,VTA_MONBOL_IVA  "
  sq2 = sq2 & " ,VTA_MONBOL_AD       ,VTA_MONBOL_EX   "
  sq2 = sq2 & " ,VTA_MONIVA          ,VTA_MONADIC     "
  sq2 = sq2 & " ,VTA_BOLINICIAL      ,VTA_BOLFINAL    "
  sq2 = sq2 & " ,VTA_CANTBOL         ,VTA_NROLLO      "
  sq2 = sq2 & " ,VTA_CREPO_INICIAL   ,VTA_CREPO_FINAL "
  sq2 = sq2 & " ,VTA_ESTADO          ,VTA_TIPOF8      "
  sq2 = sq2 & " ,VTA_TRASPASO        ,VTA_FECHA_TRASPASO"
  sq2 = sq2 & " ,VTA_SECUENCIA_SRX   ,VTA_HORA        "
  sq2 = sq2 & " ,VTA_VENDEDOR        ,VTA_TECHKEY     "
  sq2 = sq2 & " ,VTA_CONSOLIDADO     ,VTA_MMONTOBOLPER"
  sq2 = sq2 & " ,VTA_MMONTOTKRUC     ,VTA_MMONTONDB   "
  sq2 = sq2 & " ,VTA_MNETOTKT        ,VTA_MMONTOTROSIMP"
  sq2 = sq2 & " ,VTA_MTICKET         ,VTA_MTKTFACA    "
  sq2 = sq2 & " ,VTA_MTKTFACB        ,VTA_MFACA       "
  sq2 = sq2 & " ,VTA_MFACB           ,VTA_MNCRA       "
  sq2 = sq2 & " ,VTA_MNCRB           ,VTA_MONTKT_NG   "
  sq2 = sq2 & " ,VTA_MONTKT_PC1      ,VTA_MONTKT_PC2  "
  sq2 = sq2 & " ,VTA_MONTKT_PC3      ,VTA_MONTKT_ICINE "
  
 sq2 = sq2 & " ,vta_mtotal_ndebitoa "
 sq2 = sq2 & " ,vta_mtotal_ndebitob "
 sq2 = sq2 & " ,vta_mtotal_fact_elec_b "
 sq2 = sq2 & " ,vta_mtotal_fact_elec_a "
 sq2 = sq2 & " ,vta_mtotal_nc_elec_b "
 sq2 = sq2 & " ,vta_mtotal_nc_elec_a "
  

  sq2 = sq2 & " ) "
  sq2 = sq2 & " Values (        "
  sq2 = sq2 & " to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')" & ", " & Grid0.TextMatrix(2, 1)
  sq2 = sq2 & " , " & Grid0.TextMatrix(3, 1) & ",  'Y'     "
  sq2 = sq2 & " , " & Trim(Grid0.TextMatrix(4, 1)) & " ,   to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')"
  sq2 = sq2 & " ,0 ,0 "      '  ,VTA_MONTOBOL        ,VTA_MONTOFAC    "
  sq2 = sq2 & " ,0 , " & Change_Char(Round(CDbl(Grid1.TextMatrix(11, 1)), 2), ",", ".")        ' ,VTA_MONTONCR        ,VTA_TOTALVTA    "
  sq2 = sq2 & " ," & Change_Char(Round(CDbl(Grid0.TextMatrix(7, 1)), 2), ",", ".") & ",0 "      ' ,VTA_NUMBOL          ,VTA_NUMFAC      "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_NUMNCR          ,VTA_MONBOL_IVA  "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MONBOL_AD       ,VTA_MONBOL_EX   "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MONIVA          ,VTA_MONADIC     "
  sq2 = sq2 & " , " & boli & " , " & qbol       ' ,VTA_BOLINICIAL      ,VTA_BOLFINAL    "
  sq2 = sq2 & " ,0 , " & nrollo       ' ,VTA_CANTBOL         ,VTA_NROLLO      "
  sq2 = sq2 & " ,0 , " & Grid0.TextMatrix(9, 1)     '       ,VTA_CREPO_INICIAL   ,VTA_CREPO_FINAL "
  sq2 = sq2 & " ,'A' ,'N' "      ' ,VTA_ESTADO          ,VTA_TIPOF8      "
  sq2 = sq2 & " ,0  ,   to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')"      ' ,VTA_TRASPASO        ,VTA_FECHA_TRASPASO"
 ' sq2 = sq2 & " ,' ',' ' "      ' ,VTA_TRASPASADO_AL   ,VTA_TRASPASADO_POR"
  sq2 = sq2 & " ," & Grid0.TextMatrix(6, 1) & "  , " & Vtiempo & "     "  ' ,VTA_SECUENCIA_SRX   ,VTA_HORA        "
  sq2 = sq2 & " ," & Grid0.TextMatrix(8, 1) & "  , " & tk     ' ,VTA_VENDEDOR        ,VTA_TECHKEY     "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_CONSOLIDADO     ,VTA_MMONTOBOLPER"
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MMONTOTKRUC     ,VTA_MMONTONDB   "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MNETOTKT        ,VTA_MMONTOTROSIMP"
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(4, 1)), 2), ",", ".") & ", 0 "      ' ,VTA_MTICKET         ,VTA_MTKTFACA    "
  sq2 = sq2 & " ,0 , " & Change_Char(Round(CDbl(Grid1.TextMatrix(5, 1)), 2), ",", ".") & " "      ' ,VTA_MTKTFACB        ,VTA_MFACA       "
  sq2 = sq2 & " ,0 , " & Change_Char(Round(CDbl(Grid1.TextMatrix(6, 1)), 2), ",", ".") & " "     ' ,VTA_MFACB           ,VTA_MNCRA       "
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(7, 1)), 2), ",", ".") & ",0 "      ' ,VTA_MNCRB           ,VTA_MONTKT_NG   "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MONTKT_PC1      ,VTA_MONTKT_PC2  "
  sq2 = sq2 & " ,0 ,0 "      ' ,VTA_MONTKT_PC3      ,VTA_MONTKT_ICINE "
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(8, 1)), 2), ",", ".")
  sq2 = sq2 & " , " & Change_Char(Round(CDbl(Grid1.TextMatrix(9, 1)), 2), ",", ".")
  sq2 = sq2 & " , 0"
  sq2 = sq2 & " , 0"
  sq2 = sq2 & " , 0"
  sq2 = sq2 & " , 0"
  sq2 = sq2 & " ) "

ElseIf Flg_Pais$ = "HTPE" Then
Vtiempo = Mid(Trim(Grid0.TextMatrix(4, 1)), 1, 2) + Mid(Trim(Grid0.TextMatrix(4, 1)), 4, 2)

sq2 = " insert into vta_" & Flg_Pais$ & "libvta "
sq2 = sq2 & " (vta_fecha"
sq2 = sq2 & ", vta_local"
sq2 = sq2 & ", vta_terminal "
sq2 = sq2 & ", vta_tiporeg"
sq2 = sq2 & ", vta_secuencia"
sq2 = sq2 & ", vta_fecha_venta "
sq2 = sq2 & ", vta_montobol"  '' ticket peru
sq2 = sq2 & ", vta_montofac"  '' facturas
sq2 = sq2 & ", vta_montoncr " '' notas de credito
sq2 = sq2 & ", vta_totalvta"
sq2 = sq2 & ", vta_numbol"
sq2 = sq2 & ", vta_numfac"
sq2 = sq2 & ", vta_numncr "
sq2 = sq2 & ", vta_monbol_iva"
sq2 = sq2 & ", vta_monbol_ad"
sq2 = sq2 & ", vta_monbol_ex "
sq2 = sq2 & ", vta_moniva"
sq2 = sq2 & ", vta_monadic"
sq2 = sq2 & ", vta_bolinicial"
sq2 = sq2 & ", vta_bolfinal "
sq2 = sq2 & ", vta_cantbol"
sq2 = sq2 & ", vta_nrollo"
sq2 = sq2 & ", vta_crepo_inicial"
sq2 = sq2 & ", vta_crepo_final "
sq2 = sq2 & ", vta_estado"
sq2 = sq2 & ", vta_tipof8"
sq2 = sq2 & ", vta_secuencia_srx"
sq2 = sq2 & ", vta_hora"
sq2 = sq2 & ", vta_vendedor"
sq2 = sq2 & ", vta_mmontobolper"  ''venta boleta
sq2 = sq2 & ", vta_mmontotkruc"  ''ticket ruc
sq2 = sq2 & ",vta_mmontondb,vta_mnetotkt,vta_mmontotrosimp"
sq2 = sq2 & ", vta_techkey) "
totales_vta = (CDbl(Grid1.TextMatrix(2, 1)) + CDbl(Grid1.TextMatrix(3, 1)) + CDbl(Grid1.TextMatrix(4, 1)) + CDbl(Grid1.TextMatrix(5, 1)) + CDbl(Grid1.TextMatrix(8, 1)))
sq2 = sq2 & "values (to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')"
sq2 = sq2 & ",     " & Grid0.TextMatrix(2, 1) & " "
sq2 = sq2 & ",     " & Grid0.TextMatrix(3, 1) & " "
sq2 = sq2 & ",     'Y'"
sq2 = sq2 & ",      " & Grid0.TextMatrix(4, 1) & " "
sq2 = sq2 & ",     to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')"
sq2 = sq2 & ",     " & Change_Char(Round(CDbl(Grid1.TextMatrix(2, 1)), 2), ",", ".") & " "
sq2 = sq2 & ",     " & Change_Char(Round(CDbl(Grid1.TextMatrix(3, 1)), 2), ",", ".") & " "
sq2 = sq2 & ",     " & Change_Char(Round(CDbl(Grid1.TextMatrix(8, 1)), 2), ",", ".") & " "
sq2 = sq2 & ",     " & Change_Char(Round(CDbl(totales_vta), 2), ",", ".") & " "
sq2 = sq2 & ",     0 "
sq2 = sq2 & ",     0 "
sq2 = sq2 & ",     0 "
sq2 = sq2 & ",     0 "
sq2 = sq2 & ",     0 "
sq2 = sq2 & ",     0 "
sq2 = sq2 & ",     0 "
sq2 = sq2 & ",     0 "
sq2 = sq2 & ",     " & boli & " "
sq2 = sq2 & ",     " & Grid0.TextMatrix(6, 1) & " "
sq2 = sq2 & ",     " & qbol & " "
sq2 = sq2 & ",     " & nrollo & " "
sq2 = sq2 & ",     " & Grid0.TextMatrix(8, 1) & " "
sq2 = sq2 & ",     " & Grid0.TextMatrix(8, 1) & " "
sq2 = sq2 & ",     'A'"
sq2 = sq2 & ",     'N'"
sq2 = sq2 & ",     " & Mid(Trim(Grid0.TextMatrix(5, 1)), 1, 2) & Mid(Trim(Grid0.TextMatrix(5, 1)), 4, 2) & " "
sq2 = sq2 & ",     " & Vtiempo & " "
sq2 = sq2 & ",     " & Grid0.TextMatrix(7, 1) & " "
sq2 = sq2 & ",     " & Change_Char(Round(CDbl(Grid1.TextMatrix(5, 1)), 2), ",", ".") & " "
sq2 = sq2 & ",     " & Change_Char(Round(CDbl(Grid1.TextMatrix(4, 1)), 2), ",", ".") & " "
sq2 = sq2 & ",0,0,0"

sq2 = sq2 & ",     " & tk & ")  "
ElseIf Flg_Pais$ = "SFCL" Then
  Vtiempo = Mid(Trim(Grid0.TextMatrix(5, 1)), 1, 2) + Mid(Trim(Grid0.TextMatrix(5, 1)), 4, 2)
 
sq2 = " Insert into vta_" & Flg_Pais$ & "libvta " & _
     "  (vta_fecha        , vta_local " & _
     ",  vta_terminal     , vta_tiporeg " & _
     ",  vta_secuencia    , vta_fecha_venta " & _
     ",  vta_montobol     , vta_montofac " & _
     ",  vta_montoncr     , vta_totalvta" & _
     ",  vta_numbol       , vta_numfac " & _
     ",  vta_numncr       , vta_monbol_iva " & _
     ",  vta_monbol_ad    , vta_monbol_ex " & _
     ",  vta_moniva       , vta_monadic " & _
     ",  vta_bolinicial   , vta_bolfinal " & _
     ",  vta_cantbol      , vta_nrollo " & _
     ",  vta_crepo_inicial, vta_crepo_final " & _
     ",  vta_estado       , vta_tipof8 " & _
     ",  vta_secuencia_srx, vta_hora " & _
     ",  vta_vendedor     , vta_techkey" & _
     ",  vta_mmontobolper ,vta_mmontotkruc " & _
     ",  vta_mmontondb    ,vta_mnetotkt, vta_montoguia ) "

sq2 = sq2 & _
     "values (to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')" & _
     ",     " & Grid0.TextMatrix(2, 1) & " " & _
     ",     " & Grid0.TextMatrix(3, 1) & " " & _
     ",     'Y'," & Trim(Grid0.TextMatrix(4, 1)) & _
     ",     to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')" & _
     ",     " & Change_Char(CDbl(Grid1.TextMatrix(2, 1)), ",", ".") & " " & _
     ",     " & Change_Char(CDbl(Grid1.TextMatrix(4, 1)), ",", ".") & " " & _
     ",     " & Change_Char(CDbl(Grid1.TextMatrix(3, 1)), ",", ".") & " " & _
     ",     " & Change_Char(CDbl(Grid1.TextMatrix(7, 1)), ",", ".") & " " & _
     ",     0,0,0,0,0,0,0,0 " & _
     ",     " & boli & " " & _
     ",     " & Grid0.TextMatrix(6, 1) & " " & _
     ",     " & qbol & " " & _
     ",     " & nrollo & " " & _
     ",     " & Grid0.TextMatrix(8, 1) & " " & _
     ",     " & Grid0.TextMatrix(8, 1) & " " & _
     ",     'A', 'N', " & Vtiempo & " " & _
     ",     " & Vtiempo & " " & _
     ",     " & Grid0.TextMatrix(7, 1) & " " & _
     ",     " & tk & ",0,0," & Change_Char(CDbl(Grid1.TextMatrix(5, 1)), ",", ".") & ",0" & _
     ",     " & Change_Char(CDbl(Grid1.TextMatrix(6, 1)), ",", ".") & " " & _
     ") "
Else
Vtiempo = Mid(Trim(Grid0.TextMatrix(5, 1)), 1, 2) + Mid(Trim(Grid0.TextMatrix(5, 1)), 4, 2)
 
sq2 = " Insert into vta_" & Flg_Pais$ & "libvta " & _
     "  (vta_fecha        , vta_local " & _
     ",  vta_terminal     , vta_tiporeg " & _
     ",  vta_secuencia    , vta_fecha_venta " & _
     ",  vta_montobol     , vta_montofac " & _
     ",  vta_montoncr     , vta_totalvta" & _
     ",  vta_numbol       , vta_numfac " & _
     ",  vta_numncr       , vta_monbol_iva " & _
     ",  vta_monbol_ad    , vta_monbol_ex " & _
     ",  vta_moniva       , vta_monadic " & _
     ",  vta_bolinicial   , vta_bolfinal " & _
     ",  vta_cantbol      , vta_nrollo " & _
     ",  vta_crepo_inicial, vta_crepo_final " & _
     ",  vta_estado       , vta_tipof8 " & _
     ",  vta_secuencia_srx, vta_hora " & _
     ",  vta_vendedor     , vta_techkey" & _
     ",  vta_mmontobolper ,vta_mmontotkruc " & _
     ",  vta_mmontondb    ,vta_mnetotkt ) "

sq2 = sq2 & _
     "values (to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')" & _
     ",     " & Grid0.TextMatrix(2, 1) & " " & _
     ",     " & Grid0.TextMatrix(3, 1) & " " & _
     ",     'Y'," & Trim(Grid0.TextMatrix(4, 1)) & _
     ",     to_date('" & Format(DTPicker1.Value, VgFormatoFecha) & "','" & VgFormatoFecha & "')" & _
     ",     " & Change_Char(CDbl(Grid1.TextMatrix(2, 1)), ",", ".") & " " & _
     ",     " & Change_Char(CDbl(Grid1.TextMatrix(4, 1)), ",", ".") & " " & _
     ",     " & Change_Char(CDbl(Grid1.TextMatrix(3, 1)), ",", ".") & " " & _
     ",     " & Change_Char(CDbl(Grid1.TextMatrix(5, 1)), ",", ".") & " " & _
     ",     0,0,0,0,0,0,0,0 " & _
     ",     " & boli & " " & _
     ",     " & Grid0.TextMatrix(6, 1) & " " & _
     ",     " & qbol & " " & _
     ",     " & nrollo & " " & _
     ",     " & Grid0.TextMatrix(8, 1) & " " & _
     ",     " & Grid0.TextMatrix(8, 1) & " " & _
     ",     'A', 'N', " & Grid0.TextMatrix(6, 1) & " " & _
     ",     " & Vtiempo & " " & _
     ",     " & Grid0.TextMatrix(7, 1) & " " & _
     ",     " & tk & ",0,0,0,0 ) "
     
End If
 
   
   On Error GoTo oraerror
   GrabarTerceraZZZ = -1
 
   Call ConsultaTerceraZZZ.Open(sq2)
   GrabarTerceraZZZ = True
   Set ConsultaTerceraZZZ.ActiveConnection = Nothing
   Exit Function
oraerror:
    GrabarTerceraZZZ = False
    SystemMsg = "No se pudo crear registro de cierre "
    frmLogOraError.Show 1
End Function
Sub SubDefineDetalleMonto()
Dim indicepromo As Integer
Set Consulta = CreateObject("ADODB.Recordset")
With Consulta
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With

Grid1.Visible = False
Grid1.Enabled = True
   
   '' LLENO grilla con informacion de paintz
   
   sq = "select z.vtaglosa_z,z.vta_cmp_asoc,decode(z.VTA_POP_UP,null,0,z.VTA_POP_UP) " & _
        "as pop_up from vta_paint_z z " & _
        "where z.vta_localiz = '" & IIf(Trim(Flg_Pais$) = "", "CHI", Flg_Pais$) & _
        "' order by z.vta_order_z"
   
   On Error GoTo oraerror
   Call Consulta.Open(sq)
   
i = 1
   Do While Not Consulta.EOF
        Grid1.Rows = Consulta.RecordCount + 1
        ' Grid1.TextMatrix(i, 0) = CStr(i) + IIf(IsNull(Consulta.Fields("vtaglosa_z")), "", Consulta.Fields("vtaglosa_z"))
        Grid1.TextMatrix(i, 0) = IIf(IsNull(Consulta.Fields("vtaglosa_z")), "", Consulta.Fields("vtaglosa_z"))
        If Val(Consulta.Fields("pop_up")) = 1 Or Val(Consulta.Fields("pop_up")) = 2 Then
           If Trim(Grid1.TextMatrix(i, 0)) = "TOTAL FORMAS DE PAGOS" Then
                indice = 39: Columna = 1
                Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 24, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, Columna)) = "", "0", Trim(Grid1.TextMatrix(113, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, Columna)) = "", "0", Trim(Grid1.TextMatrix(114, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, Columna)) = "", "0", Trim(Grid1.TextMatrix(115, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, Columna)) = "", "0", Trim(Grid1.TextMatrix(116, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, Columna)) = "", "0", Trim(Grid1.TextMatrix(117, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, Columna)) = "", "0", Trim(Grid1.TextMatrix(140, Columna))))
                
              
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, Columna))))
'
                Grid1.TextMatrix(i, Columna) = Format(Vl_FormaPago, gFormat)
                'Grid1.TextMatrix(indice, Columna) = Format(Vl_FormaPago, gFormat)
                
                indice = 39: Columna = 2
                Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 17, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, Columna)) = "", "0", Trim(Grid1.TextMatrix(113, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, Columna)) = "", "0", Trim(Grid1.TextMatrix(114, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, Columna)) = "", "0", Trim(Grid1.TextMatrix(115, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, Columna)) = "", "0", Trim(Grid1.TextMatrix(116, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, Columna)) = "", "0", Trim(Grid1.TextMatrix(117, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, Columna)) = "", "0", Trim(Grid1.TextMatrix(140, Columna))))
'
'                Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 25, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 25, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 24, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 24, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 23, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 23, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 14, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 14, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, Columna))))
'
                 Grid1.TextMatrix(i, Columna) = Format(Vl_FormaPago, gFormat)
                
                  
                indice = 39: Columna = 4
                Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 17, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, Columna)) = "", "0", Trim(Grid1.TextMatrix(113, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, Columna)) = "", "0", Trim(Grid1.TextMatrix(114, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, Columna)) = "", "0", Trim(Grid1.TextMatrix(115, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, Columna)) = "", "0", Trim(Grid1.TextMatrix(116, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, Columna)) = "", "0", Trim(Grid1.TextMatrix(117, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, Columna)) = "", "0", Trim(Grid1.TextMatrix(140, Columna))))
'
'                        Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 25, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 25, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 24, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 24, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 23, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 23, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 14, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 14, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, Columna))))
                Grid1.TextMatrix(i, Columna) = Format(Vl_FormaPago, gFormat)
                'Grid1.TextMatrix(indice, Columna) = Format(Vl_FormaPago, gFormat)
             
                   indice = 39: Columna = 5
                Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 17, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, Columna)) = "", "0", Trim(Grid1.TextMatrix(113, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, Columna)) = "", "0", Trim(Grid1.TextMatrix(114, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, Columna)) = "", "0", Trim(Grid1.TextMatrix(115, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, Columna)) = "", "0", Trim(Grid1.TextMatrix(116, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, Columna)) = "", "0", Trim(Grid1.TextMatrix(117, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, Columna)) = "", "0", Trim(Grid1.TextMatrix(140, Columna))))
'
'                Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 25, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 25, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 24, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 24, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 23, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 23, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 14, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 14, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, Columna))))
                Grid1.TextMatrix(i, Columna) = Format(Vl_FormaPago, gFormat)
                'Grid1.TextMatrix(indice, Columna) = Format(Vl_FormaPago, gFormat)
             
                
                Grid1.TextMatrix(i, 6) = (Format((CDbl(Grid1.TextMatrix(i, 4)) - (CDbl(Grid1.TextMatrix(i, 5)) + CDbl(Grid1.TextMatrix(i, 1)))), gFormat))
            ElseIf Trim(Grid1.TextMatrix(i, 0)) = "NOTA CREDITO PROMO" Then
                indicepromo = i
                
               
            Else
             Grid1.TextMatrix(i, 1) = ""
           End If
        Else
           If VF_ExisteTerminaY = True Then
                Grid1.TextMatrix(i, 1) = Format(FuncValorDelCampo(Consulta.Fields("vta_cmp_asoc"), DTPicker1.Value, Grid0.TextMatrix(2, 1), Grid0.TextMatrix(3, 1), "Y", Grid0.TextMatrix(4, 1)), gFormat)
           Else
               Grid1.TextMatrix(i, 1) = Format(0, gFormat)
           End If
           
           Grid1.TextMatrix(i, 4) = Format(FuncBuscaValorCampo(Consulta.Fields("vta_cmp_asoc"), DTPicker1.Value, Grid0.TextMatrix(2, 1), Grid0.TextMatrix(3, 1), "F8", Grid0.TextMatrix(4, 1)), gFormat)
           Grid1.TextMatrix(i, 5) = Format(FuncBuscaValorCampo(Consulta.Fields("vta_cmp_asoc"), DTPicker1.Value, Grid0.TextMatrix(2, 1), Grid0.TextMatrix(3, 1), "Y", Grid0.TextMatrix(4, 1)), gFormat)
           Grid1.TextMatrix(i, 6) = (Format((CDbl(Grid1.TextMatrix(i, 4)) - (CDbl(Grid1.TextMatrix(i, 5)) + CDbl(Grid1.TextMatrix(i, 1)))), gFormat))
'           Grid1.TextMatrix(i, 6) = Format(CDbl(Grid1.TextMatrix(i, 4)) - CDbl(Grid1.TextMatrix(i, 5)), gFormat)
'           Grid1.TextMatrix(i, 6) = Format(CDbl(Grid1.TextMatrix(i, 6)) + CDbl(Grid1.TextMatrix(i, 1)), gFormat)
           If Flg_Pais$ = "ARG" Or Flg_Pais$ = "SOAR" Or Flg_Pais$ = "SOUY" Then
                If Grid0.TextMatrix(2, 1) = Grid0.TextMatrix(3, 1) Then
                 Grid1.TextMatrix(i, 1) = Grid1.TextMatrix(i, 4)
                End If
           End If
        End If
        Grid1.TextMatrix(i, 2) = Consulta.Fields("pop_up")
        Grid1.TextMatrix(i, 3) = IIf(IsNull(Consulta.Fields("vta_cmp_asoc")), "", Consulta.Fields("vta_cmp_asoc"))
        'vta_cmp_asoc
        If Val(Consulta.Fields("pop_up")) = 1 Or Val(Consulta.Fields("pop_up")) = 3 Then
            For f = 0 To 6
                Grid1.row = i
                Grid1.col = f
               
               If Trim(Grid1.TextMatrix(i, 0)) = "TOTAL FORMAS DE PAGOS" Then
                   Grid1.CellBackColor = &HA4E8CB
               ElseIf Trim(Grid1.TextMatrix(i, 0)) = "NOTA CREDITO PROMO" Then
                 Grid1.CellBackColor = &HA4E8CB
                Else
                   Grid1.CellBackColor = IIf(Val(Consulta.Fields("pop_up")) = 1, &HD0EDFB, &HA4E8CB)
                End If
                If f = 1 And Val(Consulta.Fields("pop_up")) = 3 Then
                   ' Grid1.TextMatrix(i, 1) = Format(i, gFormat)
                End If
            Next f
         
            
        End If
        i = i + 1
        Consulta.MoveNext
  Loop
  Set Consulta.ActiveConnection = Nothing
  If Flg_Pais$ = "ARG" Then
   i = indicepromo
     
          'total NC CREDITO PROMO
            Vl_FormaPago = 0: indice = indicepromo
            '  Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(95, 1)) = "", "0", Trim(Grid1.TextMatrix(95, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 3, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 3, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 4, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 4, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 5, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 5, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 6, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 6, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 7, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 7, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 8, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 8, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 9, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 9, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 10, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 10, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 11, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 11, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 12, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 12, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 13, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 13, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 14, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 14, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 15, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 15, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 16, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 16, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 17, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 17, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 18, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 18, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 19, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 19, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 20, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 20, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 21, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 21, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 22, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 22, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 23, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 23, 1))))
            Grid1.TextMatrix(indice, 1) = Format(Vl_FormaPago, gFormat)
             'total NC CREDITO PROMO
            Vl_FormaPago = 0: indice = indicepromo
            '  Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(95, 1)) = "", "0", Trim(Grid1.TextMatrix(95, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 3, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 3, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 4, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 4, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 5, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 5, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 6, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 6, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 7, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 7, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 8, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 8, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 9, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 9, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 10, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 10, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 11, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 11, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 12, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 12, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 13, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 13, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 14, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 14, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 15, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 15, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 16, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 16, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 17, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 17, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 18, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 18, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 19, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 19, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 20, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 20, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 21, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 21, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 22, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 22, 4))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 23, 4)) = "", "0", Trim(Grid1.TextMatrix(indice + 23, 4))))
            Grid1.TextMatrix(indice, 4) = Format(Vl_FormaPago, gFormat)
            Vl_FormaPago = 0: indice = indicepromo
            '  Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(95, 1)) = "", "0", Trim(Grid1.TextMatrix(95, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 3, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 3, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 4, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 4, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 5, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 5, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 6, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 6, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 7, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 7, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 8, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 8, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 9, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 9, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 10, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 10, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 11, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 11, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 12, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 12, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 13, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 13, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 14, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 14, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 15, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 15, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 16, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 16, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 17, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 17, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 18, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 18, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 19, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 19, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 20, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 20, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 21, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 21, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 22, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 22, 5))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 23, 5)) = "", "0", Trim(Grid1.TextMatrix(indice + 23, 5))))
            Grid1.TextMatrix(indice, 5) = Format(Vl_FormaPago, gFormat)
            
            
            
            
            indice = 39: Columna = 1
                Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, 1))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 17, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
              '  Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, Columna)) = "", "0", Trim(Grid1.TextMatrix(113, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, Columna)) = "", "0", Trim(Grid1.TextMatrix(114, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, Columna)) = "", "0", Trim(Grid1.TextMatrix(115, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, Columna)) = "", "0", Trim(Grid1.TextMatrix(116, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, Columna)) = "", "0", Trim(Grid1.TextMatrix(117, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, Columna)) = "", "0", Trim(Grid1.TextMatrix(140, Columna))))
                
               '-- Grid1.TextMatrix(i, Columna) = "TOTAL FORMAS DE PAGOS"
                Grid1.TextMatrix(indice, Columna) = Format(Vl_FormaPago, gFormat)
                  
                  
                indice = 39: Columna = 2
                Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 17, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, Columna)) = "", "0", Trim(Grid1.TextMatrix(113, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, Columna)) = "", "0", Trim(Grid1.TextMatrix(114, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, Columna)) = "", "0", Trim(Grid1.TextMatrix(115, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, Columna)) = "", "0", Trim(Grid1.TextMatrix(116, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, Columna)) = "", "0", Trim(Grid1.TextMatrix(117, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, Columna)) = "", "0", Trim(Grid1.TextMatrix(140, Columna))))
                
                 Grid1.TextMatrix(indice, Columna) = Format(Vl_FormaPago, gFormat)
                  

                indice = 39: Columna = 4
                Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 17, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, Columna)) = "", "0", Trim(Grid1.TextMatrix(113, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, Columna)) = "", "0", Trim(Grid1.TextMatrix(114, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, Columna)) = "", "0", Trim(Grid1.TextMatrix(115, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, Columna)) = "", "0", Trim(Grid1.TextMatrix(116, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, Columna)) = "", "0", Trim(Grid1.TextMatrix(117, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, Columna)) = "", "0", Trim(Grid1.TextMatrix(140, Columna))))
                
               ' Grid1.TextMatrix(i, Columna) = "TOTAL FORMAS DE PAGOS"
                Grid1.TextMatrix(indice, Columna) = Format(Vl_FormaPago, gFormat)
             
                   indice = 39: Columna = 5
                Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 17, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, Columna))))
               ' Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice, Columna)) = "", "0", Trim(Grid1.TextMatrix(indice, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, Columna)) = "", "0", Trim(Grid1.TextMatrix(113, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, Columna)) = "", "0", Trim(Grid1.TextMatrix(114, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, Columna)) = "", "0", Trim(Grid1.TextMatrix(115, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, Columna)) = "", "0", Trim(Grid1.TextMatrix(116, Columna))))
'                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, Columna)) = "", "0", Trim(Grid1.TextMatrix(117, Columna))))
                Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, Columna)) = "", "0", Trim(Grid1.TextMatrix(140, Columna))))


              '  Grid1.TextMatrix(i, Columna) = "TOTAL FORMAS DE PAGOS"
                Grid1.TextMatrix(indice, Columna) = Format(Vl_FormaPago, gFormat)
               ' Grid1.TextMatrix(indice, 6) = (Format((CDbl(Grid1.TextMatrix(indice, 4)) - (CDbl(Grid1.TextMatrix(indice, 5)) + CDbl(Grid1.TextMatrix(indice, 1)))), gFormat))
                Grid1.TextMatrix(indice, 6) = (Format((CDbl(Grid1.TextMatrix(indice, 1)) - (CDbl(Grid1.TextMatrix(indice, 4)))), gFormat))
 
   End If
  Grid1.row = 2
  Grid1.col = 1
  Grid1.Visible = True
  
  Exit Sub
oraerror:
    Grid1.Enabled = False
    MsgBox "ERROR INDICE " & indice & " COLUMNA " & Columna
    Set Consulta.ActiveConnection = Nothing
    frmLogOraError.Show 1
Exit Sub
End Sub

Private Sub Command1_Click()
Dim Cierrey As String
Dim Vl_TotalVenta  As Double
Dim Vl_FormaPago As Double
Dim menssaje, a, b As String
Dim Vl_Pagotarjeta As Double
Dim Vl_totallestarjeta As Double
Dim indice As Integer

If revisa_grid Then
   'xintec NR 11-03-2019
   If (Flg_Pais$ = "MAPE" Or Flg_Pais$ = "MPAM" Or Flg_Pais$ = "SPOR") Then
      If LeeVendedor = 0 Then
        MsgBox "Relacion Local /Vendedor no existe", vbCritical + vbDefaultButton1, "Sistema F8"
        Exit Sub
      End If
   Else
      If Oklt = 0 Then
         MsgBox "Relacion Local /Terminal no existe", vbCritical + vbDefaultButton1, "Sistema F8"
         Exit Sub
      End If
   End If
   Cierrey = ""
   If Not Est_TermStat(DTPicker1.Value, Grid0.TextMatrix(2, 1), Grid0.TextMatrix(3, 1), Cierrey) Then
      Exit Sub
   End If
   Cierrey = ""
   If Not Est_TermStat(DTPicker1.Value, Grid0.TextMatrix(2, 1), Grid0.TextMatrix(3, 1), Grid0.TextMatrix(4, 1)) Then
      Exit Sub
   End If
   If VF_ExisteTerminaY Then
     Cierrey = Grid0.TextMatrix(4, 1)
    Else
      Cierrey = ""
   End If
   If Grid0.TextMatrix(5, 1) = "" Then
      MsgBox "Debe Indicar Hora", vbCritical + vbDefaultButton1, "Sistema F8"
      Exit Sub
   End If
   If Grid0.TextMatrix(6, 1) = "" Then
      MsgBox "Debe Indicar Secuencia", vbCritical + vbDefaultButton1, "Sistema F8"
      Exit Sub
   End If
   If Grid0.TextMatrix(7, 1) = "" Then
      MsgBox "Debe Indicar N� de Boleta", vbCritical + vbDefaultButton1, "Sistema F8"
      Exit Sub
   End If
   If Grid0.TextMatrix(8, 1) = "" Then
      MsgBox "Debe Indicar Vendedor"
      Exit Sub
   End If
   If Grid0.TextMatrix(9, 1) = "" Then
      MsgBox "Debe Indicar Contador de Reposicion", vbCritical + vbDefaultButton1, "Sistema F8"
      Exit Sub
   End If


  If Flg_Pais$ = "ARG" Then
 
       Vl_TotalVenta = CDbl(IIf(Trim(Grid1.TextMatrix(18, 1)) = "", "0", Trim(Grid1.TextMatrix(18, 1))))

    'TOTAL forma de pagos
     indice = 39
            Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 17, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116 - 2, 1)) = "", "0", Trim(Grid1.TextMatrix(116 - 2, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116 - 1, 1)) = "", "0", Trim(Grid1.TextMatrix(116 - 1, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, 1)) = "", "0", Trim(Grid1.TextMatrix(116, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, 1)) = "", "0", Trim(Grid1.TextMatrix(117, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, 1)) = "", "0", Trim(Grid1.TextMatrix(140, 1))))
            
 
'

                Vl_Pagotarjeta = 0: indice = 89
            '  Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(95, 1)) = "", "0", Trim(Grid1.TextMatrix(95, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 3, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 3, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 4, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 4, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 5, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 5, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 6, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 6, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 7, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 7, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 8, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 8, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 9, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 9, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 10, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 10, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 11, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 11, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 12, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 12, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 13, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 13, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 14, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 14, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 15, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 15, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 16, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 16, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 17, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 17, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 18, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 18, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 19, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 19, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 20, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 20, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 21, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 21, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 22, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 22, 1))))
            Vl_Pagotarjeta = Vl_Pagotarjeta + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 23, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 23, 1))))
           Vl_totallestarjeta = Format(Vl_Pagotarjeta, gFormat)

   
       If Format(Vl_FormaPago, gFormat) <> Format(0, gFormat) Then
            Vl_FormaPago = Format(Vl_FormaPago, gFormat)
       End If
       If Format(Vl_TotalVenta, gFormat) <> Format(0, gFormat) Then
          Vl_TotalVenta = Format(Vl_TotalVenta, gFormat)
       End If
       
      menssaje = "descuadrada la Z, entre la  venta versus  formas de pagos  , los valores son  : "
       a = ValidaLargoDecimales_grd(CStr(Vl_TotalVenta), 2)
       b = ValidaLargoDecimales_grd(CStr(Vl_FormaPago), 2)
      menssaje = menssaje & " Total Venta :  " & CStr(a) & " ,Total Pago : " & CStr(b) & " ,Diferencia: " & CStr((a - b))
       
       If a <> b Then
          MsgBox menssaje, vbCritical, Me.Caption
          Exit Sub
       End If
       
       If Format(Vl_Pagotarjeta, gFormat) <> Format(0, gFormat) Then
             Vl_Pagotarjeta = Format(Vl_Pagotarjeta, gFormat)
        End If
        If Format(Vl_totallestarjeta, gFormat) <> Format(0, gFormat) Then
           Vl_totallestarjeta = Format(Vl_totallestarjeta, gFormat)
        End If
        menssaje = "Descuadrado total tarjeta bancaria , con su detalle de apertura por administradora, los valores son  : "
        a = ValidaLargoDecimales_grd(CStr(Vl_Pagotarjeta), 2)
        b = ValidaLargoDecimales_grd(CStr(Vl_totallestarjeta), 2)
        menssaje = menssaje & " Total detalle administradoras :  " & CStr(a) & " ,Total tarjeta : " & CStr(b) & " ,Diferencia: " & CStr((a - b))
        If a <> b Then
           MsgBox menssaje, vbCritical, Me.Caption
           Exit Sub
         End If
   
       
  End If

   msg = "�Esta seguro de Incorporar el Nuevo cierre de y para este Terminal? "
   Estilo = vbYesNo + vbQuestion + vbDefaultButton2
   respuesta = MsgBox(msg, Estilo, "Confirma Cierre")
   If respuesta = vbNo Then Exit Sub
   
   Call GrabaZZZ
End If
End Sub

Private Sub Command2_Click()
   Unload Me
 '  Command3.Enabled = True
 '  Command2.Enabled = True
End Sub

Private Sub Command3_Click()
Dim Cierrey As String
Screen.MousePointer = 11
 
 If CDate(Format(DTPicker1.Value, "dd-mm-yyyy")) >= CDate(LeeFechaServidor) Then
       MsgBox "Error,  para este d�a ( " + CStr(DTPicker1.Value) + " ) no se puede generar un Z ", vbCritical + vbDefaultButton1, "Sistema F8"
        Screen.MousePointer = 0
       Exit Sub
 End If
' aqui controlamos si existe el y
'xintec NR 11-03-2019
If (Flg_Pais$ = "MAPE" Or Flg_Pais$ = "MPAM" Or Flg_Pais$ = "SPOR") Then
    If LeeVendedor = 0 Then
      MsgBox "Relaci�n Local /Vendedor no existe", vbCritical + vbDefaultButton1, "Sistema F8"
      Screen.MousePointer = 0
      Exit Sub
    End If
Else
    If Oklt = 0 Then
       MsgBox "Relaci�n Local /Terminal no existe", vbCritical + vbDefaultButton1, "Sistema F8"
       Screen.MousePointer = 0
       Exit Sub
    End If
End If
Cierrey = ""
If Not Est_TermStat(DTPicker1.Value, Grid0.TextMatrix(2, 1), Grid0.TextMatrix(3, 1), Cierrey) Then
   Screen.MousePointer = 0
   Exit Sub
End If
If Trim(Grid0.TextMatrix(4, 1)) = "" Then
      MsgBox "Debe Indicar el Cierre de Y", vbCritical + vbDefaultButton1, "Sistema F8"
      Screen.MousePointer = 0
      Exit Sub
End If
 
If Trim(Grid0.TextMatrix(5, 1)) = "" Then
      MsgBox "Debe Indicar Hora", vbCritical + vbDefaultButton1, "Sistema F8"
      Screen.MousePointer = 0
      Exit Sub
End If
If Grid0.TextMatrix(6, 1) = "" Then
   MsgBox "Debe Indicar Secuencia", vbCritical + vbDefaultButton1, "Sistema F8"
   Screen.MousePointer = 0
   Exit Sub
End If
If Grid0.TextMatrix(7, 1) = "" Then
   MsgBox "Debe Indicar N� de Boleta", vbCritical + vbDefaultButton1, "Sistema F8"
   Screen.MousePointer = 0
   Exit Sub
End If
If Grid0.TextMatrix(8, 1) = "" Then
   MsgBox "Debe Indicar Vendedor", vbCritical + vbDefaultButton1, "Sistema F8"
   Screen.MousePointer = 0
   Exit Sub
End If
If Grid0.TextMatrix(9, 1) = "" Then
   MsgBox "Debe Indicar Contador de Reposicion", vbCritical + vbDefaultButton1, "Sistema F8"
   Screen.MousePointer = 0
   Exit Sub
End If
   
If Trim(Grid0.TextMatrix(4, 1)) <> "" And Trim(Grid0.TextMatrix(2, 1)) <> "" And Trim(Grid0.TextMatrix(3, 1)) <> "" Then
    If FuncValidNumY(DTPicker1.Value, Grid0.TextMatrix(2, 1), Grid0.TextMatrix(3, 1), Grid0.TextMatrix(4, 1)) Then
       Grid1.Enabled = True
       VF_ExisteTerminaY = True
    Else
       Grid0.TextMatrix(4, 1) = FuncBuscaNumSecY(DTPicker1.Value, Grid0.TextMatrix(2, 1), Grid0.TextMatrix(3, 1))
       VF_ExisteTerminaY = False
       Grid1.Enabled = True
    End If
    Call SubDefineDetalleMonto
    Command1.Enabled = True
End If
 Command3.Enabled = False
Screen.MousePointer = 0
End Sub

Private Sub DTPicker1_LostFocus()
    If CDate(Format(DTPicker1.Value, "dd-mm-yyyy")) >= CDate(LeeFechaServidor) Then
       MsgBox "Error,  para este d�a ( " + CStr(DTPicker1.Value) + " ) no se puede generar un Z ", vbCritical + vbDefaultButton1, "Sistema F8"
       DTPicker1.Value = FormVariable.DTPicker1.Value
       
       DTPicker1.SetFocus
    End If
End Sub

Private Sub Form_Load()


   Call definegrid
   Call definegrid1
  
   

End Sub

Function FuncValidNumY(ByVal vfecha As String, ByVal VLocal As String, ByVal vterminal As String, ByVal vcierrey As String) As Boolean
Dim tipoTerm  As String
Dim Vl_String As String
Set Consulta_cmp = CreateObject("ADODB.Recordset")

On Error GoTo salir
With Consulta_cmp
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With


sq = "      Select count(*) "
sq = sq & " From   vta_" & Flg_Pais$ & "libvta l, vta_" & Flg_Pais$ & "zzz r  ,vta_" & Flg_Pais$ & "termstaty t"
sq = sq & " where  l.vta_tiporeg     = 'Y'"
sq = sq & "   and  l.vta_fecha_venta = to_date('" & Format(vfecha, VgFormatoFechaWhere) & "','" & VgFormatoFechaWhere & "') "
sq = sq & "   and  l.vta_local       =  " & VLocal
sq = sq & "   and  l.vta_terminal    =  " & vterminal
sq = sq & "   and  l.vta_estado      = 'A'   "
sq = sq & "   and  l.vta_techkey     = r.rec_techkey  "
sq = sq & "   and  l.vta_fecha_venta =  t.ter_fecha   "
sq = sq & "   and  l.vta_local       = t.ter_local    "
sq = sq & "   and  l.vta_terminal    = t.ter_terminal "
sq = sq & "   and  l.vta_secuencia   = t.ter_cierrey "
sq = sq & "   and    l.vta_secuencia   = " & vcierrey
Call Consulta_cmp.Open(sq)

If Not Consulta_cmp.EOF Then
    If Consulta_cmp.Fields(0) = 0 Then
       FuncValidNumY = False
    Else
       FuncValidNumY = True
    End If
Else
    FuncValidNumY = False
    
End If

 
Set Consulta_cmp.ActiveConnection = Nothing
Exit Function

salir:
    FuncValidNumY = False
    Set Consulta_cmp.ActiveConnection = Nothing
Exit Function


End Function

Function FuncBuscaNumSecY(ByVal vfecha As String, ByVal VLocal As String, ByVal vterminal As String) As Integer
Dim tipoTerm  As String
Dim Vl_String As String
Set BuscaNumSec = CreateObject("ADODB.Recordset")

On Error GoTo salir
With BuscaNumSec
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With


sq = "      Select decode(max(l.vta_secuencia) ,null,0 ,max(l.vta_secuencia))    "
sq = sq & " From   vta_" & Flg_Pais$ & "libvta l, vta_" & Flg_Pais$ & "zzz r  ,vta_" & Flg_Pais$ & "termstaty t"
sq = sq & " where  l.vta_tiporeg     = 'Y'"
sq = sq & "   and  l.vta_fecha_venta = to_date('" & Format(vfecha, VgFormatoFechaWhere) & "','" & VgFormatoFechaWhere & "') "
sq = sq & "   and  l.vta_local       =  " & VLocal
sq = sq & "   and  l.vta_terminal    =  " & vterminal
sq = sq & "   and  l.vta_estado      = 'A'"
sq = sq & "   and  l.vta_techkey     = r.rec_techkey"
sq = sq & "   and  l.vta_fecha_venta =  t.ter_fecha"
sq = sq & "   and  l.vta_local       = t.ter_local"
sq = sq & "   and  l.vta_terminal    = t.ter_terminal"
'sq = sq & "   and    l.vta_secuencia   = " & vcirrey
Call BuscaNumSec.Open(sq)

If Not BuscaNumSec.EOF Then
    FuncBuscaNumSecY = BuscaNumSec.Fields(0) + 1
Else
    FuncBuscaNumSecY = 1
End If

 
Set BuscaNumSec.ActiveConnection = Nothing
Exit Function

salir:
     FuncBuscaNumSecY = -1
    Set BuscaNumSec.ActiveConnection = Nothing
Exit Function


End Function

Function FuncBuscaValorCampo(ByVal vCampo As String, ByVal vfecha As String, ByVal VLocal As String, ByVal vterminal As String, ByVal vtipo As String, ByVal vcierrey As String) As Double
Dim tipoTerm  As String
Dim Vl_String As String
Set BuscaNumSec = CreateObject("ADODB.Recordset")
FuncBuscaValorCampo = 0
On Error GoTo salir
With BuscaNumSec
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With
If VF_ExisteTerminaY And vtipo = "Y" Then
   tipoTerm = "Y"
Else
   tipoTerm = ""
End If
'
sq = "      Select decode(sum( " & vCampo & "),null,0,sum( " & vCampo & "))"
sq = sq & " From   vta_" & Flg_Pais$ & "libvta l, vta_" & Flg_Pais$ & "zzz r  ,vta_" & Flg_Pais$ & "termstat" & tipoTerm & " t"
sq = sq & " where  l.vta_tiporeg     =  '" & vtipo & "'"
sq = sq & "   and  l.vta_fecha_venta = to_date('" & Format(vfecha, VgFormatoFechaWhere) & "','" & VgFormatoFechaWhere & "') "
sq = sq & "   and  l.vta_local       =  " & VLocal
sq = sq & "   and  l.vta_terminal    =  " & vterminal
sq = sq & "   and  l.vta_estado      = 'A'"
sq = sq & "   and  l.vta_techkey     = r.rec_techkey"
sq = sq & "   and  l.vta_fecha_venta = t.ter_fecha"
sq = sq & "   and  l.vta_local       = t.ter_local"
sq = sq & "   and  l.vta_terminal    = t.ter_terminal"
If vtipo = "Y" Then
   
End If
If VF_ExisteTerminaY And vtipo = "Y" Then
    sq = sq & "   and    l.vta_secuencia   = t.ter_cierrey  "
    sq = sq & "   and    l.vta_secuencia   <> " & vcierrey
End If
Call BuscaNumSec.Open(sq)

While Not BuscaNumSec.EOF
    FuncBuscaValorCampo = FuncBuscaValorCampo + BuscaNumSec.Fields(0)
    BuscaNumSec.MoveNext
Wend
 
Set BuscaNumSec.ActiveConnection = Nothing
Exit Function

salir:
    MsgBox "Error en la lectura de informaci�n", vbCritical + vbDefaultButton1, "Sistema F8"
    FuncBuscaValorCampo = -1
    Set BuscaNumSec.ActiveConnection = Nothing
Exit Function


End Function
Function FuncValorDelCampo(ByVal vCampo As String, ByVal vfecha As String, ByVal VLocal As String, ByVal vterminal As String, ByVal vtipo As String, ByVal vcierrey As String) As Double
Dim tipoTerm  As String
Dim Vl_String As String
Set ValorDelCampo = CreateObject("ADODB.Recordset")
FuncValorDelCampo = 0
On Error GoTo salir
With ValorDelCampo
    .ActiveConnection = Ado_Conn
    .CursorLocation = adUseClient
    .CursorType = adOpenForwardOnly
    .LockType = adLockReadOnly
End With
If VF_ExisteTerminaY And vtipo = "Y" Then
   tipoTerm = "Y"
Else
   tipoTerm = ""
End If
'
sq = "      Select decode(sum( " & vCampo & "),null,0,sum( " & vCampo & "))"
sq = sq & " From   vta_" & Flg_Pais$ & "libvta l, vta_" & Flg_Pais$ & "zzz r  ,vta_" & Flg_Pais$ & "termstat" & tipoTerm & " t"
sq = sq & " where  l.vta_tiporeg     =  '" & vtipo & "'"
sq = sq & "   and  l.vta_fecha_venta = to_date('" & Format(vfecha, VgFormatoFechaWhere) & "','" & VgFormatoFechaWhere & "') "
sq = sq & "   and  l.vta_local       =  " & VLocal
sq = sq & "   and  l.vta_terminal    =  " & vterminal
sq = sq & "   and  l.vta_estado      = 'A'"
sq = sq & "   and  l.vta_techkey     = r.rec_techkey"
sq = sq & "   and  l.vta_fecha_venta = t.ter_fecha"
sq = sq & "   and  l.vta_local       = t.ter_local"
sq = sq & "   and  l.vta_terminal    = t.ter_terminal"
 
If vtipo = "Y" Then
    sq = sq & "   and    l.vta_secuencia   = t.ter_cierrey  "
    sq = sq & "   and    l.vta_secuencia   =  " & vcierrey
End If
 
Call ValorDelCampo.Open(sq)

While Not ValorDelCampo.EOF
    FuncValorDelCampo = FuncValorDelCampo + ValorDelCampo.Fields(0)
    ValorDelCampo.MoveNext
Wend
 
Set ValorDelCampo.ActiveConnection = Nothing
Exit Function

salir:
    MsgBox "Error en la lectura de informaci�n", vbCritical + vbDefaultButton1, "Sistema F8"
    FuncValorDelCampo = -1
    Set ValorDelCampo.ActiveConnection = Nothing
Exit Function


End Function

Private Sub Grid0_KeyPress(KeyAscii As Integer)
Dim FIL, KOL As Integer
Dim Filasel, COLuSel As Integer
FIL = Grid0.RowSel
KOL = Grid0.ColSel
If Command3.Enabled = False Then
   Grid1.Clear
   Call definegrid1
   Grid1.Enabled = True
   Command3.Enabled = True
End If
If KOL = 0 Or (FIL = 5 And KOL = 1) Then
   Exit Sub
End If
 
If KeyAscii = 8 Then
   If Len(Grid0.Text) > 0 Then
      'Grid0.Text = Left(Grid0.Text, Len(Grid0.Text) - 1)
      Grid0.TextMatrix(FIL, KOL) = Left(Grid0.TextMatrix(FIL, KOL), Len(Grid0.TextMatrix(FIL, KOL)) - 1)
   End If
Else
   If (KeyAscii < 48 Or KeyAscii > 58) Then
      KeyAscii = 0
   Else
   Grid0.TextMatrix(FIL, KOL) = Grid0.TextMatrix(FIL, KOL) + Chr(KeyAscii)
     ' Grid0.Text = Grid0.Text + Chr(KeyAscii)
   End If
End If
   
End Sub

Private Sub Grid1_KeyPress(KeyAscii As Integer)
Dim FIL, KOL As Integer
Dim filsele, colsele As Integer
Dim valordif, valor, SumaVenta As Double
Dim indice As Integer
'43 -- 47
   FIL = Grid1.row
   KOL = Grid1.col
   filsele = Grid1.RowSel
   colsele = Grid1.ColSel
   kol2 = 2
   If KOL <> 1 Then Exit Sub
   If colsele <> 1 Then Exit Sub
   If Trim(Grid1.TextMatrix(filsele, (colsele - 1))) = "" Then Exit Sub
   
   'Grid1.TextMatrix(filsele, colsele) = Replace(Grid1.TextMatrix(filsele, colsele), ".", "")
   
   
   If Flg_Pais$ = "ARG" Or Flg_Pais$ = "SOAR" Or Flg_Pais$ = "SOUY" Or Flg_Pais$ = "HTPE" Then
       If Trim(Grid1.TextMatrix(filsele, (2))) <> 0 Then Exit Sub
 '      If filsele = 3 Then Exit Sub
       If Trim(Grid1.TextMatrix(filsele, (6))) = "" Then
          MsgBox "Error en la informaci�n, no se puede seguir ingresando ", vbCritical + vbDefaultButton1, "Sistema F8"
          Exit Sub
       End If
       negativo = 1
       FIL = Grid1.row
       KOL = Grid1.col
       If KOL = 1 Then
            If IIf(Trim(Grid1.TextMatrix(FIL, KOL)) = "", "0", Grid1.TextMatrix(FIL, KOL)) = CStr(Format(0, gFormat)) Then
               Grid1.TextMatrix(FIL, KOL) = IIf(KeyAscii = 46, "0", "")
            End If
       End If
          
       Grid1.col = KOL
       
       If InStr(Grid1.TextMatrix(FIL, KOL), ",") > 0 And KeyAscii = 46 Then
          KeyAscii = 0
       End If
        negativo = 1
       If KeyAscii < 48 Or KeyAscii > 58 Then
          If KeyAscii = 45 Then
            negativo = -1
            KeyAscii = 0
          ElseIf KeyAscii = 46 Or KeyAscii = 8 Then
          Else
            KeyAscii = 0
          End If
          
       End If
       If KeyAscii <> 0 Then
          numeroInicial = Grid1.TextMatrix(FIL, KOL)
          Grid1.TextMatrix(FIL, KOL) = ValidaIngresoNumrosDecimales_grd(Grid1.TextMatrix(FIL, KOL), KeyAscii)
       End If
       Grid1.TextMatrix(FIL, KOL) = ValidaLargoDecimales_grd(Grid1.TextMatrix(FIL, KOL), Val(gDecimal))
       If Trim(Grid1.TextMatrix(FIL, KOL)) <> "0" And Trim(Grid1.TextMatrix(FIL, KOL)) <> Format(0, gFormat) And Trim(Grid1.TextMatrix(FIL, KOL)) <> "" And Right(Grid1.TextMatrix(FIL, KOL), 1) <> "," Then
            If negativo = -1 Then
                 negativo = -1
                 Grid1.TextMatrix(FIL, KOL) = CDbl(Grid1.TextMatrix(FIL, KOL)) * negativo
            End If
       End If
          numeroConvalor = Grid1.TextMatrix(filsele, (6))
          Grid1.TextMatrix(filsele, (6)) = ((CDbl(Trim(Grid1.TextMatrix(filsele, (4)))) - CDbl(Trim(Grid1.TextMatrix(filsele, (5))))) - CDbl(IIf(Trim(Grid1.TextMatrix(FIL, KOL)) = "", "0", Grid1.TextMatrix(FIL, KOL))))
          Grid1.TextMatrix(filsele, (6)) = Format(Grid1.TextMatrix(filsele, (6)), gFormat)
          valordif = Format((CDbl(Trim(Grid1.TextMatrix(filsele, (4)))) - CDbl(Trim(Grid1.TextMatrix(filsele, (5))))), gFormat)
           X = IIf(Trim(Grid1.TextMatrix(FIL, KOL)) = "", "0", Grid1.TextMatrix(FIL, KOL))
          valor = Format(CDbl(IIf(Trim(Grid1.TextMatrix(FIL, KOL)) = "", "0", Grid1.TextMatrix(FIL, KOL))), gFormat)
          If CDbl(Trim(Grid1.TextMatrix(filsele, (4)))) < 0 Then
             If (CDbl(valor)) < (CDbl(valordif)) Then
                Exit Sub
             End If
          End If
          
         If Grid1.Text = "" Then
            Grid1.Text = Format(0, gFormat)
         End If
            
          Select Case Flg_Pais$
          Case "ARG"

  'forma de pago  CHEQUES =DIA+FECHA
            Grid1.TextMatrix(24, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(25, 1)) = "", "0", Trim(Grid1.TextMatrix(25, 1)))) + (CDbl(IIf(Trim(Grid1.TextMatrix(26, 1)) = "", "0", Trim(Grid1.TextMatrix(26, 1)))))
            Grid1.TextMatrix(24, 1) = Format((Grid1.TextMatrix(24, 1)), gFormat)
            'OTROS INGRESOS Y EGRESOS cobros CHEQUES=FECHA+DIA
            Grid1.TextMatrix(46, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(47, 1)) = "", "0", Trim(Grid1.TextMatrix(47, 1)))) + (CDbl(IIf(Trim(Grid1.TextMatrix(48, 1)) = "", "0", Trim(Grid1.TextMatrix(48, 1)))))
            Grid1.TextMatrix(46, 1) = Format((Grid1.TextMatrix(46, 1)), gFormat)
            'otros ingresos viajes CHEQUES = DIA
            Grid1.TextMatrix(55, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(56, 1)) = "", "0", Trim(Grid1.TextMatrix(56, 1)))) + (CDbl(IIf(Trim(Grid1.TextMatrix(57, 1)) = "", "0", Trim(Grid1.TextMatrix(57, 1)))))
            Grid1.TextMatrix(55, 1) = Format((Grid1.TextMatrix(55, 1)), gFormat)

            'TOTAL VENTAS =TICKET C. F.+TICKET FAC. A+TICKET FAC. B+FACTURA A+FACTURA B +NOTA CREDITO A + NOTA CREDITO B
             indice = 18
            Vl_TotalVenta = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 14, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 14, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 13, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 13, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 12, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 12, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, 1))))
            Vl_TotalVenta = Vl_TotalVenta + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, 1))))
            
            Grid1.TextMatrix(indice, 1) = Format(Vl_TotalVenta, gFormat)
            Grid1.TextMatrix(indice, 6) = CDbl(IIf(Trim(Grid1.TextMatrix(indice, 1)) = "", "0", Trim(Grid1.TextMatrix(indice, 1)))) - CDbl(IIf(Trim(Grid1.TextMatrix(indice, 4)) = "", "0", Trim(Grid1.TextMatrix(indice, 4))))
            
            ' totalesTotal TARJETA BANCARIA
            indice = 89
            'American Express
            Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, 1))))
            'Azul
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, 1))))
            'Cabal
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 3, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 3, 1))))
            'Cordobesa
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 4, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 4, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 5, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 5, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 6, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 6, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 7, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 7, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 8, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 8, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 9, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 9, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 10, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 10, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 11, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 11, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 12, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 12, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 13, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 13, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 14, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 14, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 15, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 15, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 16, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 16, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 17, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 17, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 18, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 18, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 19, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 19, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 20, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 20, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 21, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 21, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 22, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 22, 1))))
            ' Otras Tarjeta credito
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 23, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 23, 1))))
            Grid1.TextMatrix(89, 1) = Format((Vl_FormaPago), gFormat)
            
            'otra forma de pago  TARJETA BANCARIA

            Grid1.TextMatrix(37, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(89, 1)) = "", "0", Trim(Grid1.TextMatrix(89, 1)))) - (CDbl(IIf(Trim(Grid1.TextMatrix(58, 1)) = "", "0", Trim(Grid1.TextMatrix(58, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(49, 1)) = "", "0", Trim(Grid1.TextMatrix(49, 1)))))
            Grid1.TextMatrix(37, 1) = Format((Grid1.TextMatrix(37, 1)), gFormat)
              
            'TOTAL forma de pagos
            indice = 39
            Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 17, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, 1)) = "", "0", Trim(Grid1.TextMatrix(113, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, 1)) = "", "0", Trim(Grid1.TextMatrix(114, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, 1)) = "", "0", Trim(Grid1.TextMatrix(115, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, 1)) = "", "0", Trim(Grid1.TextMatrix(116, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, 1)) = "", "0", Trim(Grid1.TextMatrix(117, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, 1)) = "", "0", Trim(Grid1.TextMatrix(140, 1))))

            Grid1.TextMatrix(indice, 1) = Format(Vl_FormaPago, gFormat)
            Grid1.TextMatrix(indice, 6) = CDbl(IIf(Trim(Grid1.TextMatrix(indice, 1)) = "", "0", Trim(Grid1.TextMatrix(indice, 1)))) - CDbl(IIf(Trim(Grid1.TextMatrix(indice, 4)) = "", "0", Trim(Grid1.TextMatrix(indice, 4))))
            
            'TOTAL COBROS 1
            
            Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(58, 1)) = "", "0", Trim(Grid1.TextMatrix(58, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(42, 1)) = "", "0", Trim(Grid1.TextMatrix(42, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(43, 1)) = "", "0", Trim(Grid1.TextMatrix(43, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(44, 1)) = "", "0", Trim(Grid1.TextMatrix(44, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(45, 1)) = "", "0", Trim(Grid1.TextMatrix(45, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(46, 1)) = "", "0", Trim(Grid1.TextMatrix(46, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(49, 1)) = "", "0", Trim(Grid1.TextMatrix(49, 1))))
            'Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(58, 1)) = "", "0", Trim(Grid1.TextMatrix(58, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(51, 1)) = "", "0", Trim(Grid1.TextMatrix(51, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(52, 1)) = "", "0", Trim(Grid1.TextMatrix(52, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(53, 1)) = "", "0", Trim(Grid1.TextMatrix(53, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(54, 1)) = "", "0", Trim(Grid1.TextMatrix(54, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(55, 1)) = "", "0", Trim(Grid1.TextMatrix(55, 1))))
            Grid1.TextMatrix(59, 1) = Format(Vl_FormaPago, gFormat)
                
            ' TOTAL AVANCE  CMR =  AVANCE  CMR + SUPER AVAN. CMR +REV. SUPER AVAN.CMR
            indice = 60
            Grid1.TextMatrix(indice, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 3, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 3, 1))))
            Grid1.TextMatrix(indice, 1) = Format((Grid1.TextMatrix(indice, 1)), gFormat)
            
            'TOTAL EN PESOS  VUELTO
            indice = 68
            Grid1.TextMatrix(indice, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, 1))))
            Grid1.TextMatrix(indice, 1) = Format((Grid1.TextMatrix(indice, 1)), gFormat)
            
            'TOTALES-----------------------------------------------------------------------------------------------------------------------------------------------
            'EFECTIVO PESOS
            Grid1.TextMatrix(74, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(21, 1)) = "", "0", Trim(Grid1.TextMatrix(21, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(42, 1)) = "", "0", Trim(Grid1.TextMatrix(42, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(51, 1)) = "", "0", Trim(Grid1.TextMatrix(51, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(60, 1)) = "", "0", Trim(Grid1.TextMatrix(60, 1))))
            Grid1.TextMatrix(74, 1) = Format((Grid1.TextMatrix(74, 1)), gFormat)
            'EFECTIVO EUROS
            Grid1.TextMatrix(75, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(22, 1)) = "", "0", Trim(Grid1.TextMatrix(22, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(43, 1)) = "", "0", Trim(Grid1.TextMatrix(43, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(52, 1)) = "", "0", Trim(Grid1.TextMatrix(52, 1))))
            Grid1.TextMatrix(75, 1) = Format((Grid1.TextMatrix(75, 1)), gFormat)
            'EFECTIVO DOLAR
            Grid1.TextMatrix(76, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(23, 1)) = "", "0", Trim(Grid1.TextMatrix(23, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(44, 1)) = "", "0", Trim(Grid1.TextMatrix(44, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(53, 1)) = "", "0", Trim(Grid1.TextMatrix(53, 1))))
            Grid1.TextMatrix(76, 1) = Format((Grid1.TextMatrix(76, 1)), gFormat)
            'TARJETAS CMR
            Grid1.TextMatrix(77, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(28, 1)) = "", "0", Trim(Grid1.TextMatrix(28, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(45, 1)) = "", "0", Trim(Grid1.TextMatrix(45, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(54, 1)) = "", "0", Trim(Grid1.TextMatrix(54, 1))))
            Grid1.TextMatrix(77, 1) = Format((Grid1.TextMatrix(77, 1)), gFormat)
            
             'CUENTA CORRIENTE
            Grid1.TextMatrix(78, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(29, 1)) = "", "0", Trim(Grid1.TextMatrix(29, 1))))
            Grid1.TextMatrix(78, 1) = Format((Grid1.TextMatrix(78, 1)), gFormat)
            'VALE DE CREDITO
            Grid1.TextMatrix(79, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(30, 1)) = "", "0", Trim(Grid1.TextMatrix(30, 1))))
            Grid1.TextMatrix(79, 1) = Format((Grid1.TextMatrix(79, 1)), gFormat)
            'TRAVELLERS CHECKS
            Grid1.TextMatrix(80, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(31, 1)) = "", "0", Trim(Grid1.TextMatrix(31, 1))))
            Grid1.TextMatrix(80, 1) = Format((Grid1.TextMatrix(80, 1)), gFormat)
            'MEMBERSHIP REWARDS
            Grid1.TextMatrix(81, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(32, 1)) = "", "0", Trim(Grid1.TextMatrix(32, 1))))
            Grid1.TextMatrix(81, 1) = Format((Grid1.TextMatrix(81, 1)), gFormat)
            'BLUE REWARDS
            Grid1.TextMatrix(82, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(33, 1)) = "", "0", Trim(Grid1.TextMatrix(33, 1))))
            Grid1.TextMatrix(82, 1) = Format((Grid1.TextMatrix(82, 1)), gFormat)
            'TICKET CANASTA
            Grid1.TextMatrix(83, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(34, 1)) = "", "0", Trim(Grid1.TextMatrix(34, 1))))
            Grid1.TextMatrix(83, 1) = Format((Grid1.TextMatrix(83, 1)), gFormat)
            'TICKET UNIFORME
            Grid1.TextMatrix(84, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(35, 1)) = "", "0", Trim(Grid1.TextMatrix(35, 1))))
            Grid1.TextMatrix(84, 1) = Format((Grid1.TextMatrix(84, 1)), gFormat)
            'POSNET
            Grid1.TextMatrix(85, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(36, 1)) = "", "0", Trim(Grid1.TextMatrix(36, 1))))
            Grid1.TextMatrix(85, 1) = Format((Grid1.TextMatrix(85, 1)), gFormat)
            
             'CHEQUES
            Grid1.TextMatrix(86, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(24, 1)) = "", "0", Trim(Grid1.TextMatrix(24, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(46, 1)) = "", "0", Trim(Grid1.TextMatrix(46, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(55, 1)) = "", "0", Trim(Grid1.TextMatrix(55, 1))))
            Grid1.TextMatrix(86, 1) = Format((Grid1.TextMatrix(86, 1)), gFormat)
           'CHEQUES DIA
            Grid1.TextMatrix(87, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(25, 1)) = "", "0", Trim(Grid1.TextMatrix(25, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(47, 1)) = "", "0", Trim(Grid1.TextMatrix(47, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(56, 1)) = "", "0", Trim(Grid1.TextMatrix(56, 1))))
            Grid1.TextMatrix(87, 1) = Format((Grid1.TextMatrix(87, 1)), gFormat)
           'CHEQUES FECHA
            Grid1.TextMatrix(88, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(26, 1)) = "", "0", Trim(Grid1.TextMatrix(26, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(48, 1)) = "", "0", Trim(Grid1.TextMatrix(48, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(57, 1)) = "", "0", Trim(Grid1.TextMatrix(57, 1))))
            Grid1.TextMatrix(88, 1) = Format((Grid1.TextMatrix(88, 1)), gFormat)
                   
             'TARJETA BANCARIA
            Grid1.TextMatrix(89, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(37, 1)) = "", "0", Trim(Grid1.TextMatrix(37, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(49, 1)) = "", "0", Trim(Grid1.TextMatrix(49, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(58, 1)) = "", "0", Trim(Grid1.TextMatrix(58, 1))))
            Grid1.TextMatrix(89, 1) = Format((Grid1.TextMatrix(89, 1)), gFormat)
            
            'total NC CREDITO PROMO
            Vl_FormaPago = 0: indice = 117
            'Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice, 1)) = "", "0", Trim(Grid1.TextMatrix(indice, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 1, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 1, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 2, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 2, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 3, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 3, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 4, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 4, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 5, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 5, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 6, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 6, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 7, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 7, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 8, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 8, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 9, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 9, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 10, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 10, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 11, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 11, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 12, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 12, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 13, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 13, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 14, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 14, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 15, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 15, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 16, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 16, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 17, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 17, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 18, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 18, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 19, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 19, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 20, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 20, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 21, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 21, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 22, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 22, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice + 23, 1)) = "", "0", Trim(Grid1.TextMatrix(indice + 23, 1))))
            Grid1.TextMatrix(indice, 1) = Format(Vl_FormaPago, gFormat)
  
'
'            'forma de pago  CHEQUES
'            Grid1.TextMatrix(17, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(18, 1)) = "", "0", Trim(Grid1.TextMatrix(18, 1)))) + (CDbl(IIf(Trim(Grid1.TextMatrix(19, 1)) = "", "0", Trim(Grid1.TextMatrix(19, 1)))))
'            Grid1.TextMatrix(17, 1) = Format((Grid1.TextMatrix(17, 1)), gFormat)
'            'otros ingresos cobros CHEQUES
'            Grid1.TextMatrix(39, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(40, 1)) = "", "0", Trim(Grid1.TextMatrix(40, 1)))) + (CDbl(IIf(Trim(Grid1.TextMatrix(41, 1)) = "", "0", Trim(Grid1.TextMatrix(41, 1)))))
'            Grid1.TextMatrix(39, 1) = Format((Grid1.TextMatrix(39, 1)), gFormat)
'            'otros ingresos viajes CHEQUES
'            Grid1.TextMatrix(48, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(49, 1)) = "", "0", Trim(Grid1.TextMatrix(49, 1)))) + (CDbl(IIf(Trim(Grid1.TextMatrix(50, 1)) = "", "0", Trim(Grid1.TextMatrix(50, 1)))))
'            Grid1.TextMatrix(48, 1) = Format((Grid1.TextMatrix(48, 1)), gFormat)
'
'            'TOTAL VENTAS =TICKET C. F.+TICKET FAC. A+TICKET FAC. B+FACTURA A+FACTURA B +NOTA CREDITO A + NOTA CREDITO B
'            Grid1.TextMatrix(11, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(4, 1)) = "", "0", Trim(Grid1.TextMatrix(4, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(5, 1)) = "", "0", Trim(Grid1.TextMatrix(5, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(6, 1)) = "", "0", Trim(Grid1.TextMatrix(6, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(7, 1)) = "", "0", Trim(Grid1.TextMatrix(7, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(8, 1)) = "", "0", Trim(Grid1.TextMatrix(8, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(9, 1)) = "", "0", Trim(Grid1.TextMatrix(9, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(10, 1)) = "", "0", Trim(Grid1.TextMatrix(10, 1))))
'            Grid1.TextMatrix(11, 1) = Format((Grid1.TextMatrix(11, 1)), gFormat)
'
'            ' totalesTotal TARJETA BANCARIA
'
'            Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(91, 1)) = "", "0", Trim(Grid1.TextMatrix(91, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(92, 1)) = "", "0", Trim(Grid1.TextMatrix(92, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(93, 1)) = "", "0", Trim(Grid1.TextMatrix(93, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(94, 1)) = "", "0", Trim(Grid1.TextMatrix(94, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(95, 1)) = "", "0", Trim(Grid1.TextMatrix(95, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(96, 1)) = "", "0", Trim(Grid1.TextMatrix(96, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(97, 1)) = "", "0", Trim(Grid1.TextMatrix(97, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(98, 1)) = "", "0", Trim(Grid1.TextMatrix(98, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(99, 1)) = "", "0", Trim(Grid1.TextMatrix(99, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(81, 1)) = "", "0", Trim(Grid1.TextMatrix(81, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(82, 1)) = "", "0", Trim(Grid1.TextMatrix(82, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(83, 1)) = "", "0", Trim(Grid1.TextMatrix(83, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(84, 1)) = "", "0", Trim(Grid1.TextMatrix(84, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(85, 1)) = "", "0", Trim(Grid1.TextMatrix(85, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(86, 1)) = "", "0", Trim(Grid1.TextMatrix(86, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(87, 1)) = "", "0", Trim(Grid1.TextMatrix(87, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(88, 1)) = "", "0", Trim(Grid1.TextMatrix(88, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(89, 1)) = "", "0", Trim(Grid1.TextMatrix(89, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(90, 1)) = "", "0", Trim(Grid1.TextMatrix(90, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(100, 1)) = "", "0", Trim(Grid1.TextMatrix(100, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(101, 1)) = "", "0", Trim(Grid1.TextMatrix(101, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(102, 1)) = "", "0", Trim(Grid1.TextMatrix(102, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(103, 1)) = "", "0", Trim(Grid1.TextMatrix(103, 1))))
'            Grid1.TextMatrix(80, 1) = Format((Vl_FormaPago), gFormat)
'            'otra forma de pago  TARJETA BANCARIA
'
'            Grid1.TextMatrix(30, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(80, 1)) = "", "0", Trim(Grid1.TextMatrix(80, 1)))) - (CDbl(IIf(Trim(Grid1.TextMatrix(51, 1)) = "", "0", Trim(Grid1.TextMatrix(51, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(42, 1)) = "", "0", Trim(Grid1.TextMatrix(42, 1)))))
'             Grid1.TextMatrix(30, 1) = Format((Grid1.TextMatrix(30, 1)), gFormat)
'
'
'
'
'
'            'TOTAL forma de pagos
'            Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(14, 1)) = "", "0", Trim(Grid1.TextMatrix(14, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(15, 1)) = "", "0", Trim(Grid1.TextMatrix(15, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(16, 1)) = "", "0", Trim(Grid1.TextMatrix(16, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(17, 1)) = "", "0", Trim(Grid1.TextMatrix(17, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(21, 1)) = "", "0", Trim(Grid1.TextMatrix(21, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(22, 1)) = "", "0", Trim(Grid1.TextMatrix(22, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(23, 1)) = "", "0", Trim(Grid1.TextMatrix(23, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(24, 1)) = "", "0", Trim(Grid1.TextMatrix(24, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(25, 1)) = "", "0", Trim(Grid1.TextMatrix(25, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(26, 1)) = "", "0", Trim(Grid1.TextMatrix(26, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(27, 1)) = "", "0", Trim(Grid1.TextMatrix(27, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(28, 1)) = "", "0", Trim(Grid1.TextMatrix(28, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(29, 1)) = "", "0", Trim(Grid1.TextMatrix(29, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(30, 1)) = "", "0", Trim(Grid1.TextMatrix(30, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(31, 1)) = "", "0", Trim(Grid1.TextMatrix(31, 1))))
'            Grid1.TextMatrix(32, 1) = Format(Vl_FormaPago, gFormat)
'
'            'TOTAL COBROS 1
'
'            Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(51, 1)) = "", "0", Trim(Grid1.TextMatrix(51, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(35, 1)) = "", "0", Trim(Grid1.TextMatrix(35, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(36, 1)) = "", "0", Trim(Grid1.TextMatrix(36, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(37, 1)) = "", "0", Trim(Grid1.TextMatrix(37, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(38, 1)) = "", "0", Trim(Grid1.TextMatrix(38, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(39, 1)) = "", "0", Trim(Grid1.TextMatrix(39, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(42, 1)) = "", "0", Trim(Grid1.TextMatrix(42, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(43, 1)) = "", "0", Trim(Grid1.TextMatrix(43, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(44, 1)) = "", "0", Trim(Grid1.TextMatrix(44, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(45, 1)) = "", "0", Trim(Grid1.TextMatrix(45, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(46, 1)) = "", "0", Trim(Grid1.TextMatrix(46, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(47, 1)) = "", "0", Trim(Grid1.TextMatrix(47, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(48, 1)) = "", "0", Trim(Grid1.TextMatrix(48, 1))))
'            Grid1.TextMatrix(52, 1) = Format(Vl_FormaPago, gFormat)
'
'            'TOTAL EN PESOS  VUELTO
'            Grid1.TextMatrix(59, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(56, 1)) = "", "0", Trim(Grid1.TextMatrix(56, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(57, 1)) = "", "0", Trim(Grid1.TextMatrix(57, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(58, 1)) = "", "0", Trim(Grid1.TextMatrix(58, 1))))
'            Grid1.TextMatrix(59, 1) = Format((Grid1.TextMatrix(59, 1)), gFormat)
'
'            'TOTALES-----------------------------------------------------------------------------------------------------------------------------------------------
'            'EFECTIVO PESOS
'            Grid1.TextMatrix(65, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(14, 1)) = "", "0", Trim(Grid1.TextMatrix(14, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(35, 1)) = "", "0", Trim(Grid1.TextMatrix(35, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(44, 1)) = "", "0", Trim(Grid1.TextMatrix(44, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(54, 1)) = "", "0", Trim(Grid1.TextMatrix(54, 1))))
'            Grid1.TextMatrix(65, 1) = Format((Grid1.TextMatrix(65, 1)), gFormat)
'            'EFECTIVO EUROS
'            Grid1.TextMatrix(66, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(15, 1)) = "", "0", Trim(Grid1.TextMatrix(15, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(36, 1)) = "", "0", Trim(Grid1.TextMatrix(36, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(45, 1)) = "", "0", Trim(Grid1.TextMatrix(45, 1))))
'            Grid1.TextMatrix(66, 1) = Format((Grid1.TextMatrix(66, 1)), gFormat)
'            'EFECTIVO DOLAR
'            Grid1.TextMatrix(67, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(16, 1)) = "", "0", Trim(Grid1.TextMatrix(16, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(37, 1)) = "", "0", Trim(Grid1.TextMatrix(37, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(46, 1)) = "", "0", Trim(Grid1.TextMatrix(46, 1))))
'            Grid1.TextMatrix(67, 1) = Format((Grid1.TextMatrix(67, 1)), gFormat)
'            'TARJETAS CMR
'            Grid1.TextMatrix(68, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(21, 1)) = "", "0", Trim(Grid1.TextMatrix(21, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(38, 1)) = "", "0", Trim(Grid1.TextMatrix(38, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(47, 1)) = "", "0", Trim(Grid1.TextMatrix(47, 1))))
'            Grid1.TextMatrix(68, 1) = Format((Grid1.TextMatrix(68, 1)), gFormat)
'
'
'             'CUENTA CORRIENTE
'            Grid1.TextMatrix(69, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(22, 1)) = "", "0", Trim(Grid1.TextMatrix(22, 1))))
'            Grid1.TextMatrix(69, 1) = Format((Grid1.TextMatrix(69, 1)), gFormat)
'            'VALE DE CREDITO
'            Grid1.TextMatrix(70, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(23, 1)) = "", "0", Trim(Grid1.TextMatrix(23, 1))))
'            Grid1.TextMatrix(70, 1) = Format((Grid1.TextMatrix(70, 1)), gFormat)
'            'TRAVELLERS CHECKS
'            Grid1.TextMatrix(71, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(24, 1)) = "", "0", Trim(Grid1.TextMatrix(24, 1))))
'            Grid1.TextMatrix(71, 1) = Format((Grid1.TextMatrix(71, 1)), gFormat)
'            'MEMBERSHIP REWARDS
'            Grid1.TextMatrix(72, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(25, 1)) = "", "0", Trim(Grid1.TextMatrix(25, 1))))
'            Grid1.TextMatrix(72, 1) = Format((Grid1.TextMatrix(72, 1)), gFormat)
'            'BLUE REWARDS
'            Grid1.TextMatrix(73, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(26, 1)) = "", "0", Trim(Grid1.TextMatrix(26, 1))))
'            Grid1.TextMatrix(73, 1) = Format((Grid1.TextMatrix(73, 1)), gFormat)
'            'TICKET CANASTA
'            Grid1.TextMatrix(74, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(27, 1)) = "", "0", Trim(Grid1.TextMatrix(27, 1))))
'            Grid1.TextMatrix(74, 1) = Format((Grid1.TextMatrix(74, 1)), gFormat)
'            'TICKET UNIFORME
'            Grid1.TextMatrix(75, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(28, 1)) = "", "0", Trim(Grid1.TextMatrix(28, 1))))
'            Grid1.TextMatrix(75, 1) = Format((Grid1.TextMatrix(75, 1)), gFormat)
'            'POSNET
'            Grid1.TextMatrix(76, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(29, 1)) = "", "0", Trim(Grid1.TextMatrix(29, 1))))
'            Grid1.TextMatrix(76, 1) = Format((Grid1.TextMatrix(76, 1)), gFormat)
'
'             'CHEQUES
'            Grid1.TextMatrix(77, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(17, 1)) = "", "0", Trim(Grid1.TextMatrix(17, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(39, 1)) = "", "0", Trim(Grid1.TextMatrix(39, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(48, 1)) = "", "0", Trim(Grid1.TextMatrix(48, 1))))
'            Grid1.TextMatrix(77, 1) = Format((Grid1.TextMatrix(77, 1)), gFormat)
'           'CHEQUES DIA
'            Grid1.TextMatrix(78, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(18, 1)) = "", "0", Trim(Grid1.TextMatrix(18, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(40, 1)) = "", "0", Trim(Grid1.TextMatrix(40, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(49, 1)) = "", "0", Trim(Grid1.TextMatrix(49, 1))))
'            Grid1.TextMatrix(78, 1) = Format((Grid1.TextMatrix(78, 1)), gFormat)
'           'CHEQUES FECHA
'            Grid1.TextMatrix(79, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(19, 1)) = "", "0", Trim(Grid1.TextMatrix(19, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(41, 1)) = "", "0", Trim(Grid1.TextMatrix(41, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(50, 1)) = "", "0", Trim(Grid1.TextMatrix(50, 1))))
'            Grid1.TextMatrix(79, 1) = Format((Grid1.TextMatrix(79, 1)), gFormat)
'
'             'TARJETA BANCARIA
'            Grid1.TextMatrix(80, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(42, 1)) = "", "0", Trim(Grid1.TextMatrix(42, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(51, 1)) = "", "0", Trim(Grid1.TextMatrix(51, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(30, 1)) = "", "0", Trim(Grid1.TextMatrix(30, 1))))
'            Grid1.TextMatrix(80, 1) = Format((Grid1.TextMatrix(80, 1)), gFormat)
''            Grid1.TextMatrix(71, 1) = CDbl(IIf(Trim(Grid1.TextMatrix(37, 1)) = "", "0", Trim(Grid1.TextMatrix(37, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(44, 1)) = "", "0", Trim(Grid1.TextMatrix(44, 1)))) + CDbl(IIf(Trim(Grid1.TextMatrix(28, 1)) = "", "0", Trim(Grid1.TextMatrix(28, 1))))
''            Grid1.TextMatrix(71, 1) = Format((Grid1.TextMatrix(71, 1)), gFormat)
''
'
'
'
'            'total NC CREDITO PROMO
'            Vl_FormaPago = 0: i = 104
'            '  Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(95, 1)) = "", "0", Trim(Grid1.TextMatrix(95, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(105, 1)) = "", "0", Trim(Grid1.TextMatrix(105, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(106, 1)) = "", "0", Trim(Grid1.TextMatrix(106, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(107, 1)) = "", "0", Trim(Grid1.TextMatrix(107, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(108, 1)) = "", "0", Trim(Grid1.TextMatrix(108, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(109, 1)) = "", "0", Trim(Grid1.TextMatrix(109, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(110, 1)) = "", "0", Trim(Grid1.TextMatrix(110, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(111, 1)) = "", "0", Trim(Grid1.TextMatrix(111, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(112, 1)) = "", "0", Trim(Grid1.TextMatrix(112, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, 1)) = "", "0", Trim(Grid1.TextMatrix(113, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, 1)) = "", "0", Trim(Grid1.TextMatrix(114, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, 1)) = "", "0", Trim(Grid1.TextMatrix(115, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, 1)) = "", "0", Trim(Grid1.TextMatrix(116, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, 1)) = "", "0", Trim(Grid1.TextMatrix(117, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(118, 1)) = "", "0", Trim(Grid1.TextMatrix(118, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(119, 1)) = "", "0", Trim(Grid1.TextMatrix(119, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(120, 1)) = "", "0", Trim(Grid1.TextMatrix(120, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(121, 1)) = "", "0", Trim(Grid1.TextMatrix(121, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(122, 1)) = "", "0", Trim(Grid1.TextMatrix(122, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(123, 1)) = "", "0", Trim(Grid1.TextMatrix(123, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(124, 1)) = "", "0", Trim(Grid1.TextMatrix(124, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(125, 1)) = "", "0", Trim(Grid1.TextMatrix(125, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(126, 1)) = "", "0", Trim(Grid1.TextMatrix(126, 1))))
'            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(127, 1)) = "", "0", Trim(Grid1.TextMatrix(127, 1))))
'
'
'            Grid1.TextMatrix(i, 1) = Format(Vl_FormaPago, gFormat)

            indice = 39
            Vl_FormaPago = CDbl(IIf(Trim(Grid1.TextMatrix(indice - 18, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 18, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 17, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 17, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 16, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 16, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 15, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 15, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 11, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 11, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 10, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 10, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 9, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 9, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 8, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 8, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 7, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 7, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 6, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 6, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 5, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 5, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 4, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 4, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 3, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 3, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 2, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 2, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(indice - 1, 1)) = "", "0", Trim(Grid1.TextMatrix(indice - 1, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(113, 1)) = "", "0", Trim(Grid1.TextMatrix(113, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(114, 1)) = "", "0", Trim(Grid1.TextMatrix(114, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(115, 1)) = "", "0", Trim(Grid1.TextMatrix(115, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(116, 1)) = "", "0", Trim(Grid1.TextMatrix(116, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(117, 1)) = "", "0", Trim(Grid1.TextMatrix(117, 1))))
            Vl_FormaPago = Vl_FormaPago + CDbl(IIf(Trim(Grid1.TextMatrix(140, 1)) = "", "0", Trim(Grid1.TextMatrix(140, 1))))
            

            Grid1.TextMatrix(indice, 1) = Format(Vl_FormaPago, gFormat)
            
            If Grid1.TextMatrix(Grid1.RowSel, 1) = "" Then
                Grid1.TextMatrix(Grid1.RowSel, 1) = Format(0, gFormat)
            End If
         
         Case "SOAR", "SOUY"

                           
            Grid1.TextMatrix(11, 1) = CDbl(Grid1.TextMatrix(9, 1)) + CDbl(Grid1.TextMatrix(8, 1)) + CDbl(Grid1.TextMatrix(7, 1)) + CDbl(Grid1.TextMatrix(6, 1)) + CDbl(Grid1.TextMatrix(5, 1)) + CDbl(Grid1.TextMatrix(4, 1))
            Grid1.TextMatrix(11, 1) = Format(Grid1.TextMatrix(11, 1), gFormat)
            
            Grid1.TextMatrix(16, 1) = CDbl(Grid1.TextMatrix(17, 1)) + CDbl(Grid1.TextMatrix(20, 1))
            Grid1.TextMatrix(16, 1) = Format(Grid1.TextMatrix(16, 1), gFormat)
                 
            Grid1.TextMatrix(25, 1) = CDbl(Grid1.TextMatrix(26, 1)) + CDbl(Grid1.TextMatrix(27, 1))
            Grid1.TextMatrix(25, 1) = Format(Grid1.TextMatrix(25, 1), gFormat)
      
            Grid1.TextMatrix(51, 1) = CDbl(Grid1.TextMatrix(52, 1)) + CDbl(Grid1.TextMatrix(53, 1))
            Grid1.TextMatrix(51, 1) = Format(Grid1.TextMatrix(51, 1), gFormat)
      
            Grid1.TextMatrix(55, 1) = CDbl(Grid1.TextMatrix(56, 1)) + CDbl(Grid1.TextMatrix(57, 1)) + CDbl(Grid1.TextMatrix(58, 1))
            Grid1.TextMatrix(55, 1) = Format(Grid1.TextMatrix(55, 1), gFormat)
      
      
            Grid1.TextMatrix(66, 1) = CDbl(Grid1.TextMatrix(14, 1)) + CDbl(Grid1.TextMatrix(45, 1)) + CDbl(Grid1.TextMatrix(60, 1))
            Grid1.TextMatrix(66, 1) = Format(Grid1.TextMatrix(66, 1), gFormat)
      
            Grid1.TextMatrix(67, 1) = CDbl(Grid1.TextMatrix(15, 1)) + CDbl(Grid1.TextMatrix(46, 1)) + CDbl(Grid1.TextMatrix(61, 1))
            Grid1.TextMatrix(67, 1) = Format(Grid1.TextMatrix(67, 1), gFormat)
      
            Grid1.TextMatrix(68, 1) = CDbl(Grid1.TextMatrix(16, 1)) + CDbl(Grid1.TextMatrix(47, 1)) + CDbl(Grid1.TextMatrix(62, 1))
            Grid1.TextMatrix(68, 1) = Format(Grid1.TextMatrix(68, 1), gFormat)
     
            Grid1.TextMatrix(69, 1) = CDbl(Grid1.TextMatrix(23, 1)) + CDbl(Grid1.TextMatrix(48, 1)) + CDbl(Grid1.TextMatrix(63, 1))
            Grid1.TextMatrix(69, 1) = Format(Grid1.TextMatrix(69, 1), gFormat)
      
            Grid1.TextMatrix(70, 1) = CDbl(Grid1.TextMatrix(24, 1)) + CDbl(Grid1.TextMatrix(49, 1)) + CDbl(Grid1.TextMatrix(64, 1))
            Grid1.TextMatrix(70, 1) = Format(Grid1.TextMatrix(70, 1), gFormat)
      
            Grid1.TextMatrix(71, 1) = CDbl(Grid1.TextMatrix(29, 1)) + CDbl(Grid1.TextMatrix(50, 1))
            Grid1.TextMatrix(71, 1) = Format(Grid1.TextMatrix(71, 1), gFormat)
        
            Grid1.TextMatrix(72, 1) = CDbl(Grid1.TextMatrix(30, 1))
            Grid1.TextMatrix(72, 1) = Format(Grid1.TextMatrix(72, 1), gFormat)
            ''
            Grid1.TextMatrix(73, 1) = CDbl(Grid1.TextMatrix(38, 1))
            Grid1.TextMatrix(73, 1) = Format(Grid1.TextMatrix(73, 1), gFormat)
            '''
            Grid1.TextMatrix(74, 1) = CDbl(Grid1.TextMatrix(75, 1)) + CDbl(Grid1.TextMatrix(76, 1))
            Grid1.TextMatrix(74, 1) = Format(Grid1.TextMatrix(74, 1), gFormat)
      
            Grid1.TextMatrix(75, 1) = CDbl(Grid1.TextMatrix(26, 1)) + CDbl(Grid1.TextMatrix(52, 1))
            Grid1.TextMatrix(75, 1) = Format(Grid1.TextMatrix(75, 1), gFormat)
      
            Grid1.TextMatrix(76, 1) = CDbl(Grid1.TextMatrix(27, 1)) + CDbl(Grid1.TextMatrix(53, 1))
            Grid1.TextMatrix(76, 1) = Format(Grid1.TextMatrix(76, 1), gFormat)
      
            Grid1.TextMatrix(77, 1) = CDbl(Grid1.TextMatrix(39, 1)) + CDbl(Grid1.TextMatrix(54, 1))
            Grid1.TextMatrix(77, 1) = Format(Grid1.TextMatrix(77, 1), gFormat)
      
            Grid1.TextMatrix(78, 1) = CDbl(Grid1.TextMatrix(40, 1))
            Grid1.TextMatrix(78, 1) = Format(Grid1.TextMatrix(78, 1), gFormat)
      
            Grid1.TextMatrix(79, 1) = CDbl(Grid1.TextMatrix(41, 1))
            Grid1.TextMatrix(79, 1) = Format(Grid1.TextMatrix(79, 1), gFormat)
      
            Grid1.TextMatrix(80, 1) = CDbl(Grid1.TextMatrix(35, 1))
            Grid1.TextMatrix(80, 1) = Format(Grid1.TextMatrix(80, 1), gFormat)
      
         Case "HTPE"
 
               If Grid1.Text <> "" Then 'Grid1.Text = "0"
               'xintec 01-04-2019
                'Grid1.TextMatrix(45, 1) = CDbl(Grid1.TextMatrix(46, 1)) + CDbl(Grid1.TextMatrix(47, 1)) + CDbl(Grid1.TextMatrix(48, 1)) + CDbl(Grid1.TextMatrix(49, 1)) + CDbl(Grid1.TextMatrix(50, 1))
                'Grid1.TextMatrix(45, 1) = Format((Grid1.TextMatrix(45, 1)), gFormat)
                Grid1.TextMatrix(46, 1) = CDbl(Grid1.TextMatrix(47, 1)) + CDbl(Grid1.TextMatrix(48, 1)) + CDbl(Grid1.TextMatrix(49, 1)) + CDbl(Grid1.TextMatrix(50, 1)) + CDbl(Grid1.TextMatrix(51, 1))
                Grid1.TextMatrix(46, 1) = Format((Grid1.TextMatrix(46, 1)), gFormat)
                
                Grid1.TextMatrix(62, 1) = CDbl(Grid1.TextMatrix(63, 1)) + CDbl(Grid1.TextMatrix(64, 1))
                Grid1.TextMatrix(62, 1) = Format((Grid1.TextMatrix(62, 1)), gFormat)
                    
                 
               End If
         End Select
         
            Grid1.TextMatrix(filsele, (6)) = ((CDbl(Trim(Grid1.TextMatrix(filsele, (4)))) - CDbl(Trim(Grid1.TextMatrix(filsele, (5))))) - CDbl(IIf(Trim(Grid1.TextMatrix(FIL, KOL)) = "", "0", Grid1.TextMatrix(FIL, KOL))))
            Grid1.TextMatrix(filsele, (6)) = Format(Grid1.TextMatrix(filsele, (6)), gFormat)
            valordif = Format((CDbl(Trim(Grid1.TextMatrix(filsele, (4)))) - CDbl(Trim(Grid1.TextMatrix(filsele, (5))))), gFormat)
            X = IIf(Trim(Grid1.TextMatrix(FIL, KOL)) = "", "0", Grid1.TextMatrix(FIL, KOL))
            valor = Format(CDbl(IIf(Trim(Grid1.TextMatrix(FIL, KOL)) = "", "0", Grid1.TextMatrix(FIL, KOL))), gFormat)
 
 Else
            If KOL <> 1 Then Exit Sub
            If Trim(Grid1.TextMatrix(FIL, (KOL - 1))) = "" Then Exit Sub
            If Trim(Grid1.TextMatrix(FIL, (2))) <> 0 Then Exit Sub
            
            If InStr(Grid1.TextMatrix(FIL, KOL), ",") > 0 And KeyAscii = 46 Then
                   KeyAscii = 0
            End If
            If KeyAscii = 8 Then
               If Len(Grid1.Text) > 0 Then
                  Grid1.Text = Left(Grid1.Text, Len(Grid1.Text) - 1)
                  If Grid1.Text = "" Then Grid1.Text = "0"
                  If Len(Grid1.Text) = 0 Then
                     Grid1.Text = 0
                  Else
                    If Len(Grid1.Text) = 1 And Grid1.Text = "-" Then
                       Grid1.Text = 0
                    End If
                  End If
               End If
            Else
               If KeyAscii = 45 Then
                  Grid1.Text = -1 * CDbl(Grid1.Text)
                   KeyAscii = 0
               ElseIf (KeyAscii < 48 Or KeyAscii > 58) Then
                    KeyAscii = 0
               End If
            End If
            If KeyAscii <> 0 Then
                   numeroInicial = Grid1.TextMatrix(FIL, KOL)
                   Grid1.TextMatrix(FIL, KOL) = ValidaIngresoNumrosDecimales_grd(Grid1.TextMatrix(FIL, KOL), KeyAscii)
            End If
            Grid1.TextMatrix(FIL, KOL) = ValidaLargoDecimales_grd(Grid1.TextMatrix(FIL, KOL), Val(gDecimal))
            If Trim(Grid1.TextMatrix(FIL, KOL)) <> "0" And Trim(Grid1.TextMatrix(FIL, KOL)) <> Format(0, gFormat) And Trim(Grid1.TextMatrix(FIL, KOL)) <> "" And Right(Grid1.TextMatrix(FIL, KOL), 1) <> "," Then
               If negativo = -1 Then
                          negativo = -1
                          Grid1.TextMatrix(FIL, KOL) = CDbl(Grid1.TextMatrix(FIL, KOL)) * negativo
              End If
            End If
            numeroConvalor = Grid1.TextMatrix(filsele, (6))
            
            Grid1.TextMatrix(filsele, (6)) = ((CDbl(Trim(Grid1.TextMatrix(filsele, (4)))) - CDbl(Trim(Grid1.TextMatrix(filsele, (5))))) - CDbl(IIf(Trim(Grid1.TextMatrix(FIL, KOL)) = "", "0", Grid1.TextMatrix(FIL, KOL))))
            Grid1.TextMatrix(filsele, (6)) = Format(Grid1.TextMatrix(filsele, (6)), gFormat)
            valordif = Format((CDbl(Trim(Grid1.TextMatrix(filsele, (4)))) - CDbl(Trim(Grid1.TextMatrix(filsele, (5))))), gFormat)
            X = IIf(Trim(Grid1.TextMatrix(FIL, KOL)) = "", "0", Grid1.TextMatrix(FIL, KOL))
            valor = Format(CDbl(IIf(Trim(Grid1.TextMatrix(FIL, KOL)) = "", "0", Grid1.TextMatrix(FIL, KOL))), gFormat)
            
            Select Case Flg_Pais$
            Case "FACO"
                   Grid1.TextMatrix(5, 1) = CDbl(IIf(Grid1.TextMatrix(2, 1) = "", "0", Grid1.TextMatrix(2, 1))) + CDbl(IIf(Grid1.TextMatrix(3, 1) = "", "0", Grid1.TextMatrix(3, 1))) + CDbl(IIf(Grid1.TextMatrix(4, 1) = "", "0", Grid1.TextMatrix(4, 1)))
                   Grid1.TextMatrix(5, 1) = Format(Grid1.TextMatrix(5, 1), gFormat)
 '                  Grid1.TextMatrix(12, 1) = CDbl(IIf(Grid1.TextMatrix(14, 1) = "", "0", Grid1.TextMatrix(14, 1))) + CDbl(IIf(Grid1.TextMatrix(13, 1) = "", "0", Grid1.TextMatrix(13, 1)))
 '                  Grid1.TextMatrix(12, 1) = Format(Grid1.TextMatrix(12, 1), gFormat)
                   Grid1.TextMatrix(29, 1) = CDbl(Grid1.TextMatrix(30, 1)) + CDbl(Grid1.TextMatrix(31, 1)) + CDbl(Grid1.TextMatrix(32, 1)) + CDbl(Grid1.TextMatrix(33, 1)) + CDbl(Grid1.TextMatrix(34, 1))
                   Grid1.TextMatrix(29, 1) = Format(Grid1.TextMatrix(29, 1), gFormat)
         
                '   Grid1.TextMatrix(33, 1) = CDbl(IIf(Grid1.TextMatrix(36, 1) = "", "0", Grid1.TextMatrix(36, 1))) + CDbl(IIf(Grid1.TextMatrix(34, 1) = "", "0", Grid1.TextMatrix(34, 1))) + CDbl(IIf(Grid1.TextMatrix(35, 1) = "", "0", Grid1.TextMatrix(35, 1)))
                 '   Grid1.TextMatrix(33, 1) = Format(Grid1.TextMatrix(33, 1), gFormat) 'CDbl(IIf(Grid1.TextMatrix(33, 1) = "", "0", Grid1.TextMatrix(33, 1))) 'Format(Grid1.TextMatrix(32, 1), gFormat)
                   Grid1.TextMatrix(filsele, colsele) = Format(Grid1.TextMatrix(filsele, colsele), gFormat)

            Case "SFCL"
                If Trim(Grid1.Text) = "" Then Grid1.Text = "0"
                Grid1.Text = Format(Grid1.Text, gFormat)
                ' TOTALES venta
                Grid1.TextMatrix(7, 1) = CDbl(Grid1.TextMatrix(2, 1)) + CDbl(Grid1.TextMatrix(4, 1)) + CDbl(Grid1.TextMatrix(3, 1)) + CDbl(Grid1.TextMatrix(5, 1)) + CDbl(Grid1.TextMatrix(6, 1))
                Grid1.TextMatrix(7, 1) = Format(Grid1.TextMatrix(7, 1), gFormat)
                'ACT. GIFT CARD
                
                '***************************************
                'Grid1.TextMatrix(37, 1) = CDbl(Grid1.TextMatrix(38, 1)) + CDbl(Grid1.TextMatrix(39, 1)) + CDbl(Grid1.TextMatrix(40, 1)) + CDbl(Grid1.TextMatrix(41, 1)) + CDbl(Grid1.TextMatrix(42, 1))
                Grid1.TextMatrix(37, 1) = Format(Grid1.TextMatrix(37, 1), gFormat)
                '***************************************
                
                'REV ACT. GIFT CARD
              ' Grid1.TextMatrix(42, 1) = CDbl(Grid1.TextMatrix(43, 1)) + CDbl(Grid1.TextMatrix(44, 1)) '+ CDbl(Grid1.TextMatrix(45, 1))
              '  Grid1.TextMatrix(42, 1) = Format(Grid1.TextMatrix(42, 1), gFormat)
            End Select
End If
     
End Sub
Private Function revisa_grid() As Boolean
Dim valor, valorcero As Double
revisa_grid = True
If Flg_Pais$ = "ARG" Or Flg_Pais$ = "SOAR" Or Flg_Pais$ = "SOUY" Then
 If Trim(Grid1.TextMatrix(11, 1)) = "" Then
         MsgBox "El monto  : " & Trim(Grid1.TextMatrix(11, 0)) & " se encuentra con valor en cero, proceso abortado ", vbCritical + vbDefaultButton1, "Sistema F8"
          revisa_grid = Fsalse
           Exit Function
    End If
    
    If Trim(Grid1.TextMatrix(11, 1)) = "" And Grid1.TextMatrix(54, 1) = "" And Trim(Grid1.TextMatrix(56, 1)) = "" And Grid1.TextMatrix(59, 1) = "" And Trim(Grid1.TextMatrix(60, 1)) = "" Then
         MsgBox "Los monto Totales : " & Trim(Grid1.TextMatrix(11, 0)) & "," & Trim(Grid1.TextMatrix(54, 0)) & "," & Trim(Grid1.TextMatrix(56, 0)) & "," & Trim(Grid1.TextMatrix(59, 0)) & "," & Trim(Grid1.TextMatrix(60, 0)) & " se encuentra con valor en cero, proceso abortado ", vbCritical + vbDefaultButton1, "Sistema F8"
          revisa_grid = Fsalse
           Exit Function
    End If
End If
For i = 1 To Grid1.Rows - 1
    If Trim(Grid1.TextMatrix(i, 1)) = "" Then
       Grid1.TextMatrix(i, 1) = "0"
    End If
    If Val(Grid1.TextMatrix(i, 1)) = 0 Then
       If Trim(Grid1.TextMatrix(i, 1)) = "" Then
          Grid1.TextMatrix(i, 1) = Format(0, gFormat)
       End If
   End If

Next



End Function
'CK: 160531 Modificaciones F8 ARG
Private Function ObtenerEstadoZZZ() As String
    Dim sqEstado As String
    Set ConsultaEstado = CreateObject("ADODB.Recordset")
    With ConsultaEstado
        .ActiveConnection = Ado_Conn
        .CursorLocation = adUseClient
        .CursorType = adOpenForwardOnly
        .LockType = adLockReadOnly
   End With
    
    
    sqEstado = "select ter_estado " & _
    "From   vta_" & Flg_Pais$ & "termstat " & _
    "where  ter_fecha = to_date('" & Format(DTPicker1.Value, VgFormatoFechaWhere) & "','" & VgFormatoFechaWhere & "') " & _
    "and    ter_local = " & Grid0.TextMatrix(2, 1) & " " & _
    "and    ter_terminal = " & Grid0.TextMatrix(3, 1) & " "

    On Error GoTo oraerror
    Call ConsultaEstado.Open(sqEstado)
    
    If ConsultaEstado.RecordCount > 0 Then
        ObtenerEstadoZZZ = ConsultaEstado.Fields(0).Value
    Else
        ObtenerEstadoZZZ = "-1"
    End If
    
        
    Set ConsultaEstado.ActiveConnection = Nothing
    Exit Function
oraerror:
    ObtenerEstadoZZZ = "-1"
End Function

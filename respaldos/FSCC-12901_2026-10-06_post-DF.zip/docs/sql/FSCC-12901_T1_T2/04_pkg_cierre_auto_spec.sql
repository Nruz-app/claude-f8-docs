-- =====================================================================
-- FSCC-12901 T1 + T2 (carpeta consolidada) - Paso 04
-- Especificacion T2 PKG_F8_FACO_CIERRE_AUTO
-- Fuente: docs/sql/FSCC-12958/05_pkg_cierre_auto_spec.sql (mantener ambas copias iguales)
-- =====================================================================

-- =====================================================================
-- FSCC-12958 (HU-01-T2) Cierre de caja automatico - Falabella Colombia
-- 05 - Especificacion de PKG_F8_FACO_CIERRE_AUTO
--
-- Replica en PL/SQL la logica de cierre del exe F8 (VB6):
--   * cierre Y : Form3Y.CierraTerminal  (FTEPROD/Form3Y.frm:2801)
--   * cierre Z : Form3.CierraTerminal   (FTEPROD/Form3.frm:3439)
--   * diferencia real: FormateaDatos (Label70) + Modulo1.StrSumCompensado
-- y el flujo "Proceso 2 - Cierre de caja automatico" de FSCC-12901.
--
-- Puntos de entrada:
--   PRC_CIERRE_AUTOMATICO : proceso automatico (se agenda fuera del alcance).
--   PRC_CIERRE_RANGO      : boton "Cerrar Terminal" de Consultas de Cuadratura
--                           (Form43, Flg_Pais$ = "FACO"), ajuste FSCC-12901 DF-SCC.
-- =====================================================================

create or replace package PKG_F8_FACO_CIERRE_AUTO as

  c_usuario_def  constant varchar2(30) := 'PROC_CIERRE_AUTO';
  c_tipo_param   constant number       := 1502;

  -- Lee un parametro de VTA_FACOPARAM tipo 1502 (CA_ACTIVO, CA_VAL_CHEQ,
  -- CA_VAL_ZZZ, CA_VAL_USD, CA_DECIMAL, CA_DIAS, CA_SIN_SOBRE). Devuelve p_default si no existe.
  function fn_param (p_codigo  in varchar2,
                     p_default in varchar2) return varchar2;

  -- Diferencia Real (Label70 de la F8):
  --   p_cierrey informado -> cierre Y (como Form3Y)
  --   p_cierrey null      -> terminal-dia / Z (como Form3)
  -- Devuelve NULL si no hay libro de ventas (libvta) para esa caja.
  function fn_dif_real (p_fecha    in date,
                        p_local    in number,
                        p_terminal in number,
                        p_cierrey  in number default null) return number;

  -- Columnas "Dif. de Caja" y "Compensacion" de Consultas de Cuadratura (Form43).
  -- Mismo calculo que fn_dif_real: fn_dif_real = round(fn_dif_caja - round(fn_compensado)).
  -- fn_dif_caja devuelve NULL si no hay libro de ventas; fn_compensado sin redondear.
  function fn_dif_caja (p_fecha    in date,
                        p_local    in number,
                        p_terminal in number,
                        p_cierrey  in number default null) return number;

  function fn_compensado (p_fecha    in date,
                          p_local    in number,
                          p_terminal in number,
                          p_cierrey  in number default null) return number;

  -- ---------------------------------------------------------------
  -- Validaciones individuales (publicas para poder probarlas por separado).
  -- p_cierrey null = nivel Z / dia completo.
  -- ---------------------------------------------------------------

  -- RY-01 / RZ-01 Cheque a fecha: gestion de cheques tipo 1 vs tesoreria (dia).
  -- Devuelve el mensaje del exe si hay diferencia, null si cuadra.
  function fn_msg_cheque_fecha (p_fecha    in date,
                                p_local    in number,
                                p_terminal in number) return varchar2;

  -- RY-03 / RZ-03 TRUE si existe un concepto p_tipo (SN, AF, ND, FN, NP, BF, CR,
  -- CT, CA, DP) sin regularizar. CA se busca en VTA_FACOCARTAAVISO.
  -- (BOOLEAN: usable desde PL/SQL, no desde SELECT)
  function fn_concepto_pendiente (p_fecha    in date,
                                  p_local    in number,
                                  p_terminal in number,
                                  p_cierrey  in number,
                                  p_tipo     in varchar2) return boolean;

  -- RY-06 / RZ-08 Formula ZZZ: F7 - F6 - F5 - F4 - F3 - F2 - F1 (0 = cuadra).
  function fn_zzz (p_fecha    in date,
                   p_local    in number,
                   p_terminal in number,
                   p_cierrey  in number) return number;

  -- RZ-06 Z = suma de las Y. Mensaje con la glosa del primer campo distinto, o null.
  function fn_msg_z_suma_y (p_fecha    in date,
                            p_local    in number,
                            p_terminal in number) return varchar2;

  -- RZ-07 Todas las Y cerradas. Mensaje si hay Y abiertas o no hay Y, o null.
  function fn_msg_y_abiertas (p_fecha    in date,
                              p_local    in number,
                              p_terminal in number) return varchar2;

  -- RZ-09 Diferencia de dolares declarados vs Prosegur DOL (0 = cuadra).
  function fn_dif_dolares (p_fecha    in date,
                           p_local    in number,
                           p_terminal in number) return number;

  -- Validaciones de "Cerrar Terminal" de la Y (sin estado ni diferencia real,
  -- que el proceso evalua antes). o_regla null = todas OK.
  procedure pr_valida_y (p_fecha    in  date,
                         p_local    in  number,
                         p_terminal in  number,
                         p_cierrey  in  number,
                         o_regla    out varchar2,
                         o_mensaje  out varchar2);

  -- Validaciones de "Cerrar Terminal" de la Z (sin estado ni diferencia real).
  procedure pr_valida_z (p_fecha    in  date,
                         p_local    in  number,
                         p_terminal in  number,
                         o_regla    out varchar2,
                         o_mensaje  out varchar2);

  -- Proceso completo: recorre VTA_FACOV_CAJAS_CIERRE (cola pendiente + cajas sin
  -- sobres del mismo local-dia si CA_SIN_SOBRE = S), cierra las Y que
  -- quedan con diferencia real 0 y cumplen las validaciones y, si todas las Y
  -- de un terminal-dia quedaron cerradas, valida y cierra la Z.
  -- p_max_cajas: limite opcional de cierres Y a evaluar por ejecucion.
  procedure prc_cierre_automatico (p_usuario   in varchar2 default 'PROC_CIERRE_AUTO',
                                   p_max_cajas in number   default null);

  -- Cierre manual desde Consultas de Cuadratura (Form43, FACO). Mismas reglas
  -- RY/RZ y flags que el proceso automatico, sin T1 y sin depender de CA_ACTIVO.
  -- Universo: cierres Y abiertos (ter_estado <= 0) con libro de ventas en el
  -- rango de fechas de venta, local y terminal (0 = todos); luego las Z de esos
  -- terminal-dia. log_proceso = CC; ter_cerradopor = p_usuario (el analista).
  -- Fechas en texto yyyymmdd (patron de Form173).
  --   o_ejecucion   : numero de ejecucion en VTA_FACOLOG_CIERRE_AUTO
  --   o_cerradas    : cierres Y + Z cerrados
  --   o_no_cerradas : cierres Y + Z evaluados que no se cerraron
  procedure prc_cierre_rango (p_fecha_ini   in  varchar2,
                              p_fecha_fin   in  varchar2,
                              p_local       in  number,
                              p_terminal    in  number,
                              p_usuario     in  varchar2,
                              o_ejecucion   out number,
                              o_cerradas    out number,
                              o_no_cerradas out number);

end PKG_F8_FACO_CIERRE_AUTO;
/

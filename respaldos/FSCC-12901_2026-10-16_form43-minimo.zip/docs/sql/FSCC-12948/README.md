# FSCC-12948 - Rematch automatico depositaria Prosegur (scripts)

Indice y analisis del requerimiento: `docs/README_FSCC-12948.md`.

Estado: scripts 01 y 02 listos, **no ejecutados** (los ejecuta el usuario). Instalar con `@INSTALAR.sql` (01 + 02 + estado); antes `00_prechecks.sql`; para volver `99_rollback.sql`.

| Archivo | Contenido |
|---|---|
| `00_prechecks.sql` | SOLO LECTURA. Objetos y estado, cola por estado, duplicados en cola, cola sobre transacciones ya cuadradas (VALIDA = 1), pendientes sin cola con o sin venta POST, job del cron, log del package |
| `01_proc_transacc_depo_queue.sql` | SP del cron: antes de llamar al package revalida las condiciones del trigger (`VALIDA = 0`, barcode, VTA_TEMP_CAB tipo 53 local/terminal/fecha, VTA_TEMPESC corr 8) contra el VTA_IDTRX encolado; si no cumple, la fila queda PROCESADO con `OMITIDO -> ...` y no se llama al package |
| `02_trg_transacc_depo_queue.sql` | Trigger: no encola si ya hay fila PENDIENTE/PROCESANDO para la misma transaccion; cruza por `TRANSACTION_DATE` (fecha de venta) en vez de `ACCOUNTING_DATE` |
| `INSTALAR.sql` | `@01`, `@02` y consulta de estado (SP `VALID`, trigger `VALID`/`ENABLED`) |
| `99_rollback.sql` | Vuelve el SP y el trigger a la linea base de `ddl_actual_desarrollo/` |
| `ddl_actual_desarrollo/01_tabla_prosegur_transactions_queue.sql` | Tabla cola + indices + secuencia (DBMS_METADATA) |
| `ddl_actual_desarrollo/02_trg_transacc_depo_queue.sql` | Trigger AFTER INSERT ON VTA_TEMP_CAB |
| `ddl_actual_desarrollo/03_proc_transacc_depo_queue.sql` | Procedimiento del cron |
| `ddl_actual_desarrollo/04_f8_transacc_depo_pkg_spec.sql` | Spec de F8_TRANSACC_DEPO_PKG |
| `ddl_actual_desarrollo/05_f8_transacc_depo_pkg_body.sql` | Body de F8_TRANSACC_DEPO_PKG (EXISTE_VTA_TEMPESC) |

Nota: `01` y `02` usan `TRANSACTION_DATE` porque el POST graba en `VTA_TEMP_CAB.VTA_FECHA` la fecha de venta (verificado en test, 50 de 50 matches). El SP tambien pasa esa fecha al package. El package `F8_TRANSACC_DEPO_PKG` no cambia.

Checklist de prueba en test: `docs/README_FSCC-12948.md` seccion 9b.

ATENCION: `ddl_actual_desarrollo/` es la linea base tal como esta en INTRANETDE el 14-10-2026: sirve para comparar y para el rollback de futuros cambios. No se ejecuta.

Convenciones: sin prefijo de esquema, solo ASCII, compatible con Oracle 10.2. Cuando haya cambios, seguiran la numeracion `01..`, `99_rollback.sql`.

-- FSCC-12948 - Instalacion: SP PROC_TRANSACC_DEPO_QUEUE (01) y trigger TRG_TRANSACC_DEPO_QUEUE (02).
-- Ejecutar en SQL*Plus conectado como el dueno de las tablas, desde esta carpeta.
-- El package F8_TRANSACC_DEPO_PKG no cambia. Rollback: @99_rollback.sql
set echo on
@01_proc_transacc_depo_queue.sql
@02_trg_transacc_depo_queue.sql
set echo off
prompt == Estado de los objetos (deben quedar VALID / ENABLED)
select object_name, object_type, status from user_objects
 where object_name in ('PROC_TRANSACC_DEPO_QUEUE','TRG_TRANSACC_DEPO_QUEUE');
select trigger_name, status from user_triggers where trigger_name = 'TRG_TRANSACC_DEPO_QUEUE';

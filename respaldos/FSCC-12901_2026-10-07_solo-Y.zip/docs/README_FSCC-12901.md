# FSCC-12901: índice y bitácora del trabajo (Falabella Colombia)

Punto de entrada para retomar el análisis y desarrollo de la historia **FSCC-12901**: compensación automática de DI y cierre de caja automático en Colombia (`Flg_Pais$ = "FACO"`). Reúne qué se hizo, dónde está cada cosa, qué se decidió, qué se verificó en la base y qué falta.

Última actualización: **07-10-2026** (documentación actualizada: FACO solo cierre Y).

---

## 1. Requerimiento

| Ítem | Detalle |
|---|---|
| Historia | **FSCC-12901** [SCCFIN][F8] Compensación automática de Diferencia No Imputable dentro de un rango, Falabella Colombia (épica FSCC-12287) |
| T1 | **FSCC-12957** HU-01-T1: compensación automática de DI. Si −1.000 ≤ DR ≤ 20.000 (DR ≠ 0), registra una DI igual a la DR, con el mismo signo. No cierra cajas |
| T2 | **FSCC-12958** HU-01-T2: cierre de caja automático. Corre después de T1; cierra los **cierres Y** de la carga con DR = 0 que cumplen las validaciones de Cerrar Terminal. No compensa. **Colombia opera solo con cierre Y: la Z no se toca** (07-10) |
| Fuentes | `docs/Requeriemintos-FSCC-12901/`: subtareas `.doc` y diagramas BPMN (flujo general, proceso 1, proceso 2). El PDF de la historia estaba en Descargas. El Excel `DF-SCC-vf_Falabella CO (MEJORAS F8 y COMPENSACIONES MENORES).xlsx` y `PRD 3.xlsx` están en esa carpeta (agregados el 06-10) y **se analizaron el 06-10** (`FSCC-12901_Analisis.md` §3.13) |
| Doc. actualizada (07-10) | `docs/Requeriemintos-FSCC-12901/Doc-Actualizado/`: HU completa `FSCC-12901.doc` (ejecutar "al momento de la carga" en `Form133`, "Colombia opera con cierre Y", CA9 nuevo), subtareas sin cambios de texto, diagramas P1/P2 rediseñados y captura de `Form133`. Análisis en `FSCC-12901_Analisis.md` §3.14 |
| DF-SCC | Fila 12: Consultas de Cuadratura (`Form43`) debe mostrar las cajas sin movimiento (Dif. Real 0), como Chile, y cerrarlas, para **evitar el archivo "dataload" de cierre de cajas**. Fila 57: DI automática de −1.000 a 20.000 (= T1). Filas 34, 40, 46 y 52: fuera de alcance |

## 2. Estado

| Frente | Estado |
|---|---|
| Análisis del cierre manual de Colombia (VB6) | ✔ Completo |
| Análisis de la HU contra el código y la base | ✔ Completo |
| Documentos técnicos por subtarea (PDF) | ✔ T1 y T2 |
| **T2 implementado en base de datos** (tabla homóloga + trigger + paquete) | ✔ **Scripts listos y verificados contra la estructura de test. No compilados ni ejecutados** |
| **T1 implementado en base de datos** (`PKG_F8_FACO_COMPENSA_DI`, reutiliza cola, trigger, log y `fn_dif_real` de T2; T2 lo invoca primero) | ✔ **Scripts listos** en `docs/sql/FSCC-12957/`, verificados contra la estructura de test. No compilados ni ejecutados |
| **Flujo consolidado T1 + T2** (`docs/sql/FSCC-12901_T1_T2/`, con `INSTALAR.sql`) | ✔ Listo para instalar. Las 14 verificaciones previas dan lo esperado en test (07-10) |
| **Ajuste por DF-SCC y PRD 3** (cajas sin sobres, `Form43` FACO delega en la base, opción 1515) | ✔ Scripts de T1, T2 y la consolidada ajustados; `FTEPROD/Form43.frm` modificado (**no compilado**: no hay VB6 en el equipo). Ver §5c |
| **Reestructura "solo cierre Y"** (doc. actualizada 07-10) | ✔ Paquete de T2 sin Z (sin RZ, `pr_procesa_z`, `pr_valida_z`, `CA_VAL_USD`), `prc_cierre_rango` y `Form43` solo Y; `Form133` revisado (sin cambios). Ver §5d |
| **Estado congelado** | ✔ Manifiesto MD5 (`docs/MANIFIESTO_FSCC-12901.md5`) y respaldos ZIP `pre-pruebas`, `post-DF` y `solo-Y` (`docs/respaldos/`). Ver §10 |
| Instalación y pruebas en test | ⏳ Pendiente. **Ningún objeto creado en la base al 06-10-2026** |

## 3. Artefactos

| Archivo | Qué contiene |
|---|---|
| [`docs/GUIA_FSCC-12901_Flujo_y_cambios.pdf`](GUIA_FSCC-12901_Flujo_y_cambios.pdf) | **Guía del flujo completo**: mapa de piezas, recorrido de una carga paso a paso, reglas de T1/T2, parámetros, estados, front, instalación, consultas útiles y bitácora del trabajo. Fuente `docs/pdf/GUIA_FSCC-12901.html`. **Empezar por aquí para entender la solución** |
| [`docs/CC_ConsultaCuadratura_FACO.md`](CC_ConsultaCuadratura_FACO.md) | Pantalla "Consultas de Cuadratura" (`Form43`) en Colombia. Hallazgo: su botón **Cerrar Terminal no cierra nada en FACO** (B1–B11) |
| [`docs/CierreCaja_FACO_Reglas.md`](CierreCaja_FACO_Reglas.md) | **Especificación completa del cierre manual**: fórmula de la diferencia real con SQL; reglas RY-01..08 (Y, `Form3Y.CierraTerminal`) y RZ-01..10 (Z, `Form3.CierraTerminal`; **no aplican a FACO desde el 07-10**); mensajes; comportamientos D1–D12; diseño de procedimiento; matriz de pruebas |
| [`docs/FSCC-12901_Analisis.md`](FSCC-12901_Analisis.md) | Análisis de la HU: veredicto, criterios de aceptación contra lo existente, hallazgos §3.1–§3.14 (carga `Form133`, base de test, BPMN, DF-SCC, doc. actualizada y solo Y), preguntas P1–P14, propuesta técnica, casos T1–T18 y comentario para Jira |
| [`docs/FSCC-12901_consultas.sql`](FSCC-12901_consultas.sql) | Consultas de solo lectura usadas para cerrar pendientes (parámetros, doble conteo, paquete de Chile, DI); desde la 8 a la 15, las validaciones del ajuste DF-SCC (cargas, universo SIN_SOBRE, consulta de `Form43`, opción 1515, perfiles); 16–18, las del modelo solo Y (estados de Y y Z) |
| [`docs/FSCC-12957_T1_Compensacion_DI_automatica.pdf`](FSCC-12957_T1_Compensacion_DI_automatica.pdf) | Documento de T1 (18 págs.): alcance, diseño en base de datos y VB6, algoritmo, pruebas, decisiones y diagramas |
| [`docs/FSCC-12958_T2_Cierre_caja_automatico.pdf`](FSCC-12958_T2_Cierre_caja_automatico.pdf) | Documento de T2: incluye la §12 con el enfoque aprobado en base de datos |
| `docs/pdf/` | Fuentes HTML de los PDF (`estilo.css`, `img/`). Se regeneran con Edge headless (§8) |
| [`docs/sql/FSCC-12958/`](sql/FSCC-12958/README.md) | **Scripts de T2** (ver §5) |
| [`docs/sql/FSCC-12957/`](sql/FSCC-12957/README.md) | **Scripts de T1** (ver §5b) |
| [`docs/sql/FSCC-12901_T1_T2/`](sql/FSCC-12901_T1_T2/README.md) | **Flujo completo T1 + T2, listo para instalar**: objetos paso a paso (00–10, 99), `INSTALAR.sql` y README con el flujo, los objetos, los parámetros, las reglas, la operación y una matriz de 20 casos. **Es la carpeta que se instala**; las otras dos sirven para revisar cada subtarea por separado |
| [`docs/sql/FSCC-12901_POC/`](sql/FSCC-12901_POC/00_LEEME.md) | **POC con datos reales en desarrollo** (`INTRANETDE`): (A) 714 cierres Y reales de 2026 copiados de test con `02g` (solo lectura) → `02_datos_test.sql`; (B) día PRD 3 (28-08-2026) con los 486 sobres reales y cajas por escenario (P0–P7). Simula `Form133`, ejecuta T1 → T2 y compara esperado frente a obtenido; `98` reinicia y `99` limpia. Guía en `00_LEEME.html` |
| [`docs/MANUAL_Prueba_FSCC-12901_por_pantallas.pdf`](MANUAL_Prueba_FSCC-12901_por_pantallas.pdf) | **Manual de prueba por pantallas** (14 págs.): carga de 29 sobres reales (locales 6 y 13, PRD 3) por `Form133` → job (script 06) → resultado en F8 (cierre Y) y en `Form43`; 23 cajas con resultado esperado; checklist y problemas frecuentes. Fuente `docs/pdf/MANUAL_PRUEBA_FSCC-12901.html`; scripts y Excel en `docs/sql/FSCC-12901_POC/manual/` (`M1` preparar, `M2` resultados, `M9` limpiar) |
| `FTEPROD/Form43.frm` | **Front VB6** (Consultas de Cuadratura) con los bloques `'CK: FSCC-12901` para FACO (§5c). Respaldo previo: `FTEPROD/Form43.frm.bak_FSCC-12901` |
| `docs/pdf/img/DF-SCC_F8_*_CC.png` | Imágenes 6 y 7 del DF (Consultas de Cuadratura de Colombia y de Chile), citadas en la §12.5 del PDF de T2 |
| `docs/pdf/img/proceso1_T1_v2.png`, `proceso2_T2_v2.png`, `form133_carga.png` | Diagramas P1/P2 actualizados y captura de `Form133` (doc. del 07-10), en las §12.6 de los PDF |
| `CLAUDE.md` §5 y §9 | Referencias a estos documentos y convenciones de scripts |
| `docs/MANIFIESTO_FSCC-12901.md5` | Huellas MD5 de scripts y documentos, congeladas antes de las pruebas (§10) |
| `docs/respaldos/FSCC-12901_2026-10-0*_*.zip` | Respaldos `pre-pruebas`, `post-DF` y `solo-Y` (§10) |

## 4. Decisiones tomadas

| Fecha | Decisión | Motivo |
|---|---|---|
| 06-10 | T2 se resuelve **en Oracle**: tabla homóloga de `VTA_FACOPRD` + trigger `AFTER INSERT` + procedimiento ejecutado por un job externo | Pedido del usuario: desacoplarlo del exe |
| 06-10 | Validaciones que dependen del perfil (103 ZZZ, 109 dólares, exención del cheque a fecha para los perfiles 8/10/12) → **flags** en `VTA_FACOPARAM` tipo 1502 | Un proceso automático no tiene perfil |
| 06-10 | `ter_cerradopor = 'PROC_CIERRE_AUTO'` | Distinguirlo del `AUTOMATICO` existente (Autopago) |
| 06-10 | ~~La Z se cierra cuando todas sus Y están cerradas, con sus validaciones propias~~ (reemplazada el 07-10) | — |
| 06-10 | Fecha de cierre en `ter_notas` (sin cambios de estructura) | Las tablas de Colombia no tienen `ter_fechacierre` |
| 06-10 | Entregable: **solo scripts**, sin ejecutar en la base | Pedido del usuario |
| 06-10 | Scripts **sin prefijo de esquema**, en ASCII; el usuario de aplicación se pide con `accept` | Portabilidad entre esquemas y ambientes |
| 06-10 | Exponer las validaciones sueltas en la especificación del paquete | Poder probarlas por separado |
| 06-10 | T1 en un **paquete propio** (`PKG_F8_FACO_COMPENSA_DI`) que **T2 invoca al inicio** de `prc_cierre_automatico`; un solo job, en el orden T1 → T2 | Respeta el diagrama general y reutiliza la cola, el trigger, el log y `fn_dif_real` |
| 06-10 | Rango propio de T1: `CA_DI_MIN` = −1000 y `CA_DI_MAX` = 20000 (tipo 1502). No se toca 1500/1501 'DI' (DI manual, −500/20000) | No cambiar lo que el analista puede ingresar en `Form38` |
| 06-10 | DI manual previa en la Y: no se toca y queda para el analista (`DI_MANUAL_PREVIA`) | Una segunda DI con `mov_rol = 0` confundiría a `Form38` |
| 06-10 | DI automática: `mov_hechopor = 'PROC_DI_AUTO'`, glosa `'COMPENSACION AUTOMATICA DI'` en `VTA_FACOCOMPDES` | Distinguirla de T2 y de la DI manual en los informes |
| 06-10 | Interruptores independientes `CA_DI_ACTIVO` (T1) y `CA_ACTIVO` (T2); el log identifica el proceso con `log_proceso` | Poder correr cada subtarea por separado |
| 06-10 | DF-SCC: `Form43` en FACO **delega en la base**: sus columnas salen de `fn_dif_caja` / `fn_compensado` / `fn_dif_real` y "Cerrar Terminal" llama a `prc_cierre_rango` | Una sola lógica de cierre (la de T2) para el proceso automático y el analista |
| 06-10 | DF-SCC: **incluir las cajas sin sobres** del mismo local y fecha de venta de la carga (vista `VTA_FACOV_CAJAS_CIERRE`, interruptor `CA_SIN_SOBRE`) | Las cajas sin movimiento nunca entran a la cola del trigger |
| 06-10 | DF-SCC: **sin pantalla de resumen** nueva; el resultado se consulta por SQL en el log | Pedido del usuario |
| 06-10 | DF-SCC: filas 34, 40, 46 y 52 **solo se documentan** | Fuera de FSCC-12901 |
| 06-10 | `prc_cierre_rango` no ejecuta T1 ni depende de `CA_ACTIVO`; `ter_cerradopor` = usuario del analista; `log_proceso = 'CC'` | Es una acción manual, como el Cerrar Terminal de Chile |
| 06-10 | Opción 1515 de FACO se crea **deshabilitada** para todos los perfiles; negocio define a quién se habilita | No existía en `VTA_FACOMENU`; dar el permiso es decisión de negocio |
| 07-10 | **FACO solo cierre Y**: el proceso, `prc_cierre_rango` y `Form43` trabajan solo con `vta_FACOtermstaty`; la Z (`vta_FACOtermstat`) no se toca. Se eliminan las reglas RZ y `CA_VAL_USD` | Pedido del usuario; `Form3Y.CierraTerminal` solo cierra la Y y en test la Z de FACO no se gestiona (10.894 en −1, 6 cerradas desde el 24-08-2026) |
| 07-10 | Disparo: **se mantiene el job externo** (cola + trigger); `Form133` no llama al SP | Decisión del usuario, aunque la HU dice "al momento de la carga" (punto abierto con negocio) |
| 07-10 | **Sin resumen en pantalla**; se consulta el log por SQL | Decisión del usuario, aunque la HU pide "emitir un resumen" (punto abierto con negocio) |
| 07-10 | `Form133.AbrirTerminal` **no se toca** (sigue reabriendo la Z) | Decisión del usuario; una Y cerrada que recibe un sobre queda `YA_CERRADA` para el analista |

## 5. T2: objetos de base de datos (`docs/sql/FSCC-12958/`)

| Script | Objeto |
|---|---|
| `00_prechecks.sql` | 9 verificaciones de solo lectura; cada una indica el resultado esperado (sin la unicidad de `termstat` desde el 07-10) |
| `01_tabla_homologa.sql` | `VTA_FACOPRD_CIERRE` (cola) + `SEQ_VTA_FACOPRD_CIERRE` |
| `02_log.sql` | `VTA_FACOLOG_CIERRE_AUTO` + `SEQ_VTA_FACOLOG_CIERRE_AUTO` (`log_proceso` T1 / T2 / CC) |
| `03_parametros.sql` | `VTA_FACOPARAM` 1502: `CA_ACTIVO`=S, `CA_VAL_CHEQ`=S, `CA_VAL_ZZZ`=N, `CA_DECIMAL`=0, `CA_DIAS`=30, `CA_SIN_SOBRE`=S. Se cambian con `UPDATE`, sin recompilar |
| `03b_vista_cajas.sql` | Vista `VTA_FACOV_CAJAS_CIERRE`: universo común de T1 y T2 (COLA + SIN_SOBRE) |
| `03c_permiso_cc.sql` | Opción 1515 "Cerrar Terminal desde Consulta Cuadratura" en `VTA_FACOMENU` / `VTA_FACORELPERMEN`, deshabilitada |
| `04_trigger.sql` | `TRG_VTA_FACOPRD_CIERRE_AI` (F8 y DOL) |
| `05` / `06` | `PKG_F8_FACO_CIERRE_AUTO`: `prc_cierre_automatico` (job), `prc_cierre_rango` (`Form43`), `fn_dif_real`, `fn_dif_caja`, `fn_compensado` (las tres exigen la Y), `pr_valida_y`, `fn_param` y las validaciones sueltas de la Y (RY-01, RY-03, RY-06). Sin Z desde el 07-10 |
| `07_grants_sinonimos.sql` | Permisos (como dueño) y sinónimos (como DBA), incluida la vista. El usuario de `[CONNECT]` del exe también los necesita |
| `08_pruebas.sql` | Comparación de la DR con la F8, validaciones sueltas, conciliación del trigger, ejecución, vista, columnas de `Form43`, `prc_cierre_rango` y 24 casos |
| `99_rollback.sql` | Reabrir las Y de una ejecución y desinstalar (incluye vista, `CA_SIN_SOBRE` y opción 1515). Ya no reabre la Z |

**Instalación:** conectado como el **dueño** de las tablas `VTA_FACO*` (en test, `INTRANETTS`). Como el cuerpo de T2 llama a T1, se usa el **orden conjunto** del README de FSCC-12957.

## 5b. T1: objetos de base de datos (`docs/sql/FSCC-12957/`)

| Script | Objeto |
|---|---|
| `00_prechecks.sql` | 9 verificaciones de solo lectura (en test coinciden las 3–8; la 1 y la 9 se completan al instalar T2) |
| `01_ajuste_log.sql` | Agrega `LOG_PROCESO` al log (idempotente). La versión actual de `FSCC-12958/02_log.sql` ya la trae |
| `02_parametros.sql` | `CA_DI_ACTIVO`=S, `CA_DI_MIN`=−1000, `CA_DI_MAX`=20000 |
| `03` / `04` | `PKG_F8_FACO_COMPENSA_DI`: `prc_compensa_di` (entrada; T2 lo llama), `fn_evalua_caja` (simulación sin grabar), `fn_estado_di` |
| `05_grants_sinonimos.sql` | `EXECUTE` y sinónimo |
| `06_pruebas.sql` | Simulación de toda la cola, T1 solo, T1 + T2 y 14 casos (criterios de aceptación de FSCC-12901) |
| `99_rollback.sql` | Apagar T1 (recomendado: no afecta T2), revertir las DI de una ejecución o desinstalar |

**Cambios hechos en FSCC-12958 para integrar T1:**
- `02_log.sql`: columna `log_proceso`;
- `06_pkg_cierre_auto_body.sql`: llamada a T1 e interruptores independientes;
- `99_rollback.sql`: desinstalar T1 antes que T2;
- `README.md`: sección de integración.

**Ajuste DF-SCC:** `04_pkg_compensa_di_body.sql` recorre la vista `VTA_FACOV_CAJAS_CIERRE` (antes, la cola); `00`, `01` y `06` actualizados.

## 5c. Front VB6: `FTEPROD/Form43.frm` (Consultas de Cuadratura, solo FACO)

Ajuste pedido por el DF-SCC, fila 12. Cambios marcados con `'CK: FSCC-12901 - …` / `'CK: FSCC-12901 - FIN`; el código anterior queda comentado. El archivo sigue en Windows-1252 con CRLF y el código nuevo es ASCII. Respaldo: `Form43.frm.bak_FSCC-12901` (idéntico al original, MD5 `0e1bfd0c…`). **No se compiló.**

| # | Lugar | Cambio |
|---|---|---|
| B1 | `Form_Load` | FACO como Chile: combo Terminal visible; "Cerrar Terminal" solo con el permiso 1515 |
| B2 | `OptionInforme_Click`, `Case Else` | En FACO el botón ya no aparece sin permiso (antes se mostraba siempre: hallazgo B4 de `CC_ConsultaCuadratura_FACO.md`) |
| B3 | `Command2_Click` | FACO + informe "Terminal" → `SubBuscarOpcionFACO` |
| B4 | `SubBuscarOpcionFACO` (nuevo) | Cierres Y con libro de ventas en el rango, local y terminal (respeta `Combo3`); **sin filas Z desde el 07-10**; columnas con `fn_dif_caja`, `fn_compensado`, `fn_dif_real`. **Muestra todas las filas, incluidas las de Dif. Real 0** |
| B5 | `Command4_Click` | FACO sale de la rama `ARG/SFCL/FACO/HTPE` (línea original comentada) y llama a `CierreTerminalFACO` |
| B6 | `CierreTerminalFACO` (nuevo) | Confirmación → `ADODB.Command` → `BEGIN PKG_F8_FACO_CIERRE_AUTO.prc_cierre_rango(?,?,?,?,?,?,?,?); END;` (fechas `yyyymmdd`, local, terminal, `LOGINUSER`) → refresca la grilla → resumen "Cerrados / No cerrados / ejecución". Errores con `SystemMsg` + `frmLogOraError` |

Diff contra el respaldo: 267 líneas nuevas (277 el 06-10; el 07-10 se quitó la parte Z) y 2 líneas originales reemplazadas, que quedan comentadas. Otros países: sin cambios de comportamiento. Los informes "F8 General" y "Gral. Tesorería" de FACO no cambian.

**Despliegue del front:** primero la base (si no, la consulta de `Form43` en FACO falla con "Problemas de comunicación"), permisos del paso 09 para el usuario de `[CONNECT]` y la opción 1515 habilitada a los perfiles que defina negocio. Después, compilar `f8a.exe` y subir `Gversion` (`Módulo1.bas`) junto con `vta_parametros.vta_ultversion` de **todos** los países, porque el exe es único.

## 5d. Reestructura por la documentación actualizada (07-10-2026): FACO solo cierre Y

Detalle en `FSCC-12901_Analisis.md` §3.14 y en la §12.6 de los PDF.

| Capa | Cambio |
|---|---|
| `PKG_F8_FACO_CIERRE_AUTO` (`05`/`06`, copias `04`/`07`) | Se eliminan `pr_procesa_z`, `pr_procesa_terminales`, `pr_valida_z`, `fn_msg_z_suma_y` (RZ-06), `fn_msg_y_abiertas` (RZ-07), `fn_dif_dolares` (RZ-09) y el tipo `t_terminales`. `p_cierrey` es obligatorio en `fn_dif_real`, `fn_dif_caja` y `fn_compensado` (se quitó la rama "día completo/Z" de `pr_cuadratura`, `fn_concepto_pendiente` y `fn_zzz`). `prc_cierre_automatico` y `prc_cierre_rango` solo cierran Y; el log FIN informa "Y cerradas / Y no cerradas" |
| Parámetros | `CA_VAL_USD` eliminado (solo servía para RZ-09). El rollback lo sigue borrando por si quedó de una instalación anterior |
| Soporte | `00` sin unicidad de `termstat`; `VTA_PAINT_Z` se valida solo contra `libvta`/`zzz` (RY-06); `08`/`10` sin pruebas de la Z, con los casos CA9 (T25) y "la Z no cambia" (T26); `99` sin reapertura de la Z; `02_log` sin nivel Z |
| `Form43.frm` (FACO) | `SubBuscarOpcionFACO` sin la parte `union all` de `termstat`; `CierreTerminalFACO` con textos "cierres Y" |
| `Form133.frm` / `.frx` | Revisados, **sin cambios**. `.frx` = ícono + 4 WMF de la cabecera. FACO inserta `F8`/`EFE` con la Y de la columna 7 y reabre la Z (`AbrirTerminal`) |
| T1 (`PKG_F8_FACO_COMPENSA_DI`) | Sin cambios de lógica (ya era por Y). CA9 cubierto por el orden T1 → T2 en la misma ejecución |

**Puntos abiertos con negocio** (la HU dice algo distinto a lo decidido):
1. Ejecutar el proceso "al momento de la carga" (hoy: un job externo, a agendar justo después de la carga).
2. "Emitir un resumen" (hoy: SQL del log).
3. El diagrama P2 dice "cerrar el terminal del día" (hoy no se hace).

## 6. Hechos verificados en la base de test

| Tema | Dato |
|---|---|
| Base | Oracle **10.2.0.5**, `DB_NAME = sgfnprds` (la conexión se llama "sgfinperds-test"), esquema dueño `INTRANETTS`, usuario de aplicación `UINTRANETTS` (solo sinónimos, sin `CREATE`) |
| `VTA_FACOPRD` | 29 columnas, PK `prv_techkey`, **sin triggers**. `PRV_CIERREY` NUMBER(2) NOT NULL con default 0 (0 = sin Y) |
| `VTA_FACOPARAM` | 4 columnas (`VTA_DFECHAREG` NOT NULL con default `sysdate`). 1500 'DI' = −500 y 1501 'DI' = 20000 (rango de la DI manual). Tipo 1502 libre |
| Decimales | `vta_parametros` FACO: `VTA_NUMFORMAT = '#,#0'` (`gFormat` del exe, 0 decimales), `VTA_DECROUND = 2` |
| `VTA_PAINT_Z` FACO | 53 filas, signo siempre `+`. Los 47 campos existen, cada uno en una sola tabla (`libvta` / `zzz`). Grupos ZZZ: 1, 2, 3, 6, 7 |
| `VTA_FACOCONCEPDIF` | TC, SN, BF, NP, CA, CR, CT, DI (coddif 8), DN, DP, DT, VC. No existen ND, FN, AF, AL, TB, NC ni FT. **Sin doble conteo** |
| Estados | `ter_estado` NUMBER(1); `termstat` sin duplicados; una fila de `tesor` por Y |
| Volumen | Unas 2.180 Z precreadas por día en −1 (solo 0–10 con venta); unos 359 sobres F8 por día de depósito |
| Objetos existentes relevantes | `PKG_F8_FACO_CIERRE_TER_PM_AP` (2022): cierre `AUTOMATICO` de Colombia, sobre todo Autopago; 556 Y y 117 Z. `FUN_F8_COMPENSACION_DI_DR` (2025): DR en PL/SQL, versión Chile. `PKG_F8_COMPENSACION_DI` (Chile). **Cuerpos no visibles** con el usuario de test |
| Desarrollo (`intranetde`) | Sin datos recientes ni parámetros 1500/1501 |
| Opción 1515 (Cerrar Terminal CC) | Existe en `VTA_MENU`, `VTA_SOARMENU` y `VTA_SFCLMENU`; **no** en `VTA_FACOMENU` ni en `VTA_FACORELPERMEN` → la crea `03c_permiso_cc.sql` |
| Perfiles FACO | 0, 1, 6, 7 (Tesorería Analista), 8, 9, 10, 11 (`VTA_FACOPERFILES`) |
| `ter_cerradopor` | VARCHAR2(50) en `termstat` y `termstaty`: admite `LOGINUSER` |
| Datos de test (06-10) | `VTA_FACOTERMSTATY` y libro de ventas Y hasta el 23-09-2026; `VTA_FACOPRD` solo hasta 2022 (no hay cargas recientes). Para probar la rama SIN_SOBRE hay que cargar sobres (p. ej. `PRD 3.xlsx`) |
| Consulta de `SubBuscarOpcionFACO` | Validada en test sin las funciones del paquete: el 23-09-2026 devolvía 1 Y y 7 Z; desde el 07-10 (solo Y) devuelve 1 Y |
| Desarrollo `INTRANETDE` (07-10) | Misma base `sgfnprds`; **puede crear objetos** (vía roles) y tiene los 8 objetos de FSCC-12901 VALID; **casi sin datos** FACO (hasta el 15-03-2022; 0 recaudadoras; `VTA_PAINT_Z` FACO con 47 filas frente a 53 en test). **No ve las tablas de `INTRANETTS`**. Mismas columnas que test en las 15 tablas del flujo. Los techkey de test se solapan con los de desarrollo |
| Datos reales en test (07-10) | 714 cierres Y de 2026 con libro de ventas Y (446 abiertos, 55 local-día, sobre todo el 07-01-2026), 1.024 tarjetas, **sin** sobres, tesorería ni movimientos. **Sin** cajas el 28-08-2026 (fecha de PRD 3) |
| Z de FACO (07-10) | Con fecha de venta desde el 24-08-2026: `vta_FACOtermstat` 10.894 filas en −1 y 6 cerradas; Y: 7 en −1 y 6 cerradas por `AUTOMATICO`. La Z no se gestiona en Colombia |
| `Form133` (07-10) | FACO: `insert into vta_FACOprd` con `prv_tiporec` = F8, `prv_tiposobre` = EFE, Y = columna 7; `AbrirTerminal` reabre o crea solo la Z. `Form133.frx` = ícono + 4 WMF (sin lógica) |

## 7. Pendientes

| # | Pendiente | Responsable |
|---|---|---|
| 1 | Instalar en test con `docs/sql/FSCC-12901_T1_T2/INSTALAR.sql` y ejecutar `10_pruebas.sql`. Las 14 verificaciones previas deben dar lo esperado. Caso clave: la DR del paquete debe ser igual a la "Diferencia Real" de la F8 en 10 cajas | Equipo / usuario |
| 1b | Compilar `f8a.exe` con el nuevo `Form43.frm` en el IDE de VB6 y probar en FACO los casos T21–T26 de `10_pruebas.sql` (grilla solo Y con DR 0, botón con y sin permiso 1515, resumen del cierre, CA9, la Z no cambia) | Equipo |
| 1d | Confirmar con negocio los 3 puntos abiertos del 07-10 (§5d): ejecución "al momento de la carga" frente al job, resumen en pantalla frente a SQL, y "cerrar el terminal del día" del diagrama P2 frente a solo Y | Negocio |
| 1c | Definir a qué perfiles FACO se habilita la opción 1515 (hoy el botón aparece para todos sin hacer nada; con el cambio queda oculto hasta habilitarlo) | Negocio |
| 2 | Obtener del DBA el cuerpo de `PKG_F8_FACO_CIERRE_TER_PM_AP` y de `PKG_F8_COMPENSACION_DI`, y saber quién ejecuta el cierre `AUTOMATICO` (convivencia con T2) | DBA |
| 3 | Decisiones de negocio abiertas: P2 (rango DI), P3, P8 (DI manual previa), P9 (envío contable), P11, P12 (Y cerrada que recibe sobres), P13 (duplicados en la carga), N2/N3 (carga todo o nada; reabrir la Y: el 07-10 se decidió no tocar `Form133.AbrirTerminal`) | Negocio (ver `FSCC-12901_Analisis.md` §4 y §3.12) |
| 4 | Definir con Contabilidad si el Envío Contable (`Form62`) debe separar la DI automática (cambio en el exe) | Contabilidad |
| 5 | ~~Revisar el Excel DF-SCC y PRD 3~~ **Hecho el 06-10** (§3.13 del análisis). Queda: confirmar si "inferior a 20.000" de la fila 57 es exclusivo (hoy inclusivo, configurable con `CA_DI_MAX`) y tratar aparte las filas 34, 40, 46 y 52 del DF (ECOMPAY en la Y, cuenta bancaria, control de bancos, fecha contable del envío a SAP) | Negocio |
| 6 | Decidir si el trigger debe impedir la carga ante un error (hoy lo ignora y hay consulta de conciliación) | Negocio / DBA |
| 7 | Opcional: hacer que `fn_param` ignore mayúsculas (`upper(trim())`) | Desarrollo |

## 8. Cómo retomar

- **Conexión a test:** requiere la **VPN Fortinet** activa. Con la VPN caída aparece `ORA-12170` (timeout).
  - Cliente: `C:\Leonardo\ClienteOracle64\sqlplus.exe`.
  - Cadena EZConnect: `<usuario>/<clave>@//10.140.2.224:1531/sgfinperds`.
  - La clave no se guarda en este documento.
- **Ver como dueño desde el usuario de aplicación** (solo para pruebas de lectura): `alter session set current_schema = INTRANETTS;`.
- **Regenerar los PDF:**
  ```
  "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --headless --disable-gpu --no-pdf-header-footer --print-to-pdf="docs\<salida>.pdf" "file:///C:/Repositorio-f8/F8/docs/pdf/<fuente>.html"
  ```
- **Leer fuentes VB6** (Windows-1252): `iconv -f CP1252 -t UTF-8 archivo | tr -d '\r'`; buscar con `rg --encoding latin1`.
- **Referencias clave del código:**
  - `Form3Y.frm:2801` (cierre de Y; FACO solo usa este) y `Form3.frm:3439` (cierre de Z, no aplica a FACO);
  - `Form3Y.frm:2704` (`FormateaDatos`, DR);
  - `Módulo1.bas:2630` (`StrSumCompensado`);
  - `Form133.frm:1671` (`CargarArchivo`, carga de sobres de Colombia) y `:707` (`AbrirTerminal`, reabre la Z);
  - `Form38.frm:498` (DI manual de FACO);
  - `Módulo1.bas:3777` (`InsertarRegistroMovDet`);
  - `Form45.frm` (`GrabarObs`, observación de la compensación);
  - `Form43.frm`: `SubBuscarOpcionFACO` y `CierreTerminalFACO` (buscar `CK: FSCC-12901`);
  - `Form173.frm:779` (patrón `ADODB.Command` con parámetros OUT);
  - `Módulo1.bas:1111` (`FuncBuscarOpcionCompensa`, permiso 1515 = `OpcionPermiteCerrarTerminalCC`, `Modulo2.bas:253`).

## 9. Historial de cambios (bitácora)

Todo el trabajo se hizo entre el 05 y el 07-10-2026, en el orden siguiente. El proyecto no usa git: este historial, el manifiesto y los respaldos de §10 reemplazan el control de versiones.

| # | Fecha | Qué se hizo | Resultado |
|---|---|---|---|
| 1 | 05-10 | Análisis de la pantalla Consultas de Cuadratura (`Form43`) para Colombia | `docs/CC_ConsultaCuadratura_FACO.md`. Hallazgo: su "Cerrar Terminal" no cierra nada en FACO |
| 2 | 05-10 | Catálogo de reglas del cierre manual de Y y Z (`Form3Y` / `Form3`) con SQL | `docs/CierreCaja_FACO_Reglas.md` |
| 3 | 05-10 | Análisis de la HU FSCC-12901 contra el código | `docs/FSCC-12901_Analisis.md` (§1–§7) |
| 4 | 06-10 | Carga de Colombia (`Form133`), identificación y contabilización, subtareas `.doc` | `FSCC-12901_Analisis.md` §3.8–§3.10 |
| 5 | 06-10 | Consultas de solo lectura en desarrollo y test | §3.11. Hallazgos: paquete de cierre `AUTOMATICO` existente, `FUN_F8_COMPENSACION_DI_DR`, sin doble conteo, rango DI −500/20000, sin `ter_fechacierre` |
| 6 | 06-10 | PDF por subtarea | `docs/FSCC-12957_T1_…pdf`, `docs/FSCC-12958_T2_…pdf` |
| 7 | 06-10 | Diagramas BPMN contra el código | `FSCC-12901_Analisis.md` §3.12 (N1–N5), sección 11 de los PDF |
| 8 | 06-10 | **T2 en base de datos** (cola + trigger + paquete), según la decisión del usuario | `docs/sql/FSCC-12958/` |
| 9 | 06-10 | Supuestos confirmados en test (estructura, `paint_z`, decimales); DR con el compensado redondeado antes, como el exe; `00_prechecks.sql` | Scripts de FSCC-12958 ajustados |
| 10 | 06-10 | Validaciones sueltas expuestas en la especificación de T2 | `05_pkg_cierre_auto_spec.sql` |
| 11 | 06-10 | **Quitar el prefijo de esquema** `INTRANETTS.` de todos los scripts; usuario de aplicación con `accept` | Scripts portables |
| 12 | 06-10 | **T1 en base de datos**, reutilizando cola, trigger, log y `fn_dif_real`; T2 lo invoca primero | `docs/sql/FSCC-12957/`; ajustes en FSCC-12958 (`log_proceso`, llamada a T1, interruptores independientes) |
| 13 | 06-10 | **Carpeta consolidada T1 + T2** con `INSTALAR.sql` | `docs/sql/FSCC-12901_T1_T2/` |
| 14 | 06-10 | Registro completo antes de las pruebas: historial, manifiesto MD5, respaldo ZIP, PDF actualizados, `CLAUDE.md` y memoria | Este documento, §10 |
| 15 | 06-10 | **Análisis del DF-SCC y de PRD 3** y ajuste de la base: vista `VTA_FACOV_CAJAS_CIERRE` (cajas sin sobres), `CA_SIN_SOBRE`, opción 1515 de FACO (no existía), `pr_cuadratura` + `fn_dif_caja` / `fn_compensado`, `prc_cierre_rango`, `log_proceso` CC; T1 recorre la vista | Scripts de FSCC-12957, FSCC-12958 y la consolidada (03b, 03c y 14 verificaciones previas). Copias de la consolidada verificadas con `diff` |
| 16 | 06-10 | **Front VB6**: `Form43.frm` en FACO delega en la base (B1–B6), con respaldo `.bak_FSCC-12901`; PDF de T2 §12.5 y de T1 §12.5 con las imágenes del DF; manifiesto y respaldo `post-DF` | §5c, §10 |
| 17 | 06-10 | Registro final del ajuste: consultas de validación del DF-SCC guardadas en `FSCC-12901_consultas.sql` (8–15); manifiesto regenerado y respaldo `post-DF` rehecho con ese archivo | §3, §10 |
| 18 | 07-10 | **Documentación actualizada** (`Doc-Actualizado/`): HU completa (ejecución en la carga, "Colombia opera con cierre Y", CA9), diagramas P1/P2 nuevos y captura de `Form133`. Revisión de `Form133.frm` y `Form133.frx` | `FSCC-12901_Analisis.md` §3.14; imágenes en `docs/pdf/img/` |
| 19 | 07-10 | **Reestructura "solo cierre Y"**: paquete de T2 sin Z (sin RZ, `pr_procesa_z`, `pr_valida_z`, `fn_msg_z_suma_y`, `fn_msg_y_abiertas`, `fn_dif_dolares`), Y obligatoria en las funciones de DR, sin `CA_VAL_USD`; soporte, pruebas (T25 CA9, T26) y rollback ajustados; `Form43` solo Y; PDF §12.6; 14 verificaciones previas OK en test; manifiesto y respaldo `solo-Y` | §5d, §10 |
| 20 | 07-10 | **Guía del flujo y de los cambios** (PDF): cómo encajan las piezas, recorrido paso a paso y bitácora; manifiesto y respaldo `solo-Y` rehechos | §3, §10 |
| 21 | 07-10 | **Corrección de compilación** reportada por el usuario al crear el paquete en desarrollo (`INTRANETDE`): `PLS-00231: function FN_NOTA may not be used in SQL` en `pr_procesa_y`. `fn_nota` es privada y estaba dentro del `UPDATE`; ahora la nota se arma antes en la variable `v_nota`. No había otros casos en T1 ni en T2 | `FSCC-12958/06_pkg_cierre_auto_body.sql` y copia `07` |
| 22 | 07-10 | **Pruebas sin variables `&`**: en DBeaver los bloques PL/SQL con `&fecha`, `&local`… fallaban (`PLS-00103`). Cada prueba trae ahora sus valores al inicio (variables `v_*` en los bloques, `with p as (…)` en las consultas, marcados EDITAR; ejemplo 15-03-2022). La prueba de la DR tiene una variante por fecha fija y otra de 60 días con el `rownum` corregido; `prc_cierre_rango` avisa que graba | `10_pruebas.sql`, `08_pruebas.sql`, `06_pruebas.sql` |
| 23 | 07-10 | **POC en SQL** del flujo completo: `docs/sql/FSCC-12901_POC/` (01 preparar con respaldos y `CA_DIAS` temporal, 02 cargar sobres como `Form133`, 03 simular, 04 ejecutar el proceso, 05 resultados OK/DIFERENTE, 06 opcional `Form43`, 99 limpiar). No ejecutado aquí (sin acceso a `INTRANETDE`) | `00_LEEME.md` |
| 24 | 07-10 | `00_LEEME.html` del POC: las mismas instrucciones en HTML autocontenido (inicio rápido, flujo, escenarios, pasos en tarjetas, reversión, cuidados y problemas frecuentes) | `docs/sql/FSCC-12901_POC/00_LEEME.html` |
| 25 | 07-10 | **POC con datos reales** (pedido del usuario: test tiene datos pero no permite crear; desarrollo permite crear pero no tiene datos). Generador `02g` (solo lectura en test) → `02_datos_test.sql` (714 Y reales, techkey + 900.000.000); `03_dia_prd3.sql` (486 sobres reales de PRD 3 y cajas por escenario P0–P7 sobre un molde real); `04` simula `Form133`; `05` previsión; `06` ejecución con duración; `07` esperado frente a obtenido y rendimiento; `98` reiniciar; `99` limpiar. Las pruebas `10`/`08`/`06` usan como ejemplo el 28-08-2026. Validado: generación contra test y clonado dinámico con SELECT; **no ejecutado en desarrollo** (decisión: solo scripts) | `docs/sql/FSCC-12901_POC/` |
| 26 | 08-10 | **Manual de prueba por pantallas** (PDF) y carpeta `POC/manual/`: Excel de prueba recortado del `PRD 3.xlsx` real (locales 6 y 13, 29 filas); `M1` (recaudador 00562, fila FACO del usuario copiada de otra localización sin escribir claves, opción 1515, respaldo de Y, tabla de esperados), `M2` (resultados por caja), `M9` (deshacer). Hallazgos: en desarrollo el usuario no tenía FACO y no hay recaudadoras; `Form133` en FACO exige al menos 2 filas; el menú es "Estado en línea" → "Carga Manual de Sobres" | §3 |

## 10. Estado congelado (último: 07-10-2026, después de la reestructura "solo cierre Y")

**Situación en la base de datos:** no se creó ni se modificó **ningún objeto o dato** en desarrollo ni en test. Todas las consultas hechas fueron de solo lectura.

**Manifiesto de integridad:** `docs/MANIFIESTO_FSCC-12901.md5` (regenerado el 07-10 tras la reestructura "solo Y") guarda la huella MD5 de los scripts y README de las tres carpetas, los documentos de análisis, los dos PDF, sus fuentes HTML, CSS e imágenes, los archivos de `docs/Requeriemintos-FSCC-12901/` (incluida `Doc-Actualizado/`), `CLAUDE.md` y `FTEPROD/Form43.frm` con su respaldo `.bak_FSCC-12901` (el número exacto está en el propio manifiesto). Para saber si algo cambió después de esta fecha (desde `C:\Repositorio-f8\F8`, en Git Bash):

```
grep -v '^#' docs/MANIFIESTO_FSCC-12901.md5 | md5sum -c
```

Si un archivo cambió, aparece como `FAILED`: revisar el cambio y, si corresponde, regenerar el manifiesto y anotar el motivo en §9.

**Respaldos** (descomprimir sobre `C:\Repositorio-f8\F8` para volver a ese estado):
- `docs/respaldos/FSCC-12901_2026-10-06_pre-pruebas.zip`: `docs/` y `CLAUDE.md` antes del ajuste DF-SCC.
- `docs/respaldos/FSCC-12901_2026-10-06_post-DF.zip`: `docs/` (sin `respaldos/`), `CLAUDE.md`, `FTEPROD/Form43.frm` y `FTEPROD/Form43.frm.bak_FSCC-12901`, después del ajuste DF-SCC (con la Z todavía en el diseño).
- `docs/respaldos/FSCC-12901_2026-10-07_solo-Y.zip`: el mismo contenido después de la reestructura "solo cierre Y" (**estado vigente**).
- Para deshacer solo el front: copiar `Form43.frm.bak_FSCC-12901` (original anterior a FSCC-12901) sobre `Form43.frm`.

**Checklist para la sesión de pruebas:**

| # | Paso | Script |
|---|---|---|
| 1 | Activar la VPN Fortinet y conectarse como el dueño de las tablas (o como DBA con `current_schema`) | — |
| 2 | Verificar que los scripts no cambiaron | `md5sum -c` (ver arriba) |
| 3 | Verificaciones previas: las 14 deben dar el resultado esperado | `FSCC-12901_T1_T2/00_prechecks.sql` |
| 4 | Instalar los pasos 00–08 (incluye 03b vista y 03c opción 1515) | `@INSTALAR.sql` |
| 5 | Permisos y sinónimos (dueño + DBA), también para el usuario de `[CONNECT]` del exe; habilitar la opción 1515 a los perfiles de prueba | `09_grants_sinonimos.sql`, `03c_permiso_cc.sql` (UPDATE) |
| 6 | Pruebas: compilación, DR contra la F8 en 10 cajas, simulación de T1, ejecución completa, vista, columnas de `Form43` y `prc_cierre_rango` | `10_pruebas.sql` |
| 6b | Compilar el exe con el nuevo `Form43` y probar Consultas de Cuadratura en FACO (casos T21–T26) | IDE VB6 |
| 7 | Registrar los resultados en §9 (nueva fila) y actualizar §2 y §7 | Este documento |
| 8 | Si algo sale mal: apagar (paso 1) o desinstalar (paso 3) | `99_rollback.sql` |

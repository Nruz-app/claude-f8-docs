# FCDVT-56 · HU-14.2: cerrar automáticamente los terminales activos sin movimiento (Falabella Colombia, FACO)

> **Estado (20-10-2026): análisis.** No hay código ni scripts. Faltan respuestas de negocio (§6) antes de diseñar.
> Fuente: `docs/sql/FCDVT-56/FCDVT-56.doc` (export de Jira). Historia padre: **FCDVT-54**, "HU-14 · Cierre automático de terminales con DR 0", que es el trabajo de FSCC-12901 (`docs/README_FSCC-12901.md`).

## 1. Qué pide

> Como tesorería de Falabella Colombia, quiero que el cierre automático también cierre los terminales activos que no tuvieron venta, para no tener que cerrarlos con el archivo «dataload».

| Escenario | Dado | Entonces |
|---|---|---|
| Terminal sin venta | Terminal activo de Colombia sin movimiento en la fecha de proceso − 1, al terminar la carga nocturna | Queda **Cerrado** con Diferencia Real 0 |
| Terminal dado de baja | Terminal dado de baja | No se considera |
| Terminal esperando sobres | Terminal sin venta que espera la carga de sobres de retiro | Queda **abierto** |

- Pantallas: Cuadratura por caja (`Form3Y`), Consultas de Cuadratura (`Form43`) y Estado General de Terminales (`Form2`).
- Tablas: `VTA_FACOTERMSTAT`, `VTA_FACOTERMSTATY`, `VTA_FACOTERMINALES` y `VTA_FACOESTATUS`.

## 2. Qué es hoy un "terminal abierto sin venta" en FACO

**"Sin Datos" en la F8 de la Y** (por ejemplo, local 6, T1, 31-08-2026) no es un estado guardado en la base:
- `Form3Y.LeeTerminales` (`Form3Y.frm:1808-1830`) lista **todos** los terminales vigentes del local (filtro `ter_fechabaja`), vendan o no.
- `LeeCierrey` (`:3415-3470`) llena el combo de Y desde `LIBVTA` (tiporeg `'Y'`, estado `'A'`) ⋈ `ZZZ` ⋈ `TERMSTATY`. Sin venta no encuentra nada, y deja Y = 0.
- `VeEstado` (`:3000-3023`) busca `ter_estado` en `VTA_FACOTERMSTATY` con Y = 0. No hay fila, así que salta al manejo de error (`:3159`), que fija `estado = 3` y muestra **"Sin Datos"** en negro (`:3127-3130`).
- Los demás estados: −1 Pendiente (rojo), 0 Pendiente (amarillo), 1 Cerrado, 2 Impreso, −2 naranjo.

**Lo que está "abierto" es la Z, no la Y:**
- En FACO, el exe solo crea `TERMSTATY` junto al libro de ventas Y (`Form19Y.GrabaZZZ` → `GrabarQuintoZZZ`, `Form19Y.frm:452-477, 610`). **Un terminal sin venta no tiene Y.**
- Lo que existe es la **Z precreada en −1** en `VTA_FACOTERMSTAT`. Hay unas 2.180 por día, y solo de 0 a 10 tienen venta (`README_FSCC-12901.md` §6). La crea un proceso de base; ninguna línea del exe la inserta en −1.
- `Form133.AbrirTerminal` (`Form133.frm:707-760`), en la carga de sobres, reabre o crea la Z en **0** con `ter_notas = 'CARGA MANUAL DE SOBRES'`.
- `Form20` (reapertura) pone Z e Y en 0 (`Form20.frm:445-468`), pero solo si la fila ya existe.

## 3. ¿Lo cubre `PKG_F8_CIERRE_DIARIO`? **No**

- **Universo:** `LIBVTA (Y, 'A') ⋈ ZZZ ⋈ TERMSTATY`, con `ter_cierrey <> 0` y `ter_estado <= 0` (`sql/FSCC-12901_CIERRE_DIARIO/04_pkg_cierre_diario_body.sql:781-795`). Un terminal sin venta no tiene libro de ventas ni Y, así que nunca entra.
- **Dif. Real:** `fn_dif_real` y `fn_dif_real_cc` devuelven **NULL**, no 0, cuando no hay libro de ventas (`sql/FSCC-12901_COMPENSA_DI/05_pkg_compensa_di_carga_body.sql:344-346`, `04:293-295`).
- **Bajas:** no cruza con `VTA_FACOTERMINALES`, así que tampoco filtra los terminales dados de baja.
- **Sobres:** no tiene el concepto "esperando sobres".
- **Z:** no toca `VTA_FACOTERMSTAT`, por la decisión del 07-10 de cerrar solo la Y.
- **Ya estaba identificado:** brecha **B6** (terminal activo sin movimiento) y **B1** (HU-14 pide cerrar "Y y terminal-día", es decir, también la Z) en `docs/FSCC-12901_Comparacion_Onboarding.md:37,42`.
- **Versiones anteriores:** la lógica de "sin sobre" de la v2 (`FSCC-12901_PROC_Y`, `CA_SIN_SOBRE`, `fn_universo :300-317`) y de la v1 (`VTA_FACOV_CAJAS_CIERRE`, `prc_cierre_rango`, cuyo comentario dice "evitar el dataload") **también exigía libro de ventas Y**.

## 4. ¿Los muestran las pantallas?

| Pantalla | ¿Muestra el terminal sin venta? | Detalle |
|---|---|---|
| **CC (`Form43`)** | **No** (en FACO) | `FuncStrPivote` (`Form43.frm:2081-2127`) usa el mismo join con libro de ventas. Para terminales sin venta existe un `UNION ... from vta_<pfx>termstat t where not exists (libvta)`, pero **solo para SFCL/HTPE** (`:2140-2175`) y **ARG** (`:2177-2205`). Ese es el precedente para FACO. "Cerrar Terminal" (`Command4_Click :2915`) solo actúa sobre filas de la grilla con Y ≠ 0 |
| **Form3Y** | Sí, como "Sin Datos" | Ver §2 |
| **Form2** | Sí, en **rojo (−1)** | Lee solo la Z (`VTA_FACOTERMSTAT` + terminales vigentes, `Form2.frm:546-556, 731-745`). Como en FACO la Z no se gestiona, nunca pasa a verde. Un terminal sin fila queda como celda vacía |

## 5. Conceptos del requerimiento contra la base

- **Dado de baja:**
  - El único indicador es `VTA_FACOTERMINALES.ter_fechabaja`. El terminal está vigente en la fecha D si `ter_fechabaja is null or ter_fechabaja >= D`; es el mismo filtro que usan unas 145 consultas del exe, por ejemplo `Form3Y.frm:1820` y `Form2.frm:553`.
  - `ter_tipo` es el tipo de terminal (0 normal, 1 Autopago, 2 POS Mobile; `Form50.frm:220-307`), no la baja.
- **`VTA_FACOESTATUS`:** es por **local-día** (`vta_stlocal`, `vta_stfecha`, `vta_estadof8`; cierre general del local, `Módulo1.bas:822, 3649`), no por terminal. El cierre general solo se bloquea si hay una `TERMSTATY` con estado distinto de 1 (`Est_TermStatPorlocal`, `Módulo1.bas:5854-5885`), así que los terminales sin fila no lo bloquean.
- **"Esperando sobres de retiro":** en FACO **no existe** esa regla. Hay tres señales posibles:
  - sobres del terminal-día en `VTA_FACOPRD` (`prv_tiporec = 'F8'`);
  - retiros declarados en `VTA_FACORETIROS` (`ret_coddenom <> 88`), que es lo que leen `LeeProsegur` y `LeeRetiros` de `Form3Y` (`:2401`, `:2319`);
  - una Z en 0 con `'CARGA MANUAL DE SOBRES'`.

  Lo que define cuándo un terminal "espera" sobres (por cuántos días y con qué dato) tiene que venir de negocio.
- **Proceso existente parecido:** `PKG_F8_FACO_CIERRE_TER_PM_AP` (2022; su cuerpo no es visible con el usuario de test). Cierra con `AUTOMATICO` Y y Z de montos en 0, sobre todo Autopago y POS Mobile: 556 Y y 117 Z (`docs/FSCC-12901_Analisis.md:31, 211`). Hay que ver si se solapa con este requerimiento.

## 6. Preguntas abiertas (negocio / usuario)

| # | Pregunta | Por qué importa |
|---|---|---|
| P1 | ¿Qué es "cerrar" un terminal sin venta en FACO? (a) cerrar la **Z precreada** (`TERMSTAT` −1/0 → 1); (b) **crear** una `TERMSTATY` con Y 0 en estado 1; (c) ambas | La historia dice "cerrar el terminal", no "la Z"; que lo abierto sea la Z es una deducción del modelo de datos. Con (a) Form2 pasa a verde, pero **Form3Y sigue en "Sin Datos"** y se contradice la decisión del 07-10 de no tocar la Z. Con (b) Form3Y mostraría "Cerrado" con Y 0. Hoy no hay nada en la Y que cerrar |
| P2 | ¿Qué hace exactamente el "dataload" de hoy: qué tabla, qué estado y qué `ter_cerradopor`? | Es la referencia del resultado esperado |
| P3 | ¿Cuándo "espera sobres" un terminal? ¿Por sobres o retiros del terminal-día todavía sin cargar? ¿Cuántos días se espera? | El escenario 3 no tiene regla en el código |
| P4 | ¿Entran Autopago y POS Mobile (`ter_tipo` 1/2) o siguen con `PKG_F8_FACO_CIERRE_TER_PM_AP`? | Evitar que dos procesos cierren lo mismo |
| P5 | ¿CC debe mostrar estos terminales en FACO, agregando el `UNION` como en SFCL? | Hoy no se ven en CC |
| P6 | ¿Va como segunda etapa de `PKG_F8_CIERRE_DIARIO` (mismo cron de nhal1) o como proceso aparte? | Diseño y prueba |
| P7 | "Fecha de proceso − 1": ¿es el mismo día que ya toma el cron (`fecha` nula = día anterior)? | Alinear con `prc_cierre_diario` |

## 7. Propuesta (a validar, sin implementar)

- **Segunda etapa "SIN_VENTA" en `PKG_F8_CIERRE_DIARIO`**, en la misma llamada de nhal1 y detrás del parámetro 1502 `CD_SIN_VENTA` (S/N):
  - **Universo:** terminales vigentes de `VTA_{P}TERMINALES` en la fecha (`ter_fechabaja`; `ter_tipo` según P4) **sin** libro de ventas Y `'A'` y sin Y abierta.
  - **Excluir los que esperan sobres** (P3): sobres en `PRD` o retiros del terminal-día. Esos quedan con el resultado `ESPERA_SOBRES`.
  - **Acción según P1:** `update` de la Z (y/o `insert` de la `TERMSTATY` Y 0) con estado 1 y `ter_cerradopor = 'PROC_CIERRE_DIARIO'`; commit por terminal; resultado `CERRADA_SIN_VENTA`.
  - **Multipaís** con el mismo `pr_config`, y el mismo log (`VTA_FACOLOG_CIERRE_DIARIO`).
- **Opcional (P5):** agregar a `Form43.FuncStrPivote` el `UNION` de terminales sin venta para FACO, como el de SFCL (`:2140-2175`).
- **Volumen:** alrededor de 2.180 terminales vigentes por día. El universo debe ser una sola consulta por fecha, sin recorrer local por local.

## 8. Consultas de verificación en test (solo lectura)

```sql
-- 1. Local 6, 31-08-2026: terminales vigentes, si tienen Y con venta y estado de Z/Y
select t.ter_terminal, t.ter_tipo, t.ter_fechabaja,
       (select count(*) from VTA_FACOLIBVTA l
         where l.vta_tiporeg = 'Y' and l.vta_estado = 'A' and l.vta_fecha_venta = d.f
           and l.vta_local = t.ter_local and l.vta_terminal = t.ter_terminal) libvta_y,
       (select max(z.ter_estado) from VTA_FACOTERMSTAT z
         where z.ter_fecha = d.f and z.ter_local = t.ter_local and z.ter_terminal = t.ter_terminal) estado_z,
       (select max(z.ter_notas) from VTA_FACOTERMSTAT z
         where z.ter_fecha = d.f and z.ter_local = t.ter_local and z.ter_terminal = t.ter_terminal) notas_z,
       (select count(*) from VTA_FACOTERMSTATY y
         where y.ter_fecha = d.f and y.ter_local = t.ter_local and y.ter_terminal = t.ter_terminal) filas_y,
       (select count(*) from VTA_FACOPRD p
         where p.prv_fechavta = d.f and p.prv_local = t.ter_local and p.prv_terminal = t.ter_terminal) sobres
  from VTA_FACOTERMINALES t, (select to_date('20260831','yyyymmdd') f from dual) d
 where t.ter_local = 6
   and (t.ter_fechabaja is null or t.ter_fechabaja >= d.f)
 order by t.ter_terminal;
-- ESPERADO: T1 con libvta_y 0, filas_y 0 y estado_z -1 (si existe la Z).

-- 2. Volumen del dia: Z sin venta por estado
select z.ter_estado, count(*)
  from VTA_FACOTERMSTAT z
 where z.ter_fecha = to_date('20260831','yyyymmdd')
   and not exists (select 1 from VTA_FACOLIBVTA l
                    where l.vta_tiporeg = 'Y' and l.vta_estado = 'A'
                      and l.vta_fecha_venta = z.ter_fecha and l.vta_local = z.ter_local
                      and l.vta_terminal = z.ter_terminal)
 group by z.ter_estado;

-- 3. Quien cierra hoy esas Z (dataload / AUTOMATICO / otros)
select z.ter_cerradopor, count(*)
  from VTA_FACOTERMSTAT z
 where z.ter_fecha >= to_date('20260801','yyyymmdd') and z.ter_estado = 1
 group by z.ter_cerradopor order by 2 desc;
```

La consulta 3 ayuda a responder P2 (qué deja el dataload).

## 9. Pendientes

| # | Pendiente | Responsable |
|---|---|---|
| 1 | Responder P1–P7 | Negocio / usuario |
| 2 | Ejecutar las consultas de §8 en test | Usuario (o Claude con la clave, solo lectura) |
| 3 | Con P1–P7 respondidas: diseño y scripts en `docs/sql/FCDVT-56/` (etapa SIN_VENTA del paquete) y, si P5 = sí, cambio en `Form43` | Claude |

## 10. Historial

| # | Fecha | Qué se hizo |
|---|---|---|
| 1 | 20-10-2026 | Análisis inicial: el requerimiento contra el exe (`Form3Y`, `Form43`, `Form2`, `Form133`, `Form19Y`) y contra `PKG_F8_CIERRE_DIARIO`. Conclusión: el paquete no lo cubre y CC no muestra estos terminales en FACO. Preguntas P1–P7 |

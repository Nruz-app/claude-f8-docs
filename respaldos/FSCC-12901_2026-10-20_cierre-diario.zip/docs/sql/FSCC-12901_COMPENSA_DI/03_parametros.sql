-- =====================================================================
-- FSCC-12901 COMPENSA_DI - Paso 03: parametros (VTA_FACOPARAM tipo 1502)
-- xintec-nruz 19-10-2026
-- Idempotente: inserta solo los que no existen. Para cambiar un valor,
-- update directo (se lee en cada llamada, sin recompilar).
-- El rango de la DI MANUAL (1500/1501 'DI') no se toca.
-- =====================================================================

insert into VTA_FACOPARAM (vta_ccodtipo, vta_ccodigo, vta_xglosa, vta_dfechareg)
select 1502, 'CA_DI_ACTIVO', 'S', sysdate from dual      -- S/N compensacion automatica activa
 where not exists (select 1 from VTA_FACOPARAM where vta_ccodtipo = 1502 and trim(vta_ccodigo) = 'CA_DI_ACTIVO');

insert into VTA_FACOPARAM (vta_ccodtipo, vta_ccodigo, vta_xglosa, vta_dfechareg)
select 1502, 'CA_DI_MIN', '-1000', sysdate from dual     -- limite inferior de la DR (inclusive)
 where not exists (select 1 from VTA_FACOPARAM where vta_ccodtipo = 1502 and trim(vta_ccodigo) = 'CA_DI_MIN');

insert into VTA_FACOPARAM (vta_ccodtipo, vta_ccodigo, vta_xglosa, vta_dfechareg)
select 1502, 'CA_DI_MAX', '20000', sysdate from dual     -- limite superior de la DR (inclusive)
 where not exists (select 1 from VTA_FACOPARAM where vta_ccodtipo = 1502 and trim(vta_ccodigo) = 'CA_DI_MAX');

insert into VTA_FACOPARAM (vta_ccodtipo, vta_ccodigo, vta_xglosa, vta_dfechareg)
select 1502, 'CA_DECIMAL', '0', sysdate from dual        -- decimales (gFormat FACO '#,#0')
 where not exists (select 1 from VTA_FACOPARAM where vta_ccodtipo = 1502 and trim(vta_ccodigo) = 'CA_DECIMAL');

commit;

-- ESPERADO: 4 filas
select trim(vta_ccodigo) codigo, vta_xglosa
  from VTA_FACOPARAM where vta_ccodtipo = 1502 order by 1;

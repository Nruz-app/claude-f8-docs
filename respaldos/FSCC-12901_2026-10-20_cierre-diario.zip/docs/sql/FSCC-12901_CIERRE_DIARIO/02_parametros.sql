-- =====================================================================
-- FSCC-12901 CIERRE_DIARIO - Paso 02: parametros (VTA_FACOPARAM tipo 1502)
-- xintec-nruz 20-10-2026
-- Idempotente: inserta solo los que no existen. Para cambiar un valor,
-- update directo (se lee en cada ejecucion, sin recompilar).
-- Prefijo CD_ (cierre diario) para no mezclarse con los CA_DI_* de la
-- compensacion de DI. CA_DECIMAL (decimales) ya existe: lo creo
-- FSCC-12901_COMPENSA_DI/03_parametros.sql y se reutiliza.
-- =====================================================================

insert into VTA_FACOPARAM (vta_ccodtipo, vta_ccodigo, vta_xglosa, vta_dfechareg)
select 1502, 'CD_ACTIVO', 'S', sysdate from dual        -- S/N cierre diario activo
 where not exists (select 1 from VTA_FACOPARAM where vta_ccodtipo = 1502 and trim(vta_ccodigo) = 'CD_ACTIVO');

insert into VTA_FACOPARAM (vta_ccodtipo, vta_ccodigo, vta_xglosa, vta_dfechareg)
select 1502, 'CD_VAL_CHEQ', 'S', sysdate from dual      -- S/N RY-01 cheque a fecha (gestion = tesoreria)
 where not exists (select 1 from VTA_FACOPARAM where vta_ccodtipo = 1502 and trim(vta_ccodigo) = 'CD_VAL_CHEQ');

insert into VTA_FACOPARAM (vta_ccodtipo, vta_ccodigo, vta_xglosa, vta_dfechareg)
select 1502, 'CD_VAL_ZZZ', 'N', sysdate from dual       -- S/N RY-06 formula ZZZ de la Y (opcion 103 del exe)
 where not exists (select 1 from VTA_FACOPARAM where vta_ccodtipo = 1502 and trim(vta_ccodigo) = 'CD_VAL_ZZZ');

commit;

-- ESPERADO: CA_DECIMAL 0, CA_DI_ACTIVO S, CA_DI_MAX 20000, CA_DI_MIN -1000,
--           CD_ACTIVO S, CD_VAL_CHEQ S, CD_VAL_ZZZ N
select trim(vta_ccodigo) codigo, vta_xglosa
  from VTA_FACOPARAM where vta_ccodtipo = 1502 order by 1;

# FSCC-12901 COMPENSA_DI: compensación automática de DI al cargar sobres (Colombia, FACO)

Creada el 19-10-2026. Reemplaza el modelo de `FSCC-12901_PROC_Y` (v2, traspasada a test el 14-10), en el que la carga de sobres además cerraba la Y.

## Modelo (reunión con el usuario de negocio, 19-10-2026)

1. **Carga de sobres (`Form133`)**: no cierra la caja. Por cada caja (fecha de venta, local, terminal, Y) del Excel, se calcula la **diferencia real** de la F8 de la Y con **todos** sus sobres.
   - Si está entre **−1.000 y +20.000** (límites incluidos) y no es 0, se registra una **DI (Diferencia No Imputable)** por el **valor exacto y con el mismo signo** (+500 → DI +500; +15.000 → DI +15.000).
   - La DI se graba igual que la manual (`Form38`): regularizada, se ve en "Compensado" de `Form4` y la Dif. Real queda en 0.
   - Observación: `COMPENSACION AUTOMATICA DIFERENCIA DE DI` (en mayúsculas, como la guarda `Form45`).
   - La caja queda **Pendiente**: no se cierra.
2. **Cierre**: un **cron diario** cerrará las cajas sin diferencia, igual que "Cerrar Terminal" de `Form43`. **Pendiente**: se diseña después.

Reglas decididas:

| Caso | Qué hace |
|---|---|
| Recarga: la caja ya tiene DI automática y llega otra carga | Se **recalcula**: borra la DI automática anterior y su observación, evalúa de nuevo con todos los sobres y, si sigue en el rango, registra la DI nueva |
| La caja tiene una DI manual (`Form38`) | No se toca (`DI_MANUAL_PREVIA`) |
| Caja cerrada | No se toca (`YA_CERRADA`) |
| Y no ingresada todavía | `SIN_TERMSTAT` / `SIN_LIBVTA`, sin DI. Ingresar la Y **antes** de cargar |
| Sobre sin Y (`prv_cierrey = 0`) | `SIN_Y` |

## Archivos

| Script | Tipo | Qué hace |
|---|---|---|
| `00_prechecks.sql` | Lectura | Objetos de v1/v2/YZ existentes, jobs, sinónimos, parámetros 1502, opción 1515, objetos que usa el paquete y datos que dejaron las pruebas |
| `01_DESINSTALAR_v2.sql` | Borrado | **Respalda** la cola y el log (`VTA_FACOPRD_CIERRE_BK`, `VTA_FACOLOG_CIERRE_AUTO_BK`). Después borra el trigger, los paquetes v2/v1, la vista v1, la cola, el log, las secuencias, los parámetros 1502 `CA_%` y la opción 1515. Es idempotente. Parte 2: sinónimos (DBA). No toca DI ni Y ya grabadas |
| `02_log_compensa_di.sql` | Objeto | `VTA_FACOLOG_COMPENSA_DI` + secuencia: una fila por caja evaluada |
| `03_parametros.sql` | Datos | 1502: `CA_DI_ACTIVO` S, `CA_DI_MIN` −1000, `CA_DI_MAX` 20000, `CA_DECIMAL` 0 |
| `04` / `05` | Paquete | `PKG_F8_COMPENSA_DI_CARGA` (spec / body) |
| `06_grants_sinonimos.sql` | Permisos | `UINTRANETTS` (parte B como DBA) |
| `07_pruebas.sql` | Pruebas | Escenarios A–G, simulación sin grabar y llamada manual por caja |
| `99_rollback.sql` | Reversión | 1 apagar, 2 borrar las DI automáticas de un rango (solo cajas abiertas), 3 desinstalar |
| `INSTALAR.sql` | — | 02 → 05 + estado (SQL*Plus) |
| `FORM133_cambios.md` | Documento | Cambio del exe para llamar al paquete por caja (**aplicado el 19-10 en `FTEPROD/Form133.frm`, sin compilar**) |
| `prueba_test/` | Prueba | Sesión de prueba en test: local 6, 31-08-2026. Cuatro pruebas: 1 DI negativa (T29, −800), 2 DI positiva (T40, +15.000), 3 sin DI fuera de rango (T31, −5.000) y 4 caso normal (T24, DR 0). Un Excel por prueba, el resumen por bloques, P0, P2 y P9 (ver su `LEEME.md`) |

## `PKG_F8_COMPENSA_DI_CARGA`

| Rutina | Uso |
|---|---|
| `prc_compensa_caja(fecha, local, terminal, Y, usuario, OUT resultado, OUT monto_di, OUT mensaje)` | La llama `Form133` por caja. Hace commit. No propaga errores (`ERROR` + mensaje) |
| `fn_evalua(fecha, local, terminal, Y)` | Resultado que daría, sin grabar (se puede usar en un `SELECT`) |
| `fn_dif_real(...)` / `fn_dif_real_sin_di(...)` | DR actual / DR sin la DI automática (la que se compensaría) |

- La DR es la misma consulta de `PKG_F8_CIERRE_AUTO.pr_cuadratura` (v2), validada en las pruebas 1 a 3 de test, con las tablas `VTA_FACO*` fijas.
- La DI replica `Modulo1.InsertarRegistroMovDet`: `mov_regul` S, `mov_fechareg` = fecha de venta, `SEQ_VTA_FACOVEN`, `mov_hechopor` = `PROC_DI_AUTO`.
- Después de grabar, controla que la DR quede en 0; si no, deshace todo (`ERROR`).

Resultados posibles: `DI_REGISTRADA`, `DR_CERO`, `FUERA_RANGO`, `DI_MANUAL_PREVIA`, `SIN_LIBVTA`, `SIN_TERMSTAT`, `YA_CERRADA`, `OCUPADA`, `SIN_Y`, `INACTIVO`, `ERROR`.

## Orden (test, conectado como `INTRANETTS`)

1. `00_prechecks.sql`: revisar qué existe y si hay un job (consulta 3).
2. `01_DESINSTALAR_v2.sql`: parte 1 como dueño y parte 2 (sinónimos) como DBA. Verificación (i).
3. `INSTALAR.sql`, o en DBeaver 02 → 03 → 04 → 05. Revisar `user_errors`.
4. `06_grants_sinonimos.sql`.
5. `07_pruebas.sql`: sin el cambio de `Form133`, cargar el Excel y llamar al paquete a mano (bloque 3).

**Atención:** entre el paso 2 y la compilación del exe con `FORM133_cambios.md`, toda carga FACO en test muestra el error de `PKG_F8_CIERRE_AUTO`. Los sobres sí quedan cargados.

## Pendiente

- Aplicar y compilar el cambio de `Form133`.
- Diseñar el **cron de cierre diario**: cajas con DR 0, mismas validaciones que "Cerrar Terminal" de `Form43` / `Form3Y.CierraTerminal`.
- Convenciones: ASCII, sin prefijo de esquema, sin `&`, Oracle 10.2. **No probado en la base**: lo compila y ejecuta el usuario.

# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 1. Qué es

**F8 Automático** (`f8a.exe`, proyecto VB6 `F8Multipais`, empresa Falabella) es una aplicación de escritorio **Visual Basic 6** para la tesorería y recaudación de tiendas. Cubre:

- **Cuadratura F8** por terminal y por local: venta declarada en la **Z** (cierre fiscal del POS) contra retiros, sobres de tesorería, recaudación de la transportadora de valores (Prosegur/LGS, carga "PRD") y medios de pago (efectivo, cheques, tarjetas, vales, notas de crédito, moneda extranjera).
- **Cierres** de terminal (Z, Y = cierres parciales, ZZZ = validación por fórmula, Z virtual) y cierre general del local.
- **Compensaciones y regularizaciones** de diferencias de caja (vendedor/cajero, sobres no enviados, billetes falsos, NC de publicidad, dotaciones, cartas aviso, certificados, etc.).
- **Sobres, depósitos y conciliación bancaria** (pareo/despareo, cartolas, máquinas recicladoras).
- **Libro de ventas**, informes y exportación a Excel.
- **Contabilización**: envío a Oracle Financials ("FOSO") y a SAP.

Es multipaís y multiempresa (Chile, Argentina, Perú, Uruguay, Colombia; Falabella, Sodimac, Tottus, Maestro, CMR, etc.) sobre **Oracle** mediante **ADO**. Todo el código está en `FTEPROD/`. Tamaño: 177 archivos de proyecto, unas 309.000 líneas.

## 2. Compilación, ejecución y despliegue

- No hay build por CLI en el repo, ni linter ni tests automatizados. Se compila en el IDE de VB6 abriendo `FTEPROD/recaudacion.vbp` (Archivo → Generar f8a.exe) o con `VB6.EXE /make FTEPROD\recaudacion.vbp` si VB6 está instalado. La única verificación posible fuera del IDE es revisar el código; los cambios se prueban ejecutando el exe contra una base de desarrollo o test.
- Referencias/OCX que deben estar registrados: ADO 2.1 (`msado21.tlb`), CDO (`cdosys.dll`), `MSSTDFMT.DLL`, `MSFLXGRD.OCX`, `MSHFLXGD.OCX`, `TABCTL32.OCX`, `COMDLG32.OCX`, `MSCOMCTL.OCX`, `mscomct2.ocx`. Los `Form*.log` los genera el IDE cuando falta un OCX ("no era una clase de control cargada"); no son código.
- En ejecución el exe lee `Setup.ini` desde `App.Path` y necesita el proveedor `MSDAORA` y el alias TNS de la base. Excel debe estar instalado para las exportaciones (`CreateObject("Excel.Application")`).
- **Control de versión obligatorio**: después del login, `LeeParametros` (`Módulo1.bas`) compara `Gversion` (`Global Const Gversion` en `Módulo1.bas`) con `vta_parametros.vta_ultversion` del país. Si no coinciden, lanza `actuf8.exe` (autoactualizador) y termina. Para publicar una versión nueva hay que cambiar `Gversion` **y** actualizar `vta_ultversion` en la base de cada país; si no, el exe no arranca o se autoactualiza a otra versión.
- Los `f8a <fecha>.exe`, `f8a rollback.exe`, `f8a_pro.exe` y los `*.zip` son binarios publicados que se guardan a mano para despliegue y rollback. No se modifican.

## 3. Qué archivos son fuente

- **Fuente real**: solo lo que lista `FTEPROD/recaudacion.vbp` (`Form=` / `Module=`). Un formulario o módulo nuevo debe agregarse ahí.
- **El nombre de archivo no siempre coincide con el `VB_Name`**, y hay archivos huérfanos con el nombre "esperado". Antes de editar un formulario, confirmar en el `.vbp` qué archivo lo contiene:

  | VB_Name (cómo se usa en el código) | Archivo real en el proyecto | Archivo huérfano (NO compilado) |
  |---|---|---|
  | `Form104` (Cuadratura) | `V1.frm` | `Form104.frm` |
  | `Form40` (Pareo sobre no enviado) | `Form41.frm` | `Form40.frm` |
  | `Form41` | `Form125.frm` | — |
  | `Form42` (Observación) | `Form128.frm` | `Form42.frm` |
  | `Form99` (Efectivo) | `Form124.frm` | `Form99.frm` |
  | `Form164` (Dice Contener) | `Form164x.frm` | — |
  | `Form164_2` (Ingreso datos depósito) | `Form164.frm` | — |
  | `frmLogOraError` | `Logoerr.frm` | — |
  | `Module1` | `Modulo2.bas` | — |
  | `Módulo1` | `Módulo1.bas` | `REP/Módulo1.bas` (copia) |

- **No forman parte del build**: `*.frm.bak`, `*_OLD`, `*_old*.frm`, `Form3malo.frm`, `Form33old.frm`, `Form6_reemplazo.frm`, `OldForm97.frm`, `Form_CHAOfrm.frm`, `J.frm`, `Pan1.frm`, `frmLogin.frm`, `vezzz.frm`, `é.frm`, `recaudacion - 20160530.vbp`, `recaudacionmaloo.vbw`, `REP/`. No se editan salvo que se pida.
- Otros archivos sueltos: `*.sql` (consultas ad hoc de soporte) y `VTA_CARTAAVISO.txt` / `VTA_SRXCARTAAVISO.txt` (DDL de tablas). Sirven de referencia; no los usa el exe.
- Cada `.frm` tiene un `.frx` binario con los recursos del diseñador (imágenes, listas). Las propiedades de los controles pueden editarse en el bloque `Begin … End` del `.frm`, pero no hay que tocar los offsets `"FormX.frx":XXXX`.
- **Codificación**: todos los fuentes están en **Windows-1252 (ISO-8859) con CRLF**. Hay identificadores con tildes (`CtsCompensación`, `BtoOpciónCertificadosTBK`, `Módulo1`). Al editar hay que conservar la codificación y los CRLF; convertir a UTF-8 rompe los identificadores y los textos de la interfaz. Para leer desde bash: `iconv -f CP1252 -t UTF-8 archivo | tr -d '\r'`. Para buscar texto con tildes hay que indicar la codificación (`rg --encoding latin1 'Compensación' FTEPROD`); una búsqueda normal en UTF-8 no encuentra nada.

## 4. Arquitectura

### 4.1 Arranque, login y sesión

1. `Startup="Form1"` (`form1.frm`). `Form_Load` hace lo siguiente:
   - aplica la configuración regional con `mConfiguracionRegional.PonerConf2` y `Func_cofiguracion`;
   - lee `[CONNECT]` de `Setup.ini` con `Lee_Ini`;
   - decodifica la contraseña con `Passwords()` (grupos de 3 dígitos, `Chr(n-10)`);
   - abre la conexión global `Ado_Conn` (`Provider=MSDAORA`).
2. `Command1_Click` → `VerificaUsuarioF8` → `BuscaLogin`, que llama a `PKG_VTA_F8LV.proc_cmp_acceso(rut, clave)` y llena `VG_registro_usuario`. Si el usuario tiene más de un perfil (`VerificaUsuarioMulti >= 2`) se abre `Form87` para elegirlo; si no, `BuscaPerfilesdeUsuario` toma el perfil directamente. Ambos caminos asignan `PERFILUSER`, `LOCALUSER`, `PAIS$` y `Flg_Pais$` desde `vta_users`, `vta_<pfx>perfiles`, `vta_parametros` y `vis_adm_personas`.
3. `LeeParametros` hace el control de versión y fija `gFormat` / `gDecimal`; `LeePeractual` lee el período. Un `Select Case PAIS$` fija `VG_COD_PAIS` y `VG_COD_EMPRESA` (código de empresa por país) y muestra `MDIForm1`.
4. `MDIForm1.MDIForm_Load` pone título y bandera según `PAIS$`, llama a `SubBuscarOpcionMenu(PERFILUSER)` y lee parámetros con `Fuctiondatoparam(tipo, código)`: 3005 = límite de días, 3004 = fecha Prosegur, 510 = monto máximo de sobre. Después muestra `FormVariable`.
5. `MDIForm_Unload` → `MainFinal` cierra `Ado_Conn` y ejecuta `End`. Accesos y salidas se registran en `VTA_LOG_SISTEMA` con `InsertaLogSistema` (`LogSistemaF8.bas`); los IDs de módulo son las constantes `LOGINENTRADA`…`MANTUSUA`.

### 4.2 Navegación y permisos

- **No hay menú clásico**. Toda la navegación pasa por `MDIForm1.Toolbar1` (botones indexados, varios con `ButtonMenus` desplegables):
  - `Toolbar1_ButtonClick` despacha por `Button.Description` (`"F8"`, `"F8G"`, `"zz"`, `"YYYY"`, `"Sobres"`, `"Cerrar"`, `"Informes"`, …);
  - `Toolbar1_ButtonMenuClick` despacha por `ButtonMenu.Key` (`"CargaDepositos"`, `"pareo"`, `"Recicladora"`, `"ZLV"`, …).
  
  Para saber qué formulario abre una opción hay que buscar su clave ahí.
- **Permisos por perfil** (`SubBuscarOpcionMenu`): lee `VTA_<pfx>relpermen` unido a `VTA_<pfx>menu` (`mnu_tipomenu = 'MenuPrincipal'`) para el `per_codigo`. `mnu_codigo` es el **índice del botón** del toolbar, salvo los casos especiales mapeados a mano: 104/106/3 → botón 3; 331–346 y 450/451 → submenús del botón 33; 116–120 y 152–155 → botón 27; 421 → botón 40; 281 → botón 28; etc. `rel_estado = -1` significa habilitado (True en VB). Agregar una opción nueva requiere tres cosas: el botón o submenú en el `.frm`, el registro en `vta_<pfx>menu`/`relpermen` y, si el índice no coincide, una rama nueva en `SubBuscarOpcionMenu`.
- **Permisos finos dentro de pantallas**: `FuncBuscarOpcionCompensa(PERFILUSER, código)` y `FuncBuscarOpcionCompensarango` (`Módulo1.bas`) consultan opciones `mnu_tipomenu = 'opcion'`. Los códigos son las constantes `Cts*`, `Bto*`, `Opcion*` de `Modulo2.bas` y `Btn*` de `Módulo1.bas` (p. ej. `CtsCompensación = 40`, `OpcionPermiteIngresoSobreCero = 1514`).
- Perfiles: constantes `PERFIL_USER_*` en `Módulo1.bas` (0 tesorería local, 1 grupal, 9 administrador, 12 nuevo administrador, 13 conciliación, etc.). Muchas validaciones de cierre se saltan para ciertos perfiles (p. ej. `PERFIL_USER_DIEZ`).

### 4.3 Pantalla F8 activa y estado global entre formularios

- `FormVariable` (global `Object`) apunta a la pantalla de cuadratura activa: `Form3` (F8 por terminal), `Form3Y` (cuadratura con cierres Y), `Form8` (F8 general/empresa del local) o `Form104` (`V1.frm`, cuadratura por operador). La toolbar opera sobre ella: `FormVariable.ProcesoConsulta`, `FormVariable.CierraTerminal`, `FormVariable.lblEstado.Tag` (estado del terminal; `1` = cerrado).
- Los formularios se pasan contexto con **variables globales**, no con parámetros: `Gfecha`, `Glocal`, `Gterminal`, `GcierreY`, `Gopcion` (`"T"` terminal, `"G"` general, `"E"` empresa), `swform3`, `swActiva` (suprime eventos `Click` mientras se llenan combos), `Prd_actualiza`, `VG_LecturaTabla`, `SobreNE$`, `flg_comp$`, `Type_Ingreso_Z` (`"F8"` / `"F8L"`), etc. Antes de cambiar un formulario hay que revisar qué globales lee y escribe.
- Casi todos los diálogos se abren modales (`FormX.Show 1`). Al volver, la toolbar suele llamar a `FormVariable.ProcesoConsulta` para refrescar la F8.

### 4.4 Multipaís / multiempresa

- `PAIS$` = código de localización (`vta_users.vta_localiz`). `Flg_Pais$` = **prefijo de tablas** (`vta_parametros.vta_prefijo`). Chile (`CHI` / `""`) usa las tablas sin prefijo.
- Códigos en uso: `CHI`/`""` Falabella Chile, `CMCL` CMR Chile, `KFCL` Procafecol, `SFCL` Tottus Chile, `ARG` Falabella Argentina, `SOAR` Sodimac Argentina, `SOUY` Sodimac Uruguay, `PER` Saga Falabella Perú, `FAOR` Saga Oriente, `FAIQ` Saga Iquitos, `HTPE`/`HTOR`/`HTIQ` Tottus Perú, `SOPE` Sodimac Perú, `SPOR` Sodimac Oriente, `MAPE` Maestro Perú, `MPAM` Maestro Amazonía, `FACO` Falabella Colombia.
- Los nombres de tabla se arman en tiempo de ejecución: `"vta_" & Flg_Pais$ & "param"`, `"vta_" & Flg_Pais$ & "movdet"`, `"vta_" & IIf(Flg_Pais$ = "CHI", "", Flg_Pais$) & "locales"`. Una tabla nueva por país debe existir con **todos** los prefijos activos.
- La lógica por país está repartida en cientos de `If Flg_Pais$ = … Or …` dentro de los formularios. Al cambiar un flujo hay que buscar todas las ramas, con ambas variables: `grep -n 'Flg_Pais\$ = "XXX"'` y `grep -n 'PAIS\$ = "XXX"'`. Patrones frecuentes:
  - Perú y sus empresas usan `Form19_2` para la Z; Argentina usa `Form19_3`.
  - `ARG`, `SFCL`, `FACO` y `HTPE` usan cierres Y (`Form19Y`, `Form3Y`). **`FACO` opera solo con cierre Y**: `Form3Y.CierraTerminal` actualiza solo `vta_FACOtermstaty`, y la Z (`vta_FACOtermstat`) se precrea en −1 y no se gestiona. `Form133` (carga de sobres) inserta `F8`/`EFE` con la Y del Excel y reabre solo la Z (`AbrirTerminal`). Ver `docs/README_FSCC-12901.md` §5d.
  - `MAPE`, `MPAM` y `SPOR` cuadran por vendedor en lugar de por terminal (`LeeVendedor`).
  - `SFCL` tiene recicladoras y pantallas propias (`Form81`, `Form107`).
  - `SOAR` y `SOUY` envían a FOSO con `Form72`; el resto lo hace con `Form62`.

### 4.5 Acceso a datos

- Conexiones globales (`Módulo1.bas`):
  - `Ado_Conn`: base principal de tesorería (`[CONNECT]`), abierta todo el tiempo de la sesión.
  - `Ado_Conn_apps`: base de Oracle Financials (`[CONNECT2]`). Se abre y se cierra localmente en `Form62`, `Form72`, `Form90` y `Form132`.
  - `[CONNECT21]` y `[CONNECT22]` son alternativas comentadas o sin uso.
- **Patrón único en todo el código** (seguirlo en código nuevo):
  ```vb
  Set rs = CreateObject("ADODB.Recordset")
  With rs
      .ActiveConnection = Ado_Conn
      .CursorLocation = adUseClient
      .CursorType = adOpenForwardOnly
      .LockType = adLockReadOnly
  End With
  sq = "select ... from vta_" & Flg_Pais$ & "tabla where campo = '" & valor & "'"
  On Error GoTo oraerror
  Call rs.Open(sq)
  ' ... recorrer ...
  Set rs.ActiveConnection = Nothing
  Exit Function
  oraerror:
     Set rs.ActiveConnection = Nothing
     SystemMsg = "Problemas de comunicación con servidor ..."
     frmLogOraError.Show 1
  ```
  Los INSERT/UPDATE/DELETE (unos 535) y las llamadas a procedimientos también pasan por `Recordset.Open`. `ADODB.Command` casi no se usa (solo `Form173`). **No hay transacciones** (`BeginTrans` no aparece): cada sentencia se confirma sola.
- `frmLogOraError` (`Logoerr.frm`) muestra la global `SystemMsg` y el `Err` de VB. Hay que asignar `SystemMsg` antes de mostrarlo.
- Fechas: se envían como texto con `to_date(..)` y los formatos de `Modulo2.bas` (`VgFormatoFecha = "yyyymmdd"`, `VgFormatoFechaWhere`, `VG_Fechaddmmyyyy`). Montos: `Change_Char(x, ",", ".")` para el SQL y `Format(x, gFormat)` para mostrar, porque `PonerConf2` fuerza la configuración regional del separador decimal (`obtenerSepDecimal`, `gstrSepDec`).

### 4.6 Modelo de datos (Oracle)

Las tablas por país se escriben aquí como `vta_<pfx>X`.

- **Parámetros**: `vta_<pfx>param` (el objeto más usado; clave `vta_ccodtipo` + `vta_ccodigo` → `vta_xglosa`, que se lee con `Fuctiondatoparam`), `vta_parametros` (por localización: versión, formato, prefijo), `vta_param`, `vta_facoparam` (usada directamente en `Form62`/`Form72`).
- **Seguridad**: `vta_users`, `vta_<pfx>perfiles`, `vta_<pfx>menu`, `vta_<pfx>relpermen`, `vis_adm_personas`, `mae_personas_falabella`, `VTA_LOG_SISTEMA`.
- **Venta y Z**: `vta_<pfx>locales` / `locales2`, `vta_<pfx>terminales`, `vta_<pfx>libvta` (libro de ventas), `vta_<pfx>zzz` / `vta_paint_z` / `vta_order_z` (estructura y validación de la Z), `vta_zvirtual`, `vta_<pfx>tarj` / `dettarj` / `detpago`.
- **Estado de terminales**: `vta_<pfx>termstat` (cierre Z), `termstaty` (cierres Y), `termstatesc`, `estatus`, `esttrx`.
- **Tesorería y sobres**: `vta_<pfx>tes`, `retiros`, `recuentotesor`, `sobreprd`, `prd` (carga de la transportadora), `prs`, `codprosegur`, `gruposprd`, `temp_cab` / `temp_cuerpo` / `temp_cue_ini` (cargas de escucha), `deporeci` y `procrecicladora` (recicladoras).
- **Compensaciones**: `vta_<pfx>movdet`, el detalle de movimientos con `vta_tipomov` de 2 letras (p. ej. `SN` sobre no enviado, `AF` atesoramiento fondo fijo, `ND`, `FN` factura no digitada, `NP` NC publicidad; ver `CierraTerminal` en `Form3.frm`). También `concepdif` (catálogo de conceptos), `difvend` / `relvendedor` (vendedor-cajero), `cartaaviso`, `compensacion`, `compdes`, `movdetcert` (certificados).
- **Cheques y moneda extranjera**: `vta_<pfx>cheques`, `vta_<pfx>_f8cheques`, `tes_ccheque`, `vta_<pfx>tasamda`, `vta_<pfx>recmex`, `cmn_mdareg`.
- **Banco**: `vta_<pfx>depbanco`, `conciliacion`, `pareo`, `cartola`, `cmn_bancosvs`.
- **Contabilidad**: `vta_<pfx>enviofoso`, `OF_CORP_AR_RECIBOS`, `OF_CORP_AR_INTERFACE`, `OF_CORP_GL_INTERFACE` (en `Ado_Conn_apps`), `sap_concepdif`, `sap_transportadora[_fr]`, `sap_asociacion_tienda[_fr]`, `vta_homologactactesap`, `vta_enviocontab_*`.
- **Paquetes PL/SQL**:
  - acceso: `PKG_VTA_F8LV` (login, pareo banco, moneda extranjera SOAR) y `PKG_VTA_F8LV_NEW` (usuarios);
  - días hábiles: `PKG_CMNFPI2`;
  - recicladoras y recuento: `PKG_INT_F8_PROCREC`, `PKG_INT_F8_MEJORARECI`;
  - compensación por diferencia no imputable y billetes falsos: `PKG_F8_COMPENSACION_DI`;
  - interfaces de Oracle Financials: `PKG_OF_CORP_GL_INTERFACE`, `PKG_OF_CORP_AR_INTERFACE[_COL]`;
  - SAP por empresa: `PKG_F8_INT_SAP`, `PKG_FR_F8_INT_SAP`, `PKG_FAIQ_F8_INT_SAP`;
  - otros: `PKG_CMP_PRS_TJE` (retenciones), `PKG_VTA_F8UYALL` (reporte Uruguay).
- Secuencias: `SEQ_VTA_*` (muchas por país, p. ej. `SEQ_VTA_<pfx>PRS`), `SEQ_OF_CORP_GL_INTERFACE`, `SEQ_SAP_*`, `SEQ_TES_*`.

### 4.7 Módulos compartidos

- **`Módulo1.bas`** (unas 6.900 líneas):
  - conexiones, variables de sesión, constantes de perfiles, medios de pago (`GEfectivo`…`GValeAlimento`), monedas (`DOLAR = "305"`, `EUROS = "304"`, …) y `Gversion`;
  - validaciones de sesión: `LeeParametros`, `LeePeractual`, `LeeFechaServidor`;
  - SQL de negocio: compensaciones (`StrCompensado`, `StrSumCompensado*`, `StrPorCompensado`), validación de Z/Y (`FuncValidarZoY`, `CuadraturaZZYY`, `FuncValidaZZZ`, `ValidarCuadraturaZY`), contabilización (`StrContable*`, `ConsultaContabilizado`), tesorería (`GrabaTesoreria`) y cheques (`Func_Valor*Cheque*`);
  - utilidades: `Passwords`, `Fuctiondatoparam`, `ProLeeLocales`, `GeneraCualquierExcel(grid, ruta)` (exporta cualquier grilla).
- **`Modulo2.bas`** (`Module1`):
  - tipos `Registro_*` para leer archivos de carga (banco, Prosegur, sobres);
  - constantes de permisos y de formato de fecha;
  - lectura de INI (`Lee_Ini`) y acceso al registro;
  - funciones de terminal: `Est_TermStat`, `Grabar_termstat[YYY]`, `TerminalCuadrado`, `TerminalCerrado`, `AperturaTerminales`, `BuscarRec*` (montos recaudados por tipo);
  - moneda extranjera: `TraeTasaCambio`, `InsertaMovMonedaSoar`;
  - `Main` / `MainFinal`.
  
  Buena parte del archivo es código heredado del asistente de instalación de VB (constantes `gstr*`, `mstr*`) que no se usa.
- **`Register.bas`** (`Rutinas_Registro`): registro de Windows, INI y `Func_cofiguracion`. **`mlocaleinfo.bas`** (`mConfiguracionRegional`): `PonerConf1`/`PonerConf2` cambian los separadores regionales de Windows. **`LogSistemaF8.bas`**: log de accesos.

### 4.8 Integraciones externas

- **Archivos de entrada**: se leen con `Open … For Input`:
  - depósitos y cartolas bancarias: `Form57`, `Form95`;
  - escucha de efectivo: `Form124`/`Form99`.
  
  Las cargas de sobres desde Excel usan `Workbooks.Open` (`Form81`, `Form133`, `Form155`, `Form171`).
- **Archivos de salida**: `Form37` (interfaz vendedor-cajero, que abre el resultado en `notepad`) y `Form126` (sobres pendientes Prosegur). Unos 78 formularios exportan a Excel.
- **Impresión directa** con el objeto `Printer`: libro de ventas (`Form24`, `Form79`), informes de conceptos (`Form15`, `Form26`, `Form36`) y recaudación (`Form88`, `Form89`).
- **Correo**: CDO en `Form89` (envío de recaudación).
- **Autoactualización**: `actuf8.exe` (ver §2).

## 5. Catálogo de formularios por dominio

El nombre `FormNNN` no indica la función. Para ubicar una pantalla conviene buscar su título (`Caption`) o la clave de toolbar en `MDIForm1.frm`. Entre corchetes va el archivo cuando difiere del nombre.

- **Sesión y marco**:
  - `Form1` login, `Form22` cambio de clave, `Form87` selección de perfil;
  - `MDIForm1` contenedor, `frmwait` espera, `frmLogOraError` [Logoerr.frm] errores;
  - `FrmFechaContable` selección de fecha contable.
- **Cuadratura F8**:
  - pantallas principales: `Form3` F8 por terminal (Z), `Form3Y` F8 con cierres Y, `Form8` F8 general/empresa (`Gopcion` G/E), `Form104` [V1.frm] cuadratura por operador (reglas y SQL del cierre de Y y Z para Colombia en `docs/CierreCaja_FACO_Reglas.md`; análisis de la HU de compensación DI automática en `docs/FSCC-12901_Analisis.md`);
  - impresión y estado: `Form9` impresión F8, `Form2` estado general de terminales;
  - detalles: `Form10` diferencia de caja, `Form11` cheques/vendedor, `Form12` dólares por terminal, `Form14` retiros por terminal, `Form97` transacciones de terminal;
  - consultas: `Form43` consultas de cuadratura (análisis para Colombia y del botón Cerrar Terminal en `docs/CC_ConsultaCuadratura_FACO.md`; **en FACO, desde FSCC-12901, el informe "Terminal" y "Cerrar Terminal" delegan en `PKG_F8_FACO_CIERRE_AUTO`** (`SubBuscarOpcionFACO`, `CierreTerminalFACO`; opción 1515), ver `docs/README_FSCC-12901.md` §5c), `Form98` / `Form107` (SFCL) estado en línea, `Form105` antesala, `Form139` KPI local, `Form116` control de dinero acumulado.
- **Cierres**:
  - ingreso de Z: `Form19` (general), `Form19_2` (Perú; también "ZLV" con `Type_Ingreso_Z = "F8L"`), `Form19_3` (Argentina);
  - `Form19Y` ingreso de cierres Y;
  - `Form20` reapertura, `Form52` cierre general del local, `Form39` fecha histórica, `Form150` mantención de la fecha de actualización del libro de ventas.
- **Compensaciones y regularizaciones**:
  - diferencias de caja: `Form4` compensación de diferencia de caja, `Form17` compensación de cierre Y, `Form51`, `Form6` distribución de diferencias por VC, `Form59` compensación de cuadratura;
  - vendedor/cajero: `Form13` datos vendedor/cajero, `Form53` compensación cajeros-vendedores, `Form37` interfaz diferencia vendedor-cajero;
  - registros: `Form23` regularizaciones, `Form28` devolución de cheque, `Form29` billetes falsos, `Form30` NC publicidad, `Form31` / `Form35` dotaciones;
  - diferencia no imputable: `Form38` diferencia no imputable / arqueo, `Form131` su detalle;
  - otros: `Form45` / `Form42` [Form128.frm] observaciones, `Form112` / `Form120` / `Form111` sobrantes de vale de crédito, `Form54` ticket uniforme contado, `Form55`, `Form171` carga masiva de compensaciones, `Form71` interfaz de diferencia.
- **Cartas aviso**: `Form16`, `Form18`, `Form56`, `Form60`, `Form63`, `Form93`; `Form63_2` transacciones Posnet / transferencia bancaria.
- **Certificados, documentos y vales**:
  - certificados: `Form61`, `Form64`, `Form64_2`, `Form94`, y `Form160` certificado por código de barra (Cornershop);
  - documentos: `Form77`, `Form100`;
  - vales y efectivo: `Form137` vales de alimentos, `Form99` [Form124.frm] efectivo.
- **Cheques**: `Form49` gestión de cheques, `Form49_2` auditoría, `Form101`, `Form102`, `Form103` y `Form138` (cheques y su detalle), `Form96` cheque a depósito.
- **Moneda extranjera**: `Form27` gestión de USD y euros, `Form46` tasa de cambio.
- **Tarjetas y movimientos**: `Form34`, `Form34_2`, `Form34_3` detalle de tarjetas; `Form44` / `Form69` detalle de movimiento; `Form135`, `Form136`.
- **Sobres y transportadora (Prosegur/LGS)**:
  - ingreso: `Form21` sobres de depósito, `Form81` ingreso de sobres (SFCL), `Form66` por código de barra, `Form110` / `Form152` / `Form154` ingreso manual;
  - ajustes y consultas: `Form5` conteo de sobres, `Form5_2` cambio de sobre de cajero, `Form68` consulta de cargas, `Form123` relacionar sobre;
  - carga PRD: `Form32` borrar carga PRD, `Form133` / `Form155` carga manual (Excel), `Form134` errores de carga PRD, `Form130` interfaz de validación;
  - pareo y grupos: `Form40` [Form41.frm] pareo de sobre no enviado, `Form80` grupos Prosegur;
  - recaudación y depósitos: `Form88` recaudación de sobres, `Form89` envío de recaudación, `Form106` depósitos, `Form108` detalle de recuento;
  - informes: `Form113` terminales pistoleados, `Form114` / `Form127` informe general de sobres, `Form126` sobres pendientes, `Form129` VC rechazados, `Form70` sobres pistoleados vs efectivo;
  - detalles y control: `Form115` operador de caja, `Form117` / `Form118` / `Form119` / `Form121` detalles, `Form122` registro de transacciones.
- **Banco y conciliación**:
  - carga: `Form57` / `Form84` depósitos bancarios, `Form95` reproceso de cartola;
  - conciliación: `Form58` conciliación de recaudación, `Form65` / `Form67` detalles, `Form82` depósitos emitidos por tesorería;
  - pareo: `Form83` pareo manual, `Form85` proceso de pareo, `Form86` despareo, `Form90` consultas de pareo;
  - `Form172` / `Form173` cuadratura de efectivo API vs cartola.
- **Recicladoras (SFCL)**: `Form162` recicladora, `Form163` depósito de máquina depositaria, `Form164` [Form164x.frm] dice contener, `Form164_2` [Form164.frm], `Form165` consulta de depósitos, `Form166` / `Form167` transacciones, `Form168` asociación manual de sobres, `Form169` sobres en proceso, `Form170` número de depósito.
- **Validación de Z / Z virtual**: `Form74` fórmula de validación de Z (ZZZ), `Form78` estado de validación de Z, `Form140` / `Form141` / `Form142` Z virtual.
- **Contabilidad**:
  - Oracle Financials: `Form62` envío a FOSO (unas 15.500 líneas), `Form72` envío a FOSO para SOAR/SOUY (unas 18.700 líneas, casi copia de `Form62`), `Form132` resultado del envío;
  - SAP: `Form159` envío contable;
  - mantenedores: `Form156` centros de costo y cuentas, `Form156_2` mantenedor BP / transportadora, `Form157` BP tienda, `Form158` asociación de operaciones, `Form161` mantenedor de cuentas.
- **Libro de ventas**: `Form33` consulta, `Form24` / `Form79` impresión, `Form25` impresora oficial.
- **Informes**: `Form7` diferencias de compensaciones (unas 17.500 líneas), `Form15`, `Form26` y `Form36` (conceptos de compensación), `Form48` informes de diferencias.
- **Administración**: `Form47` perfiles, `Form151` usuarios, `Form50` terminales POS Mobile / Autopago.

## 6. Configuración

- `FTEPROD/Setup.ini` es el archivo que usa el exe. Secciones `[CONNECT]`, `[CONNECT2]`, …, cada una con `USER`, `PASS` (codificada con el esquema inverso a `Passwords()`) y `BASE` (alias TNS). Las variantes `Setup_*.ini` y `ManUSR_des.ini` / `LibroVenta_desa.ini` son de desarrollo, test o producción; según el ambiente se copian sobre `Setup.ini` junto al exe.
- `NombreEquipo` / `GetRuta` (`MDIForm1`) leen una ruta de INI adicional desde `vta_sfclparam` (tipo 6200).
- Las credenciales de los INI son reales y la codificación de `PASS` es trivial de revertir: no copiarlas en código, commits, documentación ni respuestas.

## 7. Convenciones al modificar

- Seguir el estilo del código vecino: Hungarian/VB clásico (`sq`, `st` para SQL; `vfecha`, `VLocal`, `vterminal`, `vcierrey` como parámetros), patrón de Recordset de §4.5 y `SystemMsg` + `frmLogOraError` para errores.
- Marcar cada cambio con un comentario de iniciales/proveedor y número de caso, como hace el código existente: `'CK: 162715 - descripción`, `'MM: 166355 - …`, `'---INI---- Xintec <mes año> ----` … `'---FIN----`. No borrar el código anterior: el estilo de la casa es dejarlo comentado.
- Cualquier cambio en un flujo de cuadratura o cierre debe revisar las variantes paralelas, que están duplicadas y no comparten código:
  - `Form3` / `Form3Y` / `Form8` / `V1.frm`, que repiten `LeeZ`, `LeeTes`, `LeeRetiros`, `LeeProsegur`, `ARMA_QUERY_Z`;
  - `Form19` / `Form19_2` / `Form19_3` / `Form19Y`;
  - `Form62` / `Form72`;
  - `Form34` / `Form34_2` / `Form34_3`;
  - los seis formularios de carta aviso.
- La mayoría de los archivos no tiene `Option Explicit` (173 de 177): una variable mal escrita no da error de compilación, crea una variable nueva. Revisar los nombres con cuidado.
- No hay transacciones: en procesos de varios pasos (cierres, envíos contables) un error a mitad de camino deja datos parciales. Mantener el orden de las sentencias existentes y validar antes de escribir.

## 8. Riesgos y deuda técnica conocidos

- **SQL armado por concatenación** con texto de la interfaz, incluido el login (`VerificaUsuarioMulti` en `form1.frm` inserta `lusername.Text` directamente). Es vulnerable a inyección y falla con apóstrofes. En código nuevo, como mínimo hay que escapar `'` y validar numéricos; ADO permite `ADODB.Command` con parámetros (ejemplo en `Form173`).
- Credenciales de base en INI con ofuscación reversible (`Chr(n-10)`) y contraseñas antiguas comentadas en `form1.frm`.
- `PonerConf2` modifica la configuración regional de Windows del usuario.
- Formularios gigantes y duplicados (`Form72` ≈ `Form62`; `Form7`, `Form3`, `Form8` con miles de líneas), lógica de negocio en eventos de controles (`LabelNN_Click`) y estado compartido en decenas de globales.
- Constantes de fecha fijas en código (`fechamov = "31-10-2018"`, `FechaLimiteCheque`, `VG_Fecha_*_Valid`) que condicionan consultas.
- Índices de botones del toolbar fijos en el código: insertar un botón en medio desplaza todos los índices y rompe `SubBuscarOpcionMenu` y los permisos guardados en la base.
- No es un repositorio git. El historial está en los `.bak`, en los exe con fecha y en los comentarios por caso.

## 9. Documentación de requerimientos y scripts de base de datos

- `docs/` guarda los análisis y entregables de cada requerimiento. **Empezar por el índice del requerimiento**; para FSCC-12901 (compensación DI y cierre automático en Colombia) es `docs/README_FSCC-12901.md`: estado, artefactos, decisiones, datos verificados en la base, pendientes y cómo retomar.
- Los scripts Oracle van en `docs/sql/<ticket>/`, numerados en orden de ejecución, con `README.md`, `00_prechecks.sql` (solo lectura) y `99_rollback.sql`. Convenciones:
  - sin prefijo de esquema (se ejecutan conectado como el dueño de las tablas `VTA_*`);
  - solo ASCII;
  - compatibles con Oracle 10.2 (sin `LISTAGG`, compound triggers ni `IDENTITY`).
- Cuando un requerimiento tiene subtareas, cada una tiene su carpeta (`docs/sql/FSCC-12957/`, `docs/sql/FSCC-12958/`). Además hay una **carpeta consolidada que es la que se instala** (`docs/sql/FSCC-12901_T1_T2/`, con `INSTALAR.sql`). Sus scripts copiados indican la fuente en el encabezado: al cambiar uno, actualizar también la copia.
- Como no hay git, antes de hitos importantes (por ejemplo las pruebas) se congela el estado con:
  - un **manifiesto MD5**: `docs/MANIFIESTO_<ticket>.md5`; se verifica con `grep -v '^#' … | md5sum -c`;
  - un **respaldo ZIP** en `docs/respaldos/`;
  - una fila en el historial (§9) del índice del requerimiento.
- Si un requerimiento toca el exe, el `.frm` se respalda antes como `<archivo>.bak_<ticket>` y se edita en modo binario (Perl `:raw`) para conservar Windows-1252 y CRLF; el formulario y su respaldo entran en el manifiesto y en el ZIP.
- Base de test: accesible solo con la VPN Fortinet. Datos de conexión (sin clave) en `docs/README_FSCC-12901.md` §8.

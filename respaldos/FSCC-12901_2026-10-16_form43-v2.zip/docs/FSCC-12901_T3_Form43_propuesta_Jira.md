# Propuesta de subtarea Jira: HU-01-T3 (Form43, DF-SCC fila 12)

Texto listo para crear la subtarea bajo **FSCC-12901**.

Origen: Excel DF-SCC (`docs/Requeriemintos-FSCC-12901/DF-SCC-vf_Falabella CO (MEJORAS F8 y COMPENSACIONES MENORES).xlsx`, fila 12). El pedido no figura en el texto de FSCC-12901, FSCC-12957 ni FSCC-12958.

Estado al 16-10-2026:
- **Desarrollado** en `FTEPROD/Form43.frm` (marcas `'---INI---- xintec-nruz 16-10-2026 FSCC-12901`), sobre el paquete `PKG_F8_CIERRE_AUTO` (PROC_Y), que ya está en test.
- **Pendiente:** compilar el exe y probar.

---

```
Titulo: HU-01-T3 · Consultas de Cuadratura Colombia: mostrar cajas con Diferencia Real 0 y Cerrar Terminal

Descripcion
T3 ajusta la pantalla Consultas de Cuadratura (Form43) para Falabella Colombia (FACO), segun
el DF-SCC fila 12: la pantalla debe mostrar tambien las cajas sin diferencia (Diferencia Real 0),
como en Chile, y permitir cerrarlas desde ahi, para evitar el archivo "dataload" de cierre de cajas.

Situacion actual: en Colombia la grilla del informe "Terminal" solo muestra las cajas con
Diferencia Real distinta de 0, y el boton "Cerrar Terminal" solo cierra las de Diferencia Real 0.
Por eso el boton nunca cierra nada y siempre responde "No hay Terminales que Cumplan con el
Proceso de Cierre". Ademas, el boton aparece para todos los perfiles.

Complementa a T1 y T2: el proceso automatico cierra las cajas que quedan en 0 al cargar. T3 cubre
las que el analista cuadra despues a mano (compensacion o correccion de la Y).

Reglas
- Solo cierres Y. Colombia no gestiona la Z desde esta pantalla.
- La grilla "Terminal" muestra todos los cierres Y con libro de ventas del rango de fechas, del
  local y del terminal elegidos, incluidos los de Diferencia Real 0, con su estado (Pendiente,
  Cerrado, Impreso).
- Las columnas Dif. de Caja, Compensacion y Diferencia Real se calculan con la misma logica del
  proceso automatico (PKG_F8_CIERRE_AUTO), igual que la F8 de la Y.
- "Cerrar Terminal" cierra las Y abiertas de UN dia, del local y terminal elegidos (terminal 0 =
  todos), que tengan Diferencia Real 0 y cumplan las mismas validaciones de Cerrar Terminal de la
  F8 Y (cheques a fecha, conceptos sin regularizar, formula ZZZ segun parametro).
- La Y queda cerrada con el usuario del analista (no con el usuario de proceso).
- Lo no cerrado queda en el log VTA_FACOLOG_CIERRE_AUTO (proceso CC) con su motivo, y la
  pantalla informa la cantidad de cerradas y no cerradas.
- El boton se muestra solo a los perfiles con la opcion 1515 "Cerrar Terminal desde Consulta
  Cuadratura". Negocio define a que perfiles se habilita.
- Otros paises sin cambios.

Criterios de aceptacion
# | Dado | Cuando | Entonces
1 | un local-dia con Y de Diferencia Real 0 y Y con diferencia | se consulta el informe "Terminal" | aparecen todas las Y, incluidas las de Diferencia Real 0, con sus columnas y su estado
2 | las columnas de una Y en la grilla | se comparan con la F8 de esa Y | Dif. de Caja, Compensacion y Diferencia Real son iguales
3 | un perfil sin la opcion 1515 | abre la pantalla | no ve el boton "Cerrar Terminal"
4 | un perfil con la opcion 1515 y un rango de fechas de mas de un dia | presiona "Cerrar Terminal" | se le pide seleccionar un solo dia y no se cierra nada
5 | una Y abierta con Diferencia Real 0 y sin pendientes | se cierra el dia desde la pantalla | la Y queda Cerrada, con el usuario del analista, y la grilla se refresca
6 | una Y con Diferencia Real distinta de 0 o con un concepto pendiente de regularizar | se cierra el dia desde la pantalla | la Y no se cierra y el motivo queda en el log; la pantalla informa las no cerradas
7 | una Y compensada a mano hasta quedar en 0 (ej.: excluida por el proceso automatico por rango) | se cierra el dia desde la pantalla | la Y queda Cerrada
8 | un usuario de otro pais | usa Consultas de Cuadratura | la pantalla funciona igual que antes

Estado: desarrollado en Form43.frm (16-10-2026); pendiente compilar el exe, probar en test y
definir los perfiles de la opcion 1515.
```

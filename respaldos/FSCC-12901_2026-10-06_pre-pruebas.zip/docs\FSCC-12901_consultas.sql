-- FSCC-12901: consultas de solo lectura para cerrar los pendientes del análisis
-- Uso: sqlplus usuario@ALIAS_TNS @FSCC-12901_consultas.sql
--      (sqlplus pide la clave; el resultado queda en FSCC-12901_resultado.txt)
set linesize 250 pagesize 500 long 100000 trimspool on feedback on
spool FSCC-12901_resultado.txt

prompt === 1. Rango actual de la DI manual (vta_FACOparam 1500/1501)
select vta_ccodtipo, vta_ccodigo, vta_xglosa
from   vta_FACOparam
where  vta_ccodtipo in (1500, 1501)
order  by vta_ccodtipo, vta_ccodigo;

prompt === 2. Posible doble conteo en la compensacion (D12): mas de una fila por rama?
select mov_tipomov, vta_coddif
from   vta_FACOconcepdif
where  mov_tipomov in ('NP','FT') or vta_coddif = 1
order  by mov_tipomov;

prompt === 3. Fuente del paquete de Chile (procedimiento cierre_terminal_di)
select type, line, text
from   all_source
where  name = 'PKG_F8_COMPENSACION_DI'
order  by type, line;

prompt === 4. Cuantas DI hay por Y (deberia ser una sola con mov_rol = 0)
select mov_fecha, mov_local, mov_terminal, mov_cierrey, mov_rol, count(*) cantidad
from   vta_FACOmovdet
where  mov_tipomov = 'DI'
and    mov_fecha >= trunc(sysdate) - 60
group  by mov_fecha, mov_local, mov_terminal, mov_cierrey, mov_rol
having count(*) > 1;

prompt === 5. Distribucion de la DI manual de los ultimos 60 dias (para dimensionar el rango)
select count(*) cantidad,
       min(mov_monto) minimo, max(mov_monto) maximo,
       sum(case when mov_monto between -1000 and 20000 then 1 else 0 end) en_rango
from   vta_FACOmovdet
where  mov_tipomov = 'DI'
and    mov_fecha >= trunc(sysdate) - 60;

prompt === 6. Sobres cargados sin cierre Y (afectan la DR de la Y)
select prv_fechavta, count(*) sobres_sin_y
from   vta_FACOprd
where  prv_fechavta >= trunc(sysdate) - 60
and    prv_tiporec = 'F8'
and   (prv_cierrey is null or prv_cierrey = 0)
group  by prv_fechavta
order  by prv_fechavta;

prompt === 7. Y cerradas cuya Z fue reabierta por la carga (riesgo P12)
select t.ter_fecha, t.ter_local, t.ter_terminal, y.ter_cierrey, y.ter_estado estado_y, t.ter_estado estado_z, t.ter_notas
from   vta_FACOtermstat t, vta_FACOtermstaty y
where  t.ter_fecha >= trunc(sysdate) - 60
and    t.ter_notas = 'CARGA MANUAL DE SOBRES'
and    t.ter_estado = 0
and    y.ter_fecha = t.ter_fecha and y.ter_local = t.ter_local and y.ter_terminal = t.ter_terminal
and    y.ter_estado = 1
order  by 1, 2, 3, 4;

spool off
exit

# FSCC-12958 (HU-01-T2): cierre de caja automático, Falabella Colombia (scripts de base de datos)

> **Para instalar T1 + T2 juntos usar la carpeta consolidada [`../FSCC-12901_T1_T2/`](../FSCC-12901_T1_T2/README.md).** Esta carpeta documenta solo esta subtarea; sus scripts son la fuente de las copias de la carpeta consolidada (mantener ambas iguales).

Este enfoque resuelve el cierre automático completo en Oracle: una cola alimentada por un trigger sobre `VTA_FACOPRD` y un procedimiento que se ejecuta aparte. El exe VB6 no se modifica.

```
Form133 / Form21 / Form124 …  ──INSERT──▶ VTA_FACOPRD
                                              │ TRG_VTA_FACOPRD_CIERRE_AI (F8, DOL)
                                              ▼
                                     VTA_FACOPRD_CIERRE  (cola, estado P)
                                              │
     job externo ──▶ PKG_F8_FACO_CIERRE_AUTO.PRC_CIERRE_AUTOMATICO
                                              │  por cada cierre Y pendiente:
                                              │   estado → DR = 0 → validaciones → cierra Y
                                              │  por cada terminal-día tocado:
                                              │   todas las Y cerradas → DR Z = 0 → validaciones → cierra Z
                                              ▼
                        VTA_FACOTERMSTATY / VTA_FACOTERMSTAT  +  VTA_FACOLOG_CIERRE_AUTO
```

## Orden de ejecución

**Ningún script tiene el esquema escrito fijo.** Los objetos se crean y se referencian por nombre (`VTA_FACOPRD_CIERRE`, no `<esquema>.VTA_FACOPRD_CIERRE`), así que se resuelven en el esquema de la sesión. Por eso:

- **Los scripts 00 a 06 y 08 se ejecutan conectado como el dueño del esquema** donde están las tablas `VTA_FACO*`. En test es el dueño de `VTA_FACOPRD`; se averigua con `select owner from all_tables where table_name = 'VTA_FACOPRD'`. El usuario de aplicación no sirve para instalar: no tiene privilegios `CREATE`.
- Si el DBA instala con su propio usuario, debe ejecutar antes `alter session set current_schema = <dueño>`.
- **El script 07** toma el dueño de la sesión (`sys_context('USERENV','CURRENT_SCHEMA')`) y **pide** el usuario de aplicación (`accept`). Los permisos los da el dueño; los sinónimos, el DBA (`CREATE ANY SYNONYM`).
- **Derechos del dueño (definer rights).** El paquete y su SQL dinámico se ejecutan con los privilegios del dueño. Si alguna tabla `VTA_FACO*` o `VTA_PAINT_Z` no fuera del mismo esquema, el dueño necesita un **grant directo** (no a través de un rol) sobre ella. En test, todas son del mismo esquema.

| # | Script | Contenido |
|---|---|---|
| 0 | `00_prechecks.sql` | Verificaciones previas de solo lectura en el ambiente destino; cada consulta indica el resultado esperado |
| 1 | `01_tabla_homologa.sql` | Tabla `VTA_FACOPRD_CIERRE` (tipos heredados de `VTA_FACOPRD`), índices y `SEQ_VTA_FACOPRD_CIERRE` |
| 2 | `02_log.sql` | `VTA_FACOLOG_CIERRE_AUTO` + secuencia (el "Registro de ejecución" del diagrama) |
| 3 | `03_parametros.sql` | Flags en `VTA_FACOPARAM` tipo 1502. **Ejecutar antes las dos consultas de verificación** |
| 4 | `05_pkg_cierre_auto_spec.sql` | Especificación del paquete. Públicas: `prc_cierre_automatico`, `fn_dif_real`, `pr_valida_y`, `pr_valida_z`, `fn_param` y cada validación por separado (`fn_msg_cheque_fecha`, `fn_concepto_pendiente`, `fn_zzz`, `fn_msg_z_suma_y`, `fn_msg_y_abiertas`, `fn_dif_dolares`). Privadas (dependen del estado de la ejecución): `pr_log`, `fn_dec`, `fn_conceptos`, `pr_marca_cola`, `fn_nota`, `pr_procesa_y`, `pr_procesa_z` |
| 5 | `06_pkg_cierre_auto_body.sql` | Cuerpo del paquete. **Llama a T1** (`PKG_F8_FACO_COMPENSA_DI.prc_compensa_di`, FSCC-12957) antes de cerrar: **instalar antes la especificación y el cuerpo de T1** (orden conjunto en `../FSCC-12957/README.md`) |
| 6 | `04_trigger.sql` | Trigger. **Va al final**, para no encolar sobres antes de que el proceso esté compilado |
| 7 | `07_grants_sinonimos.sql` | Permisos (como dueño) y sinónimos (como DBA) para el usuario de aplicación o del job, que el script pide al ejecutarse |
| 8 | `08_pruebas.sql` | Pruebas en test |
| — | `99_rollback.sql` | Reapertura opcional de una ejecución y desinstalación |

**Llamada del job:**

```sql
-- como dueño, o como usuario de aplicación a través del sinónimo
begin PKG_F8_FACO_CIERRE_AUTO.prc_cierre_automatico('PROC_CIERRE_AUTO'); end;
```

Cómo se agenda (DBMS_JOB, cron o un orquestador) está fuera del alcance.

## Integración con T1 (FSCC-12957, compensación automática de DI)

`prc_cierre_automatico` es el único punto de entrada del job y sigue el orden del diagrama general:

1. Marca en la cola los sobres sin Y (`O`) y los vencidos (`V`).
2. Llama a `PKG_F8_FACO_COMPENSA_DI.prc_compensa_di`, que registra la DI de las cajas con DR en el rango (si `CA_DI_ACTIVO = S`).
3. Si `CA_ACTIVO = S`, cierra las Y y las Z (T2).

Los interruptores son independientes: si los dos están en `N`, no se hace nada. El log distingue cada proceso con `log_proceso` (`T1` o `T2`). Un error en T1 se registra y no detiene T2. Detalle en [`../FSCC-12957/README.md`](../FSCC-12957/README.md).

## Parámetros (`VTA_FACOPARAM`, tipo 1502)

| Código | Valor inicial | Uso | Equivalente en el exe |
|---|---|---|---|
| `CA_ACTIVO` | S | Proceso activo ("T2 activa" del diagrama general) | — |
| `CA_VAL_CHEQ` | S | Valida cheque a fecha: gestión = tesorería | RY-01 / RZ-01. En la Z, el exe exime a los perfiles 8, 10 y 12 |
| `CA_VAL_ZZZ` | N | Valida la fórmula ZZZ | Opción de perfil 103 |
| `CA_VAL_USD` | N | Valida dólares declarados contra Prosegur | Opción de perfil 109 |
| `CA_DECIMAL` | 0 | Decimales para redondear la DR y las comparaciones | `gFormat` de Colombia (**verificar** `vta_parametros`) |
| `CA_DIAS` | 30 | Días que una caja pendiente se sigue reevaluando | — |

## Reglas implementadas

Se evalúan en orden; la primera que falla bloquea la caja.

**Cierre de la Y** (`Form3Y.CierraTerminal`, `FTEPROD/Form3Y.frm:2801`). El orden sigue el diagrama del proceso 2: estado → DR → validaciones.

| Regla | Qué valida | Resultado en el log |
|---|---|---|
| Bloqueo | `FOR UPDATE NOWAIT` sobre `termstaty` | `OCUPADA` |
| RY-02 | `ter_estado > 0`. **No se reabren** Y cerradas, impresas ni sin datos | `YA_CERRADA` |
| — | Sin libro de ventas de la Y | `SIN_LIBVTA` |
| RY-05 | Diferencia real ≠ 0 (`fn_dif_real`) | `CON_DIFERENCIA` |
| RY-01 | Cheque a fecha (si `CA_VAL_CHEQ = S`) | `BLOQUEADA` |
| RY-03 | Conceptos sin regularizar en la Y: SN, AF, ND, FN, NP, BF, CR, CT, CA (cartaaviso), DP | `BLOQUEADA` |
| RY-06 | Fórmula ZZZ (si `CA_VAL_ZZZ = S`) | `BLOQUEADA` |
| Cierre | `ter_estado = 1`, `ter_cerradopor = PROC_CIERRE_AUTO`, `ter_notas = 'CIERRE AUTOMATICO FSCC-12958 dd-mm-yyyy hh24:mi | <nota anterior>'` | `CERRADA_Y` |

**Cierre de la Z** (`Form3.CierraTerminal`, `FTEPROD/Form3.frm:3439`). Solo para los terminal-día que tuvieron Y en la ejecución.

| Regla | Qué valida |
|---|---|
| RZ-02 | Estado de la Z |
| RZ-07 | Todas las Y cerradas |
| RZ-05 | DR del día completo |
| RZ-01 | Cheque a fecha |
| RZ-03 | Conceptos del día |
| RZ-06 | Z = Σ Y, campo por campo según `VTA_PAINT_Z` (SQL dinámico) |
| RZ-08 | ZZZ (flag) |
| RZ-09 | Dólares (flag) |
| Cierre | Igual que la Y → `CERRADA_Z` |

**Diferencia real.** Es la de la F8 (`Label70`):

```
(prsefe − totefe) + (prschd − totchd) + USD + (teschf − totchf) + (tarjetas 2000–2999 − (rec_mtarj + rec_msodimac)) − compensado
```

El compensado son las 13 ramas de `Módulo1.StrSumCompensado`, con `UNION` como en el exe. Detalle en `docs/CierreCaja_FACO_Reglas.md` §2.

## Estados de la cola (`pcr_estado`)

| Estado | Significado |
|---|---|
| `P` | Pendiente. Se reevalúa en cada ejecución: `CON_DIFERENCIA`, `BLOQUEADA`, `SIN_LIBVTA`, `OCUPADA`, `ERROR`. Si el analista compensa o regulariza, el siguiente ciclo la cierra |
| `C` | Terminada: `CERRADA_Y` o `YA_CERRADA` |
| `O` | Omitida: el sobre no tiene cierre Y |
| `V` | Vencida: la fecha de venta es más antigua que `CA_DIAS` |

## Diferencias deliberadas con el exe

1. **Bug D1 corregido.** El exe pasa el local en lugar del número de Y a la ZZZ de la Y, así que en la práctica no valida. El paquete usa la Y real, y solo si `CA_VAL_ZZZ = S`.
2. **Z sin Y en el libro de ventas.** El exe avisa y deja cerrar; el proceso **no** cierra (RZ-07) y lo deja al analista.
3. **Cheque a fecha y perfiles.** Las validaciones que dependen del perfil pasan a flags.
4. **Tesorería en la Y.** `Form3Y.LeeTes` toma la primera fila de la Y; el paquete suma. Es equivalente si hay una fila por Y.
5. **Tarjetas.** No se valida el total de tarjetas, igual que el exe para Colombia, aunque el diagrama lo mencione.
6. **Errores.** Si una consulta falla, la caja queda en `ERROR` y se reintenta. En el exe algunas validaciones fallidas dejaban pasar.

## Supuestos verificados en la base de test (`sgfnprds`, 06-10-2026)

| Supuesto | Resultado | Impacto en los scripts |
|---|---|---|
| Estructura de `VTA_FACOPRD` | 29 columnas, PK en `prv_techkey`, **sin triggers**. `PRV_CIERREY` es `NUMBER(2)` NOT NULL con default 0 | 0 = sobre sin Y; queda en estado `O` |
| `VTA_PAINT_Z.vta_signo` | `CHAR(1)`, siempre `'+'` en FACO | El armado `signo || '1'` es correcto |
| Campos dinámicos de `VTA_PAINT_Z` (47 en FACO) | Todos existen, cada uno en **una sola** tabla (`libvta` o `zzz`) | El SQL dinámico sin prefijo de tabla funciona |
| Grupos ZZZ de FACO | 1 ventas; 2 abono/avance CMR, reversa recaudación, pago facturas; 3 recaudación; 6 gift card; 7 formas de pago | Fórmula F7−F6−…−F1 |
| `VTA_FACOPARAM` | 4 columnas; `VTA_DFECHAREG` NOT NULL con default `sysdate`; tipo 1502 libre | Los INSERT informan `vta_dfechareg` |
| Decimales | `vta_parametros` FACO: `VTA_NUMFORMAT = '#,#0'` (el `gFormat` del exe) y `VTA_DECROUND = 2` | `CA_DECIMAL = 0`. El compensado también se redondea **antes** de restarlo, como hace el exe |
| Tesorería | Una fila por Y en `VTA_FACOTESOR` | Sumar es equivalente a "primera fila" |
| `VTA_FACOTERMSTAT` | Sin duplicados por fecha/local/terminal | El `UPDATE` de la Z afecta una fila |
| Columnas de las tablas que lee el paquete (54 revisadas) | Todas existen | — |

### Revisión final (06-10-2026)

| Verificación | Resultado | Conclusión |
|---|---|---|
| Conceptos en `VTA_FACOCONCEPDIF` | Existen TC, SN, BF, NP, CA, CR, CT, DI, DN, DP, DT y VC. **No existen** ND, FN, AF, AL, TB, NC ni FT | Las ramas del compensado sin concepto no aportan, igual que en el exe. Las validaciones de pendientes de AF, ND y FN se buscan igual en `movdet`, como hace el exe |
| Acceso del usuario de aplicación | Accede a las tablas por sinónimos y no tiene privilegios `CREATE` | Instala el dueño o el DBA; los sinónimos los crea el DBA (script 07) |
| Tipos de `termstat` / `termstaty` | `ter_estado` NUMBER(1), `ter_cierrey` NUMBER(2), `ter_cerradopor` VARCHAR2(50), `ter_notas` VARCHAR2(2500) | Compatibles con lo que graba el paquete |
| Volumen | Unos 359 sobres F8 por día de depósito (test) | Trigger por fila liviano |
| Prefijo de esquema | 0 ocurrencias en los `.sql` | Portable a cualquier esquema |

## Riesgos y supuestos a revisar antes de producción

- **Trigger.** Hoy ignora sus propios errores para no frenar la carga de sobres. Ver el comentario en `04_trigger.sql` y la consulta de conciliación en `08_pruebas.sql`.
- **Convivencia con `PKG_F8_FACO_CIERRE_TER_PM_AP`.** Es el cierre `AUTOMATICO` de Autopago, que ya existe. Las dos rutas solo cierran cajas con estado ≤ 0 y este paquete bloquea con `NOWAIT`, pero conviene coordinar los horarios.
- **Producción puede diferir de test.** Ejecutar `00_prechecks.sql` en el ambiente destino; cada consulta indica el resultado esperado.
- **`CA_DECIMAL = 0`.** Una diferencia de 0,4 cuenta como 0, igual que en la F8 (`Format` con `'#,#0'`).
- **Y cerrada que recibe un sobre (P12).** No se reabre: queda `YA_CERRADA` en el log y la Z no cerrará por RZ-05 o RZ-06. La reapertura sigue siendo manual (`Form20`).
- **Sin transacción con la carga.** La cola se llena en la misma transacción del insert del sobre. Si la carga hace rollback, la fila de la cola también se revierte.

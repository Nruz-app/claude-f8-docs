-- =====================================================================
-- FSCC-12958 (HU-01-T2) Cierre de caja automatico - Falabella Colombia
-- 08 - Pruebas (ambiente de TEST). Ejecutar paso a paso.
-- Reemplazar &fecha (dd-mm-yyyy), &local, &terminal, &cierrey.
-- =====================================================================
set serveroutput on size 100000
set linesize 220 pagesize 200

-- ---------------------------------------------------------------
-- 0. Compilacion
-- ---------------------------------------------------------------
select object_name, object_type, status
  from all_objects
 where owner = sys_context('USERENV','CURRENT_SCHEMA')
   and object_name in ('PKG_F8_FACO_CIERRE_AUTO', 'TRG_VTA_FACOPRD_CIERRE_AI',
                       'VTA_FACOPRD_CIERRE', 'VTA_FACOLOG_CIERRE_AUTO');
select line, position, text from all_errors
 where owner = sys_context('USERENV','CURRENT_SCHEMA') and name = 'PKG_F8_FACO_CIERRE_AUTO' order by sequence;

-- ---------------------------------------------------------------
-- 1. Diferencia real: comparar contra la F8 (Form3Y, campo "Diferencia Real")
--    para al menos 10 cajas. Deben coincidir.
-- ---------------------------------------------------------------
select y.ter_fecha, y.ter_local, y.ter_terminal, y.ter_cierrey, y.ter_estado,
       PKG_F8_FACO_CIERRE_AUTO.fn_dif_real(y.ter_fecha, y.ter_local, y.ter_terminal, y.ter_cierrey) dr_y,
       PKG_F8_FACO_CIERRE_AUTO.fn_dif_real(y.ter_fecha, y.ter_local, y.ter_terminal, null)          dr_z
  from VTA_FACOTERMSTATY y
 where y.ter_fecha >= trunc(sysdate) - 60
   and rownum <= 20
 order by 1, 2, 3, 4;

-- ---------------------------------------------------------------
-- 2. Validaciones sueltas de una caja
-- ---------------------------------------------------------------
declare
  r varchar2(10); m varchar2(1000);
begin
  PKG_F8_FACO_CIERRE_AUTO.pr_valida_y(to_date('&fecha','dd-mm-yyyy'), &local, &terminal, &cierrey, r, m);
  dbms_output.put_line('Y -> ' || nvl(r, 'OK') || ' ' || m);
  PKG_F8_FACO_CIERRE_AUTO.pr_valida_z(to_date('&fecha','dd-mm-yyyy'), &local, &terminal, r, m);
  dbms_output.put_line('Z -> ' || nvl(r, 'OK') || ' ' || m);
end;
/

-- 2b. Cada validacion por separado (funciones publicas)
select PKG_F8_FACO_CIERRE_AUTO.fn_msg_cheque_fecha(to_date('&fecha','dd-mm-yyyy'), &local, &terminal) ry01_rz01_cheque,
       PKG_F8_FACO_CIERRE_AUTO.fn_zzz(to_date('&fecha','dd-mm-yyyy'), &local, &terminal, &cierrey)     ry06_zzz_y,
       PKG_F8_FACO_CIERRE_AUTO.fn_zzz(to_date('&fecha','dd-mm-yyyy'), &local, &terminal, null)         rz08_zzz_z,
       PKG_F8_FACO_CIERRE_AUTO.fn_msg_z_suma_y(to_date('&fecha','dd-mm-yyyy'), &local, &terminal)     rz06_z_suma_y,
       PKG_F8_FACO_CIERRE_AUTO.fn_msg_y_abiertas(to_date('&fecha','dd-mm-yyyy'), &local, &terminal)   rz07_y_abiertas,
       PKG_F8_FACO_CIERRE_AUTO.fn_dif_dolares(to_date('&fecha','dd-mm-yyyy'), &local, &terminal)      rz09_dolares
  from dual;

-- fn_concepto_pendiente devuelve BOOLEAN: se prueba desde PL/SQL
declare
  type t_tipos is table of varchar2(2);
  v t_tipos := t_tipos('SN','AF','ND','FN','NP','BF','CR','CT','CA','DP');
begin
  for i in 1 .. v.count loop
    dbms_output.put_line(v(i) || ' Y: ' ||
      case when PKG_F8_FACO_CIERRE_AUTO.fn_concepto_pendiente(to_date('&fecha','dd-mm-yyyy'), &local, &terminal, &cierrey, v(i))
           then 'PENDIENTE' else 'ok' end ||
      '   Z: ' ||
      case when PKG_F8_FACO_CIERRE_AUTO.fn_concepto_pendiente(to_date('&fecha','dd-mm-yyyy'), &local, &terminal, null, v(i))
           then 'PENDIENTE' else 'ok' end);
  end loop;
end;
/

-- ---------------------------------------------------------------
-- 3. Trigger: cargar un sobre con Form133 (o insertar en VTA_FACOPRD) y
--    verificar la fila en la cola
-- ---------------------------------------------------------------
select * from VTA_FACOPRD_CIERRE order by pcr_id desc;

-- Conciliacion: sobres F8/DOL sin fila en la cola (trigger fallo o era anterior)
select p.prv_techkey, p.prv_fechavta, p.prv_local, p.prv_terminal, p.prv_cierrey
  from VTA_FACOPRD p
 where p.prv_tiporec in ('F8', 'DOL')
   and p.prv_fechadep >= trunc(sysdate) - 1
   and not exists (select 1 from VTA_FACOPRD_CIERRE q where q.prv_techkey = p.prv_techkey);

-- ---------------------------------------------------------------
-- 4. Ejecucion del proceso
-- ---------------------------------------------------------------
begin
  PKG_F8_FACO_CIERRE_AUTO.prc_cierre_automatico('PROC_CIERRE_AUTO');
end;
/

-- Resumen de la ultima ejecucion
select l.log_nivel, l.log_fecha_vta, l.log_local, l.log_terminal, l.log_cierrey,
       l.log_dif_real, l.log_resultado, l.log_regla, l.log_mensaje
  from VTA_FACOLOG_CIERRE_AUTO l
 where l.log_ejecucion = (select max(log_ejecucion) from VTA_FACOLOG_CIERRE_AUTO)
 order by l.log_id;

select log_resultado, log_regla, count(*)
  from VTA_FACOLOG_CIERRE_AUTO
 where log_ejecucion = (select max(log_ejecucion) from VTA_FACOLOG_CIERRE_AUTO)
 group by log_resultado, log_regla order by 1, 2;

-- Cajas cerradas por el proceso
select ter_fecha, ter_local, ter_terminal, ter_cierrey, ter_estado, ter_cerradopor, ter_notas
  from VTA_FACOTERMSTATY where ter_cerradopor = 'PROC_CIERRE_AUTO' order by 1, 2, 3, 4;
select ter_fecha, ter_local, ter_terminal, ter_estado, ter_cerradopor, ter_notas
  from VTA_FACOTERMSTAT  where ter_cerradopor = 'PROC_CIERRE_AUTO' order by 1, 2, 3;

-- ---------------------------------------------------------------
-- 5. Matriz de casos (preparar datos en test y verificar resultado del log)
-- ---------------------------------------------------------------
-- T01 Y con DR 0 y sin pendientes                  -> CERRADA_Y; si es la unica Y -> CERRADA_Z
-- T02 Y con DR distinta de 0                       -> CON_DIFERENCIA RY-05, cola sigue 'P'
-- T03 Y con SN sin regularizar (repetir AF..DP)    -> BLOQUEADA RY-03 + mensaje del concepto
-- T04 Cheque a fecha gestion <> tesoreria          -> BLOQUEADA RY-01 (con CA_VAL_CHEQ = S)
-- T05 Y en estado 1, 2 o 3                         -> YA_CERRADA RY-02, cola 'C'
-- T06 Y sin libro de ventas                        -> SIN_LIBVTA
-- T07 Terminal con 3 Y, una con diferencia         -> 2 CERRADA_Y; Z BLOQUEADA RZ-07
-- T08 Todas las Y cerradas, Z <> suma Y            -> Z BLOQUEADA RZ-06 con glosa
-- T09 Todas las Y en 0 pero DR de Z distinta de 0  -> Z CON_DIFERENCIA RZ-05
-- T10 CA_VAL_ZZZ = S y formula ZZZ descuadrada     -> BLOQUEADA RY-06 / RZ-08
-- T11 CA_VAL_USD = S y USD <> Prosegur DOL         -> Z BLOQUEADA RZ-09
-- T12 Caja abierta en la F8 por un analista (bloqueo) mientras corre -> OCUPADA
-- T13 Ejecutar dos veces seguidas                  -> sin cambios en lo cerrado, sin errores
-- T14 CA_ACTIVO = N                                -> log INACTIVO, sin cambios
-- T15 Sobre sin cierre Y (prv_cierrey 0)           -> cola 'O' SIN_CIERREY
-- T16 Terminal Autopago (ter_tipo 2)               -> mismo resultado que el cierre AUTOMATICO actual
-- T17 Comparar 10 cajas: misma regla que mostraria Form3Y/Form3 al cerrar manualmente

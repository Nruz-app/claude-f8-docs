-- =====================================================================
-- FSCC-12901 T1 + T2 (carpeta consolidada) - Paso 10
-- Pruebas en TEST (ejecutar bloque a bloque).
-- Reemplazar &fecha (dd-mm-yyyy), &local, &terminal, &cierrey.
-- Fuentes: FSCC-12958/08_pruebas.sql + FSCC-12957/06_pruebas.sql
-- =====================================================================
set serveroutput on size 100000
set linesize 220 pagesize 200

-- 1. Compilacion (esperado: todo VALID y sin errores)
select object_name, object_type, status from all_objects
 where owner = sys_context('USERENV','CURRENT_SCHEMA')
   and object_name in ('PKG_F8_FACO_CIERRE_AUTO', 'PKG_F8_FACO_COMPENSA_DI',
                       'TRG_VTA_FACOPRD_CIERRE_AI', 'VTA_FACOPRD_CIERRE', 'VTA_FACOLOG_CIERRE_AUTO')
 order by 1, 2;
select name, type, line, position, text from all_errors
 where owner = sys_context('USERENV','CURRENT_SCHEMA')
   and name in ('PKG_F8_FACO_CIERRE_AUTO', 'PKG_F8_FACO_COMPENSA_DI', 'TRG_VTA_FACOPRD_CIERRE_AI')
 order by name, sequence;

-- 2. Diferencia real del paquete vs "Diferencia Real" de la F8 (Form3Y / Form3).
--    Deben coincidir en al menos 10 cajas antes de activar el proceso.
select y.ter_fecha, y.ter_local, y.ter_terminal, y.ter_cierrey, y.ter_estado,
       PKG_F8_FACO_CIERRE_AUTO.fn_dif_real(y.ter_fecha, y.ter_local, y.ter_terminal, y.ter_cierrey) dr_y,
       PKG_F8_FACO_CIERRE_AUTO.fn_dif_real(y.ter_fecha, y.ter_local, y.ter_terminal, null)          dr_z
  from VTA_FACOTERMSTATY y
 where y.ter_fecha >= trunc(sysdate) - 60 and rownum <= 20
 order by 1, 2, 3, 4;

-- 3. Una caja: que haria T1 (sin grabar) y validaciones de T2
declare
  v_dr number; r varchar2(10); m varchar2(1000);
begin
  dbms_output.put_line('T1 -> ' || PKG_F8_FACO_COMPENSA_DI.fn_evalua_caja(
      to_date('&fecha','dd-mm-yyyy'), &local, &terminal, &cierrey, v_dr) || ' DR=' || v_dr);
  dbms_output.put_line('DI existentes: ' || PKG_F8_FACO_COMPENSA_DI.fn_estado_di(
      to_date('&fecha','dd-mm-yyyy'), &local, &terminal, &cierrey));
  PKG_F8_FACO_CIERRE_AUTO.pr_valida_y(to_date('&fecha','dd-mm-yyyy'), &local, &terminal, &cierrey, r, m);
  dbms_output.put_line('T2 Y -> ' || nvl(r, 'OK') || ' ' || m);
  PKG_F8_FACO_CIERRE_AUTO.pr_valida_z(to_date('&fecha','dd-mm-yyyy'), &local, &terminal, r, m);
  dbms_output.put_line('T2 Z -> ' || nvl(r, 'OK') || ' ' || m);
end;
/

-- 4. Validaciones sueltas de T2
select PKG_F8_FACO_CIERRE_AUTO.fn_msg_cheque_fecha(to_date('&fecha','dd-mm-yyyy'), &local, &terminal) ry01_rz01_cheque,
       PKG_F8_FACO_CIERRE_AUTO.fn_zzz(to_date('&fecha','dd-mm-yyyy'), &local, &terminal, &cierrey)     ry06_zzz_y,
       PKG_F8_FACO_CIERRE_AUTO.fn_msg_z_suma_y(to_date('&fecha','dd-mm-yyyy'), &local, &terminal)     rz06_z_suma_y,
       PKG_F8_FACO_CIERRE_AUTO.fn_msg_y_abiertas(to_date('&fecha','dd-mm-yyyy'), &local, &terminal)   rz07_y_abiertas,
       PKG_F8_FACO_CIERRE_AUTO.fn_dif_dolares(to_date('&fecha','dd-mm-yyyy'), &local, &terminal)      rz09_dolares
  from dual;

-- 5. Trigger: cargar sobres con Form133 y verificar la cola
select * from VTA_FACOPRD_CIERRE order by pcr_id desc;
-- Conciliacion: sobres F8/DOL de los ultimos dias sin fila en la cola
select p.prv_techkey, p.prv_fechavta, p.prv_local, p.prv_terminal, p.prv_cierrey
  from VTA_FACOPRD p
 where p.prv_tiporec in ('F8', 'DOL') and p.prv_fechadep >= trunc(sysdate) - 1
   and not exists (select 1 from VTA_FACOPRD_CIERRE q where q.prv_techkey = p.prv_techkey);

-- 6. Simulacion de T1 sobre toda la cola (no graba)
declare
  v_dr number; v_res varchar2(30);
begin
  for c in (select distinct prv_fechavta f, prv_local l, prv_terminal t, prv_cierrey y
              from VTA_FACOPRD_CIERRE where pcr_estado = 'P' and prv_cierrey <> 0 order by 1, 2, 3, 4) loop
    v_res := PKG_F8_FACO_COMPENSA_DI.fn_evalua_caja(c.f, c.l, c.t, c.y, v_dr);
    dbms_output.put_line(to_char(c.f,'dd-mm-yyyy') || ' ' || c.l || '/' || c.t || ' Y' || c.y ||
                         ' DR=' || nvl(to_char(v_dr), 'null') || ' -> ' || v_res);
  end loop;
end;
/

-- 7. Ejecucion completa (como el job): T1 y luego T2
begin
  PKG_F8_FACO_CIERRE_AUTO.prc_cierre_automatico;
end;
/

-- 8. Resumen de la ultima ejecucion
select l.log_proceso, l.log_nivel, l.log_fecha_vta, l.log_local, l.log_terminal, l.log_cierrey,
       l.log_dif_real, l.log_resultado, l.log_regla, l.log_mensaje
  from VTA_FACOLOG_CIERRE_AUTO l
 where l.log_ejecucion = (select max(log_ejecucion) from VTA_FACOLOG_CIERRE_AUTO)
 order by l.log_id;

select log_proceso, log_resultado, log_regla, count(*)
  from VTA_FACOLOG_CIERRE_AUTO
 where log_ejecucion = (select max(log_ejecucion) from VTA_FACOLOG_CIERRE_AUTO)
 group by log_proceso, log_resultado, log_regla order by 1, 2, 3;

-- 9. Resultado en las tablas del sistema
select m.mov_fecha, m.mov_local, m.mov_terminal, m.mov_cierrey, m.mov_monto, m.mov_hechopor, m.mov_fechareg
  from VTA_FACOMOVDET m where m.mov_tipomov = 'DI' and m.mov_hechopor = 'PROC_DI_AUTO'
 order by 1 desc, 2, 3, 4;
select ter_fecha, ter_local, ter_terminal, ter_cierrey, ter_estado, ter_cerradopor, ter_notas
  from VTA_FACOTERMSTATY where ter_cerradopor = 'PROC_CIERRE_AUTO' order by 1, 2, 3, 4;
select ter_fecha, ter_local, ter_terminal, ter_estado, ter_cerradopor, ter_notas
  from VTA_FACOTERMSTAT  where ter_cerradopor = 'PROC_CIERRE_AUTO' order by 1, 2, 3;

-- 10. Matriz de casos del flujo completo (ver README.md, seccion 8)

-- =====================================================================
-- FSCC-12958 (HU-01-T2) Cierre de caja automatico - Falabella Colombia
-- 06 - Cuerpo de PKG_F8_FACO_CIERRE_AUTO   (Oracle 10.2)
--
-- Referencias al exe VB6 (FTEPROD/):
--   Form3Y.CierraTerminal :2801   Form3.CierraTerminal :3439
--   Form3Y.FormateaDatos  :2704   Form3.FormateaDatos  :3337
--   Form3Y.FuncvalidarConcepto :1700  Form3.FuncvalidarConcepto :1872
--   Modulo1.StrSumCompensado :2630    Modulo1.FuncValidarZSumaY :5531
--   Modulo1.FuncMontoValidaZZZ/ZZZYY :4105/:4160  StrCamposValidarZZZ :4053
--   Modulo1.Func_ValorGestionCheque :5681  Func_ValorChequeFecha :5632
--   Form3.FuncValidadCierreyyyy :2153  Form3.FuncvalidarDifDolares :1966
-- Detalle funcional: docs/CierreCaja_FACO_Reglas.md
-- =====================================================================

create or replace package body PKG_F8_FACO_CIERRE_AUTO as

  -- ---------------------------------------------------------------
  -- Estado de la ejecucion
  -- ---------------------------------------------------------------
  g_ejecucion  number;
  g_usuario    varchar2(50) := c_usuario_def;
  g_dec        number;          -- decimales de redondeo (CA_DECIMAL)

  e_ocupada    exception;
  pragma exception_init(e_ocupada, -54);   -- ORA-00054 resource busy (NOWAIT)

  type t_conceptos is table of varchar2(200) index by varchar2(2);
  type t_terminales is table of varchar2(1) index by varchar2(60);

  -- ---------------------------------------------------------------
  -- Utilitarios
  -- ---------------------------------------------------------------
  function fn_param (p_codigo  in varchar2,
                     p_default in varchar2) return varchar2 is
    v_valor varchar2(200);
  begin
    select trim(p.vta_xglosa)
      into v_valor
      from VTA_FACOPARAM p
     where p.vta_ccodtipo = c_tipo_param
       and trim(p.vta_ccodigo) = p_codigo
       and rownum = 1;
    return nvl(v_valor, p_default);
  exception
    when no_data_found then
      return p_default;
  end fn_param;

  function fn_dec return number is
  begin
    if g_dec is null then
      g_dec := to_number(fn_param('CA_DECIMAL', '0'));
    end if;
    return g_dec;
  end fn_dec;

  -- Log con transaccion autonoma: queda registrado aunque la caja haga rollback
  procedure pr_log (p_nivel     in varchar2,
                    p_fecha     in date,
                    p_local     in number,
                    p_terminal  in number,
                    p_cierrey   in number,
                    p_dif_real  in number,
                    p_resultado in varchar2,
                    p_regla     in varchar2,
                    p_mensaje   in varchar2) is
    pragma autonomous_transaction;
  begin
    insert into VTA_FACOLOG_CIERRE_AUTO
      (log_id, log_ejecucion, log_proceso, log_nivel, log_fecha_vta, log_local, log_terminal,
       log_cierrey, log_dif_real, log_resultado, log_regla, log_mensaje,
       log_usuario, log_fechahora)
    values
      (SEQ_VTA_FACOLOG_CIERRE_AUTO.nextval, nvl(g_ejecucion, 0), 'T2', p_nivel,
       p_fecha, p_local, p_terminal, p_cierrey, p_dif_real, p_resultado, p_regla,
       substr(p_mensaje, 1, 1000), g_usuario, sysdate);
    commit;
  end pr_log;

  -- Mensajes de conceptos pendientes (Form3Y.CierraTerminal, mismo orden)
  function fn_conceptos return t_conceptos is
    v t_conceptos;
  begin
    v('SN') := 'Falta regularizar el Sobres No Enviado declarada, o elimine el registro';
    v('AF') := 'Falta regularizar Atesoramiento Fondo Fijo, o elimine el registro';
    v('ND') := 'Falta regularizar N/D no digitada declarada, o elimine el registro';
    v('FN') := 'Falta regularizar Factura no digitada declarada, o elimine el registro';
    v('NP') := 'Falta regularizar el N/C Publicidad declarada, o elimine el registro';
    v('BF') := 'Falta regularizar el Billete Falso declarada, o elimine el registro';
    v('CR') := 'Falta regularizar el Certificado Regalo declarada, o elimine el registro';
    v('CT') := 'Falta regularizar el carta aviso Tienda declarada, o elimine el registro';
    v('CA') := 'Falta regularizar el carta aviso central declarada, o elimine el registro';
    v('DP') := 'Falta regularizar la Diferencia Prestadora declarada, o elimine el registro';
    return v;
  end fn_conceptos;

  -- ---------------------------------------------------------------
  -- Diferencia Real (Label70)  = sumaBZ - compensado
  -- sumaBZ FACO = (prsefe-totefe)+(prschd-totchd)+totDol+(teschf-totchf)+(tesTarjeta-totTarjeta)
  -- ---------------------------------------------------------------
  function fn_dif_real (p_fecha    in date,
                        p_local    in number,
                        p_terminal in number,
                        p_cierrey  in number default null) return number is
    v_tipo     varchar2(2) := case when p_cierrey is null then 'F8' else 'Y' end;
    v_cnt      number;
    v_totefe   number; v_totchd number; v_totchf number; v_tottarj number;
    v_prsefe   number; v_prschd number;
    v_teschf   number; v_testarj number; v_totdol number;
    v_comp     number;
  begin
    -- Declarado en la Y / Z (LeeZ + ARMA_QUERY_Z, rama FACO)
    select count(*),
           nvl(sum(r.rec_mefectivo), 0),
           nvl(sum(r.rec_mchkdia), 0),
           nvl(sum(r.rec_mchkfecha), 0),
           nvl(sum(r.rec_mtarj), 0) + nvl(sum(r.rec_msodimac), 0)
      into v_cnt, v_totefe, v_totchd, v_totchf, v_tottarj
      from VTA_FACOLIBVTA l, VTA_FACOZZZ r
     where l.vta_tiporeg     = v_tipo
       and l.vta_fecha_venta = p_fecha
       and l.vta_local       = p_local
       and l.vta_terminal    = p_terminal
       and l.vta_estado      = 'A'
       and l.vta_techkey     = r.rec_techkey
       and (p_cierrey is null or l.vta_secuencia = p_cierrey);

    if v_cnt = 0 then
      return null;   -- sin libro de ventas: el exe muestra "No hay Z disponible"
    end if;

    -- Sobres Prosegur (LeeProsegur): tiporec F8, EFE / CHE
    select nvl(sum(case when p.prv_tiposobre = 'EFE' then nvl(p.prv_montosobre,0) + nvl(p.prv_montodif,0) end), 0),
           nvl(sum(case when p.prv_tiposobre = 'CHE' then nvl(p.prv_montosobre,0) + nvl(p.prv_montodif,0) end), 0)
      into v_prsefe, v_prschd
      from VTA_FACOPRD p
     where p.prv_fechavta = p_fecha
       and p.prv_local    = p_local
       and p.prv_terminal = p_terminal
       and p.prv_tiporec  = 'F8'
       and (p_cierrey is null or p.prv_cierrey = p_cierrey);

    -- Cheque a fecha en tesoreria (LeeTes). Form3Y toma la primera fila de la Y;
    -- aqui se suma. Verificado en test (06-10-2026): una fila por Y.
    select nvl(sum(t.tes_chefecha), 0)
      into v_teschf
      from VTA_FACOTESOR t
     where t.tes_fecha    = p_fecha
       and t.tes_local    = p_local
       and t.tes_terminal = p_terminal
       and (p_cierrey is null or t.tes_cierrey = p_cierrey);

    -- Tarjetas recaudadas (FuncLeeTarjeta CTARJ, FACO: codigos 2000-2999)
    select nvl(sum(t.vta_monto_inf), 0)
      into v_testarj
      from VTA_FACOTARJ t
     where t.vta_fecha    = p_fecha
       and t.vta_local    = p_local
       and t.vta_terminal = p_terminal
       and t.vta_cod_tarj between 2000 and 2999
       and (p_cierrey is null or t.vta_cierrey = p_cierrey);

    -- Dolares recaudados (FunConsRecMon 305). FACO: totDol = tesDol
    select nvl(sum(x.mex_monto), 0)
      into v_totdol
      from VTA_FACORECMEX x
     where x.mex_fecha    = p_fecha
       and x.mex_local    = p_local
       and x.mex_terminal = p_terminal
       and x.id_mdareg    = 305
       and (p_cierrey is null or x.mex_cierrey = p_cierrey);

    -- Compensado (Modulo1.StrSumCompensado, Gopcion = "T", rama FACO).
    -- Se mantiene UNION (no UNION ALL) para replicar exactamente al exe.
    select nvl(sum(c.mov_monto), 0)
      into v_comp
      from (
        -- TC: registrados el dia - regularizados ese dia
        select ( nvl((select sum(m.mov_monto) from VTA_FACOMOVDET m
                       where m.mov_fecha = p_fecha and m.mov_local = p_local
                         and m.mov_terminal = p_terminal
                         and (p_cierrey is null or m.mov_cierrey = p_cierrey)
                         and m.mov_tipomov = 'TC'), 0)
               - nvl((select sum(m.mov_monto) from VTA_FACOMOVDET m
                       where m.mov_fechareg = p_fecha and m.mov_local = p_local
                         and m.mov_terminal = p_terminal
                         and (p_cierrey is null or m.mov_cierrey = p_cierrey)
                         and m.mov_regul = 'S' and m.mov_tipomov = 'TC'), 0) ) mov_monto,
               d.mov_tipomov
          from VTA_FACOCONCEPDIF d
         where d.mov_tipomov = 'TC'
        union
        -- SN, ND, FN: regularizados del dia - regularizados ese dia
        select ( nvl((select sum(m.mov_monto) from VTA_FACOMOVDET m
                       where m.mov_fecha = p_fecha and m.mov_local = p_local
                         and m.mov_terminal = p_terminal
                         and (p_cierrey is null or m.mov_cierrey = p_cierrey)
                         and m.mov_regul = 'S' and m.mov_tipomov = d.mov_tipomov), 0)
               - nvl((select sum(m.mov_monto) from VTA_FACOMOVDET m
                       where m.mov_fechareg = p_fecha and m.mov_local = p_local
                         and m.mov_terminal = p_terminal
                         and (p_cierrey is null or m.mov_cierrey = p_cierrey)
                         and m.mov_regul = 'S' and m.mov_tipomov = d.mov_tipomov), 0) ),
               d.mov_tipomov
          from VTA_FACOCONCEPDIF d
         where d.mov_tipomov in ('SN', 'ND', 'FN')
        union
        -- BF
        select nvl((select sum(m.mov_monto) from VTA_FACOMOVDET m
                     where m.mov_fecha = p_fecha and m.mov_local = p_local
                       and m.mov_terminal = p_terminal
                       and (p_cierrey is null or m.mov_cierrey = p_cierrey)
                       and m.mov_regul = 'S' and m.mov_tipomov = 'BF'), 0),
               d.mov_tipomov
          from VTA_FACOCONCEPDIF d
         where d.mov_tipomov = 'BF'
        union
        -- NP / FT (una fila por concepto de concepdif, cada una con la suma NP+FT)
        select nvl((select sum(m.mov_monto) from VTA_FACOMOVDET m
                     where m.mov_fecha = p_fecha and m.mov_local = p_local
                       and m.mov_terminal = p_terminal
                       and (p_cierrey is null or m.mov_cierrey = p_cierrey)
                       and m.mov_regul = 'S' and m.mov_tipomov in ('NP', 'FT')), 0),
               d.mov_tipomov
          from VTA_FACOCONCEPDIF d
         where d.mov_tipomov in ('NP', 'FT')
        union
        -- Conceptos regularizados (incluye CA y DI para FACO)
        select nvl(sum(m.mov_monto), 0), d.mov_tipomov
          from VTA_FACOMOVDET m, VTA_FACOCONCEPDIF d
         where m.mov_fecha = p_fecha and m.mov_local = p_local
           and m.mov_terminal = p_terminal
           and (p_cierrey is null or m.mov_cierrey = p_cierrey)
           and m.mov_regul = 'S'
           and m.mov_fechareg is not null
           and m.mov_tipomov = d.mov_tipomov
           and d.mov_tipomov in ('TU','DV','P1','P2','CM','CB','CC','SB','SC','SV','CP','CF','CT',
                                 'RE','CR','PC','DN','AF','DD','AA','DI','AV','RP','DP','CA','DE','PM')
         group by d.mov_tipomov
        union
        -- Carta aviso central (VTA_FACOCARTAAVISO)
        select nvl(sum(m.mov_monto), 0), d.mov_tipomov
          from VTA_FACOCARTAAVISO m, VTA_FACOCONCEPDIF d
         where m.mov_fecha = p_fecha and m.mov_local = p_local
           and m.mov_terminal = p_terminal
           and (p_cierrey is null or m.mov_cierrey = p_cierrey)
           and m.mov_regul = 'S'
           and m.mov_fechareg is not null
           and m.mov_tipomov = d.mov_tipomov
           and d.mov_tipomov = 'CA'
         group by d.mov_tipomov
        union
        -- Vendedor / cajero (FACO: sin filtro VEN_REGUL)
        select (select nvl(sum(v.ven_monto), 0) from VTA_FACODIFVEND v
                 where v.ven_fecha = p_fecha and v.ven_local = p_local
                   and v.ven_terminal = p_terminal
                   and (p_cierrey is null or v.ven_cierrey = p_cierrey)),
               d.mov_tipomov
          from VTA_FACOCONCEPDIF d
         where d.vta_coddif = 1
        union
        -- DT / NC con mov_numero <> terminal
        select nvl(sum(m.mov_monto), 0), d.mov_tipomov
          from VTA_FACOMOVDET m, VTA_FACOCONCEPDIF d
         where m.mov_fecha = p_fecha and m.mov_numero <> m.mov_terminal
           and m.mov_local = p_local and m.mov_terminal = p_terminal
           and (p_cierrey is null or m.mov_cierrey = p_cierrey)
           and m.mov_tipomov = d.mov_tipomov
           and d.mov_tipomov in ('DT', 'NC')
         group by d.mov_tipomov
        union
        -- DT / NC con mov_numero = terminal
        select nvl(sum(m.mov_monto), 0), d.mov_tipomov
          from VTA_FACOMOVDET m, VTA_FACOCONCEPDIF d
         where m.mov_fecha = p_fecha and m.mov_numero = m.mov_terminal
           and m.mov_local = p_local and m.mov_terminal = p_terminal
           and (p_cierrey is null or m.mov_cierrey = p_cierrey)
           and m.mov_tipomov = d.mov_tipomov
           and d.mov_tipomov in ('DT', 'NC')
         group by d.mov_tipomov
        union
        -- AL (cruce con libro de ventas: 'Y' en cierre Y, 'F8' en Z)
        select nvl(sum(m.mov_monto), 0), d.mov_tipomov
          from VTA_FACOMOVDET m, VTA_FACOCONCEPDIF d,
               VTA_FACOLIBVTA l, VTA_FACOZZZ z
         where m.mov_fecha = p_fecha and m.mov_numero = m.mov_terminal
           and m.mov_fecha = l.vta_fecha_venta
           and m.mov_local = l.vta_local
           and m.mov_terminal = l.vta_terminal
           and l.vta_techkey = z.rec_techkey and l.vta_estado = 'A'
           and m.mov_local = p_local and m.mov_terminal = p_terminal
           and (p_cierrey is null or m.mov_cierrey = p_cierrey)
           and l.vta_tiporeg = v_tipo
           and m.mov_secuencia = l.vta_secuencia
           and m.mov_tipomov = d.mov_tipomov
           and d.mov_tipomov = 'AL'
         group by d.mov_tipomov
        union
        -- TB
        select nvl(sum(m.mov_monto), 0), d.mov_tipomov
          from VTA_FACOMOVDET m, VTA_FACOCONCEPDIF d
         where m.mov_fecha = p_fecha and m.mov_numero = m.mov_terminal
           and m.mov_local = p_local and m.mov_terminal = p_terminal
           and (p_cierrey is null or m.mov_cierrey = p_cierrey)
           and m.mov_tipomov = d.mov_tipomov
           and d.mov_tipomov = 'TB'
         group by d.mov_tipomov
      ) c;

    -- El exe redondea el compensado ANTES de restarlo:
    --   VG_ValorCompensado = Format(ValorCompensacion, gFormat)
    --   Label70 = Format(sumaBZ - VG_ValorCompensado, gFormat)
    -- gFormat de FACO = vta_parametros.vta_numformat '#,#0' (0 decimales).
    v_comp := round(v_comp, fn_dec);

    return round( (v_prsefe - v_totefe) + (v_prschd - v_totchd) + v_totdol
                + (v_teschf - v_totchf) + (v_testarj - v_tottarj) - v_comp, fn_dec );
  end fn_dif_real;

  -- ---------------------------------------------------------------
  -- RY-01 / RZ-01 Cheque a fecha: gestion de cheques (tipo 1) = tesoreria
  -- (dia completo, sin filtro de Y, igual que el exe)
  -- ---------------------------------------------------------------
  function fn_msg_cheque_fecha (p_fecha in date, p_local in number, p_terminal in number) return varchar2 is
    v_gestion number;
    v_tesor   number;
  begin
    select nvl(sum(c.chq_monto), 0)
      into v_gestion
      from VTA_FACOCHEQUES c
     where c.chq_fecha = p_fecha and c.chq_local = p_local
       and c.chq_terminal = p_terminal and c.chq_tipocheque = 1;

    select nvl(sum(t.tes_chefecha), 0)
      into v_tesor
      from VTA_FACOTESOR t
     where t.tes_fecha = p_fecha and t.tes_local = p_local and t.tes_terminal = p_terminal;

    if round(v_gestion, fn_dec) <> round(v_tesor, fn_dec) then
      return 'Existe diferencia para el concepto cheques a Fecha entre la Gestion de Cheque : ( '
             || v_gestion || ' ) versus columna tesoreria : ( ' || v_tesor || ' ) , para poder cerrar Y.';
    end if;
    return null;
  end fn_msg_cheque_fecha;

  -- ---------------------------------------------------------------
  -- RY-03 / RZ-03 Concepto declarado sin regularizar (FuncvalidarConcepto)
  -- ---------------------------------------------------------------
  function fn_concepto_pendiente (p_fecha in date, p_local in number, p_terminal in number,
                                  p_cierrey in number, p_tipo in varchar2) return boolean is
    v_cnt number;
  begin
    if p_tipo = 'CA' then
      select count(*) into v_cnt
        from VTA_FACOCARTAAVISO m
       where m.mov_fecha = p_fecha and m.mov_local = p_local and m.mov_terminal = p_terminal
         and (m.mov_regul is null or m.mov_regul in (' ', 'N'))
         and m.mov_tipomov = p_tipo
         and (p_cierrey is null or m.mov_cierrey = p_cierrey);
    else
      select count(*) into v_cnt
        from VTA_FACOMOVDET m
       where m.mov_fecha = p_fecha and m.mov_local = p_local and m.mov_terminal = p_terminal
         and (m.mov_regul is null or m.mov_regul in (' ', 'N'))
         and m.mov_tipomov = p_tipo
         and (p_cierrey is null or m.mov_cierrey = p_cierrey);
    end if;
    return v_cnt > 0;
  end fn_concepto_pendiente;

  -- ---------------------------------------------------------------
  -- RY-06 / RZ-08 Formula ZZZ (FuncValidaZZZ + FuncMontoValidaZZZ[YY])
  -- Verificado en test (06-10-2026): VTA_PAINT_Z.vta_signo es CHAR(1) y vale
  -- '+' en todas las filas FACO; los campos de vta_cmp_asoc existen en una
  -- sola de VTA_FACOLIBVTA / VTA_FACOZZZ, por lo que van sin prefijo.
  -- Grupos FACO: 1 ventas (boletas, NC, facturas), 2 abono/avance CMR,
  -- reversa recaudacion, pago facturas, 3 recaudacion, 6 gift card,
  -- 7 formas de pago.
  -- Diferencia = F7 - F6 - F5 - F4 - F3 - F2 - F1, con F(k) armada desde
  -- VTA_PAINT_Z.vta_validadorzzz = k. Corrige el bug del exe (Form3Y pasaba
  -- el local en vez del numero de Y): aqui se usa la Y real.
  -- ---------------------------------------------------------------
  function fn_zzz (p_fecha in date, p_local in number, p_terminal in number,
                   p_cierrey in number) return number is
    type t_num is table of number index by pls_integer;
    v_f    t_num;
    v_expr varchar2(4000);
    v_sql  varchar2(4000);
  begin
    for k in 1 .. 7 loop
      v_expr := null;
      for r in (select z.vta_cmp_asoc, z.vta_signo
                  from VTA_PAINT_Z z
                 where z.vta_localiz = 'FACO'
                   and z.vta_validadorzzz = k
                   and z.vta_cmp_asoc is not null
                 order by z.vta_order_z) loop
        v_expr := v_expr || case when v_expr is not null then ' + ' end
               || 'nvl(sum(' || r.vta_cmp_asoc || '),0) * ' || nvl(trim(r.vta_signo), '+') || '1';
      end loop;

      if v_expr is null then
        v_f(k) := 0;
      else
        v_sql := 'select ' || v_expr ||
                 ' from VTA_FACOLIBVTA l, VTA_FACOZZZ r' ||
                 ' where l.vta_fecha_venta = :f and l.vta_local = :lo and l.vta_terminal = :te' ||
                 ' and l.vta_estado = ''A'' and l.vta_techkey = r.rec_techkey';
        if p_cierrey is null then
          v_sql := v_sql || ' and l.vta_tiporeg = ''F8''';
          execute immediate v_sql into v_f(k) using p_fecha, p_local, p_terminal;
        else
          v_sql := v_sql || ' and l.vta_tiporeg = ''Y'' and l.vta_secuencia = :y';
          execute immediate v_sql into v_f(k) using p_fecha, p_local, p_terminal, p_cierrey;
        end if;
        v_f(k) := nvl(v_f(k), 0);
      end if;
    end loop;
    return round(v_f(7) - v_f(6) - v_f(5) - v_f(4) - v_f(3) - v_f(2) - v_f(1), fn_dec);
  end fn_zzz;

  -- ---------------------------------------------------------------
  -- RZ-06 Z = suma de las Y por cada campo de VTA_PAINT_Z (FuncValidarZSumaY)
  -- ---------------------------------------------------------------
  function fn_msg_z_suma_y (p_fecha in date, p_local in number, p_terminal in number) return varchar2 is
    v_z number;
    v_y number;
  begin
    for r in (select z.vtaglosa_z, z.vta_cmp_asoc, z.vta_order_z
                from VTA_PAINT_Z z
               where z.vta_localiz = 'FACO'
                 and nvl(z.vta_pop_up, 0) = 0
                 and z.vta_cmp_asoc is not null
               order by z.vta_order_z) loop
      if r.vta_order_z < 56 or r.vta_order_z > 76 then
        execute immediate
          'select nvl(sum(' || r.vta_cmp_asoc || '),0)' ||
          ' from VTA_FACOLIBVTA l, VTA_FACOZZZ r, VTA_FACOTERMSTAT t' ||
          ' where l.vta_tiporeg = ''F8'' and l.vta_fecha_venta = :f and l.vta_local = :lo' ||
          ' and l.vta_terminal = :te and l.vta_estado = ''A'' and l.vta_techkey = r.rec_techkey' ||
          ' and l.vta_fecha_venta = t.ter_fecha and l.vta_local = t.ter_local and l.vta_terminal = t.ter_terminal'
          into v_z using p_fecha, p_local, p_terminal;

        execute immediate
          'select nvl(sum(' || r.vta_cmp_asoc || '),0)' ||
          ' from VTA_FACOLIBVTA l, VTA_FACOZZZ r, VTA_FACOTERMSTATY t' ||
          ' where l.vta_tiporeg = ''Y'' and l.vta_fecha_venta = :f and l.vta_local = :lo' ||
          ' and l.vta_terminal = :te and l.vta_estado = ''A'' and l.vta_techkey = r.rec_techkey' ||
          ' and l.vta_fecha_venta = t.ter_fecha and l.vta_local = t.ter_local and l.vta_terminal = t.ter_terminal' ||
          ' and l.vta_secuencia = t.ter_cierrey'
          into v_y using p_fecha, p_local, p_terminal;

        if nvl(v_z, 0) - nvl(v_y, 0) <> 0 then
          return 'En el monto ' || trim(r.vtaglosa_z) || ' Existe diferencia entre el Z y la sumatoria de las Y';
        end if;
      end if;
    end loop;
    return null;
  end fn_msg_z_suma_y;

  -- ---------------------------------------------------------------
  -- RZ-07 Todas las Y del terminal-dia cerradas (FuncValidadCierreyyyy)
  -- Diferencia con el exe: si no hay Y en libro de ventas el exe deja
  -- pasar; el proceso automatico NO cierra (queda para el analista).
  -- ---------------------------------------------------------------
  function fn_msg_y_abiertas (p_fecha in date, p_local in number, p_terminal in number) return varchar2 is
    v_total   number;
    v_abiertas number;
  begin
    select count(*), sum(case when t.ter_estado = 1 then 0 else 1 end)
      into v_total, v_abiertas
      from VTA_FACOLIBVTA l, VTA_FACOZZZ r, VTA_FACOTERMSTATY t
     where l.vta_tiporeg = 'Y' and l.vta_fecha_venta = p_fecha
       and l.vta_local = p_local and l.vta_terminal = p_terminal
       and l.vta_estado = 'A' and l.vta_techkey = r.rec_techkey
       and l.vta_fecha_venta = t.ter_fecha and l.vta_local = t.ter_local
       and l.vta_terminal = t.ter_terminal and l.vta_secuencia = t.ter_cierrey;

    if v_total = 0 then
      return 'Existen problema para traer informacion de los estados de los cierre Y del terminal';
    elsif nvl(v_abiertas, 0) > 0 then
      return 'Hay Cierres de Y abiertos';
    end if;
    return null;
  end fn_msg_y_abiertas;

  -- ---------------------------------------------------------------
  -- RZ-09 Dolares declarados vs Prosegur (FuncvalidarDifDolares)
  -- Se mantiene UNION como en el exe.
  -- ---------------------------------------------------------------
  function fn_dif_dolares (p_fecha in date, p_local in number, p_terminal in number) return number is
    v_monto number;
  begin
    select nvl(sum(a.monto), 0)
      into v_monto
      from (select sum(nvl(r.mex_cantidad, 0) * -1) monto, count(*) * -1 numero, 'RECMEX' origen
              from VTA_FACORECMEX r
             where r.mex_fecha = p_fecha and r.mex_local = p_local
               and r.id_mdareg = 305 and r.mex_terminal = p_terminal
            union
            select sum(p.prv_montosobre) + sum(p.prv_montodif), count(*), 'PRD'
              from VTA_FACOPRD p
             where p.prv_fechavta = p_fecha and p.prv_tiporec = 'DOL'
               and p.prv_local = p_local and p.prv_terminal = p_terminal) a;
    return v_monto;
  end fn_dif_dolares;

  -- ---------------------------------------------------------------
  -- Validaciones Y (orden de Form3Y.CierraTerminal; estado y DR se
  -- evaluan antes en el proceso, segun el diagrama del Proceso 2)
  -- ---------------------------------------------------------------
  procedure pr_valida_y (p_fecha    in  date,
                         p_local    in  number,
                         p_terminal in  number,
                         p_cierrey  in  number,
                         o_regla    out varchar2,
                         o_mensaje  out varchar2) is
    v_c   t_conceptos := fn_conceptos;
    v_k   varchar2(2);
    v_zzz number;
  begin
    o_regla := null; o_mensaje := null;

    -- RY-01 cheque a fecha
    if fn_param('CA_VAL_CHEQ', 'S') = 'S' then
      o_mensaje := fn_msg_cheque_fecha(p_fecha, p_local, p_terminal);
      if o_mensaje is not null then o_regla := 'RY-01'; return; end if;
    end if;

    -- RY-03 conceptos sin regularizar en la Y (orden del exe)
    for i in 1 .. 10 loop
      v_k := case i when 1 then 'SN' when 2 then 'AF' when 3 then 'ND' when 4 then 'FN'
                    when 5 then 'NP' when 6 then 'BF' when 7 then 'CR' when 8 then 'CT'
                    when 9 then 'CA' else 'DP' end;
      if fn_concepto_pendiente(p_fecha, p_local, p_terminal, p_cierrey, v_k) then
        o_regla := 'RY-03'; o_mensaje := v_c(v_k); return;
      end if;
    end loop;

    -- RY-06 formula ZZZ (opcion 103 del exe, aqui flag)
    if fn_param('CA_VAL_ZZZ', 'N') = 'S' then
      v_zzz := fn_zzz(p_fecha, p_local, p_terminal, p_cierrey);
      if v_zzz <> 0 then
        o_regla := 'RY-06';
        o_mensaje := 'Error, Y descuadrada, favor revisar... diferencia : ' || v_zzz;
        return;
      end if;
    end if;
  end pr_valida_y;

  -- ---------------------------------------------------------------
  -- Validaciones Z (orden de Form3.CierraTerminal)
  -- ---------------------------------------------------------------
  procedure pr_valida_z (p_fecha    in  date,
                         p_local    in  number,
                         p_terminal in  number,
                         o_regla    out varchar2,
                         o_mensaje  out varchar2) is
    v_c   t_conceptos := fn_conceptos;
    v_k   varchar2(2);
    v_num number;
  begin
    o_regla := null; o_mensaje := null;

    -- RZ-07 todas las Y cerradas (precondicion del flujo)
    o_mensaje := fn_msg_y_abiertas(p_fecha, p_local, p_terminal);
    if o_mensaje is not null then o_regla := 'RZ-07'; return; end if;

    -- RZ-01 cheque a fecha
    if fn_param('CA_VAL_CHEQ', 'S') = 'S' then
      o_mensaje := fn_msg_cheque_fecha(p_fecha, p_local, p_terminal);
      if o_mensaje is not null then o_regla := 'RZ-01'; return; end if;
    end if;

    -- RZ-03 conceptos sin regularizar del dia (sin filtro de Y)
    for i in 1 .. 10 loop
      v_k := case i when 1 then 'SN' when 2 then 'AF' when 3 then 'ND' when 4 then 'FN'
                    when 5 then 'NP' when 6 then 'BF' when 7 then 'CR' when 8 then 'CT'
                    when 9 then 'CA' else 'DP' end;
      if fn_concepto_pendiente(p_fecha, p_local, p_terminal, null, v_k) then
        o_regla := 'RZ-03'; o_mensaje := v_c(v_k); return;
      end if;
    end loop;

    -- RZ-06 Z = suma de las Y
    o_mensaje := fn_msg_z_suma_y(p_fecha, p_local, p_terminal);
    if o_mensaje is not null then o_regla := 'RZ-06'; return; end if;

    -- RZ-08 formula ZZZ de la Z (flag)
    if fn_param('CA_VAL_ZZZ', 'N') = 'S' then
      v_num := fn_zzz(p_fecha, p_local, p_terminal, null);
      if v_num <> 0 then
        o_regla := 'RZ-08';
        o_mensaje := 'Error, Z descuadrada, favor revisar... diferencia : ' || v_num;
        return;
      end if;
    end if;

    -- RZ-09 dolares vs Prosegur (flag)
    if fn_param('CA_VAL_USD', 'N') = 'S' then
      v_num := fn_dif_dolares(p_fecha, p_local, p_terminal);
      if v_num <> 0 then
        o_regla := 'RZ-09';
        o_mensaje := 'Error, existen diferencias entre los dolares declarados y los dolares informado por Prosegur , favor revisar... diferencia ' || v_num;
        return;
      end if;
    end if;
  end pr_valida_z;

  -- ---------------------------------------------------------------
  -- Marca las filas pendientes de la cola para una caja
  -- ---------------------------------------------------------------
  procedure pr_marca_cola (p_fecha in date, p_local in number, p_terminal in number,
                           p_cierrey in number, p_estado in varchar2,
                           p_resultado in varchar2, p_mensaje in varchar2) is
  begin
    update VTA_FACOPRD_CIERRE q
       set q.pcr_estado    = p_estado,
           q.pcr_resultado = p_resultado,
           q.pcr_mensaje   = substr(p_mensaje, 1, 1000),
           q.pcr_fechaproc = sysdate,
           q.pcr_ejecucion = g_ejecucion,
           q.pcr_intentos  = q.pcr_intentos + 1
     where q.pcr_estado   = 'P'
       and q.prv_fechavta = p_fecha
       and q.prv_local    = p_local
       and q.prv_terminal = p_terminal
       and q.prv_cierrey  = p_cierrey;
  end pr_marca_cola;

  function fn_nota (p_nota_actual in varchar2) return varchar2 is
  begin
    return substr('CIERRE AUTOMATICO FSCC-12958 ' || to_char(sysdate, 'dd-mm-yyyy hh24:mi')
                  || case when p_nota_actual is not null then ' | ' || p_nota_actual end, 1, 2500);
  end fn_nota;

  -- ---------------------------------------------------------------
  -- Proceso de una Y (Proceso 2 del diagrama)
  -- ---------------------------------------------------------------
  procedure pr_procesa_y (p_fecha in date, p_local in number, p_terminal in number, p_cierrey in number) is
    v_estado  number;
    v_notas   varchar2(2500);
    v_dr      number;
    v_regla   varchar2(10);
    v_msg     varchar2(1000);
  begin
    savepoint sp_y;

    begin
      select t.ter_estado, t.ter_notas
        into v_estado, v_notas
        from VTA_FACOTERMSTATY t
       where t.ter_fecha = p_fecha and t.ter_local = p_local
         and t.ter_terminal = p_terminal and t.ter_cierrey = p_cierrey
         for update nowait;
    exception
      when no_data_found then
        pr_marca_cola(p_fecha, p_local, p_terminal, p_cierrey, 'P', 'SIN_TERMSTAT', 'No existe el cierre Y en VTA_FACOTERMSTATY');
        commit;
        pr_log('Y', p_fecha, p_local, p_terminal, p_cierrey, null, 'SIN_TERMSTAT', 'RY-02', 'No existe el cierre Y en VTA_FACOTERMSTATY');
        return;
      when e_ocupada then
        pr_marca_cola(p_fecha, p_local, p_terminal, p_cierrey, 'P', 'OCUPADA', 'Caja bloqueada por otro usuario');
        commit;
        pr_log('Y', p_fecha, p_local, p_terminal, p_cierrey, null, 'OCUPADA', null, 'Caja bloqueada por otro usuario');
        return;
    end;

    -- RY-02 estado: 1 cerrado, 2 impreso, 3 sin datos -> no se reabre
    if v_estado > 0 then
      rollback to sp_y;
      pr_marca_cola(p_fecha, p_local, p_terminal, p_cierrey, 'C', 'YA_CERRADA', 'Terminal ya se Encuentra Cerrado');
      commit;
      pr_log('Y', p_fecha, p_local, p_terminal, p_cierrey, null, 'YA_CERRADA', 'RY-02', 'Terminal ya se Encuentra Cerrado (estado ' || v_estado || ')');
      return;
    end if;

    -- Recalcular la Diferencia Real (diagrama) / RY-05
    v_dr := fn_dif_real(p_fecha, p_local, p_terminal, p_cierrey);
    if v_dr is null then
      rollback to sp_y;
      pr_marca_cola(p_fecha, p_local, p_terminal, p_cierrey, 'P', 'SIN_LIBVTA', 'No hay Z disponible (sin libro de ventas de la Y)');
      commit;
      pr_log('Y', p_fecha, p_local, p_terminal, p_cierrey, null, 'SIN_LIBVTA', null, 'No hay Z disponible (sin libro de ventas de la Y)');
      return;
    elsif v_dr <> 0 then
      rollback to sp_y;
      pr_marca_cola(p_fecha, p_local, p_terminal, p_cierrey, 'P', 'CON_DIFERENCIA', 'Falta Monto por Compensar');
      commit;
      pr_log('Y', p_fecha, p_local, p_terminal, p_cierrey, v_dr, 'CON_DIFERENCIA', 'RY-05', 'Falta Monto por Compensar');
      return;
    end if;

    -- Validaciones de Cerrar Terminal
    pr_valida_y(p_fecha, p_local, p_terminal, p_cierrey, v_regla, v_msg);
    if v_regla is not null then
      rollback to sp_y;
      pr_marca_cola(p_fecha, p_local, p_terminal, p_cierrey, 'P', 'BLOQUEADA', v_regla || ' ' || v_msg);
      commit;
      pr_log('Y', p_fecha, p_local, p_terminal, p_cierrey, v_dr, 'BLOQUEADA', v_regla, v_msg);
      return;
    end if;

    -- Cerrar el cierre Y: estado cerrado, usuario de proceso, fecha y nota
    update VTA_FACOTERMSTATY t
       set t.ter_estado     = 1,
           t.ter_cerradopor = g_usuario,
           t.ter_notas      = fn_nota(v_notas)
     where t.ter_fecha = p_fecha and t.ter_local = p_local
       and t.ter_terminal = p_terminal and t.ter_cierrey = p_cierrey;

    pr_marca_cola(p_fecha, p_local, p_terminal, p_cierrey, 'C', 'CERRADA_Y', null);
    commit;
    pr_log('Y', p_fecha, p_local, p_terminal, p_cierrey, v_dr, 'CERRADA_Y', null, null);

  exception
    when others then
      v_msg := substr(sqlerrm, 1, 1000);
      begin
        rollback to sp_y;
      exception
        when others then rollback;   -- ORA-01086: el savepoint ya no existe tras un commit
      end;
      pr_marca_cola(p_fecha, p_local, p_terminal, p_cierrey, 'P', 'ERROR', v_msg);
      commit;
      pr_log('Y', p_fecha, p_local, p_terminal, p_cierrey, null, 'ERROR', null, v_msg);
  end pr_procesa_y;

  -- ---------------------------------------------------------------
  -- Proceso de la Z de un terminal-dia (solo si todas las Y estan cerradas)
  -- ---------------------------------------------------------------
  procedure pr_procesa_z (p_fecha in date, p_local in number, p_terminal in number) is
    cursor c_z is
      select t.ter_estado, t.ter_notas
        from VTA_FACOTERMSTAT t
       where t.ter_fecha = p_fecha and t.ter_local = p_local and t.ter_terminal = p_terminal
         for update nowait;
    v_estado number;
    v_notas  varchar2(2500);
    v_dr     number;
    v_regla  varchar2(10);
    v_msg    varchar2(1000);
  begin
    savepoint sp_z;

    begin
      open c_z;                       -- bloquea todas las filas de la Z (no hay PK unica)
      fetch c_z into v_estado, v_notas;
      if c_z%notfound then
        close c_z;
        rollback to sp_z;
        pr_log('Z', p_fecha, p_local, p_terminal, null, null, 'SIN_TERMSTAT', 'RZ-02', 'No existe la Z en VTA_FACOTERMSTAT');
        return;
      end if;
      close c_z;
    exception
      when e_ocupada then
        rollback to sp_z;
        pr_log('Z', p_fecha, p_local, p_terminal, null, null, 'OCUPADA', null, 'Z bloqueada por otro usuario');
        return;
    end;

    -- RZ-02 estado
    if v_estado > 0 then
      rollback to sp_z;
      pr_log('Z', p_fecha, p_local, p_terminal, null, null, 'YA_CERRADA', 'RZ-02', 'Terminal ya se Encuentra Cerrado (estado ' || v_estado || ')');
      return;
    end if;

    -- RZ-07 primero: si quedan Y abiertas la Z no se evalua (caso normal)
    v_msg := fn_msg_y_abiertas(p_fecha, p_local, p_terminal);
    if v_msg is not null then
      rollback to sp_z;
      pr_log('Z', p_fecha, p_local, p_terminal, null, null, 'BLOQUEADA', 'RZ-07', v_msg);
      return;
    end if;

    -- RZ-05 Diferencia Real de la Z
    v_dr := fn_dif_real(p_fecha, p_local, p_terminal, null);
    if v_dr is null then
      rollback to sp_z;
      pr_log('Z', p_fecha, p_local, p_terminal, null, null, 'SIN_LIBVTA', null, 'No hay Z disponible (sin libro de ventas F8)');
      return;
    elsif v_dr <> 0 then
      rollback to sp_z;
      pr_log('Z', p_fecha, p_local, p_terminal, null, v_dr, 'CON_DIFERENCIA', 'RZ-05', 'Falta Monto por Compensar');
      return;
    end if;

    -- Resto de validaciones de la Z
    pr_valida_z(p_fecha, p_local, p_terminal, v_regla, v_msg);
    if v_regla is not null then
      rollback to sp_z;
      pr_log('Z', p_fecha, p_local, p_terminal, null, v_dr, 'BLOQUEADA', v_regla, v_msg);
      return;
    end if;

    -- Cerrar el terminal-dia (Z)
    update VTA_FACOTERMSTAT t
       set t.ter_estado     = 1,
           t.ter_cerradopor = g_usuario,
           t.ter_notas      = fn_nota(v_notas)
     where t.ter_fecha = p_fecha and t.ter_local = p_local and t.ter_terminal = p_terminal;
    commit;
    pr_log('Z', p_fecha, p_local, p_terminal, null, v_dr, 'CERRADA_Z', null, null);

  exception
    when others then
      v_msg := substr(sqlerrm, 1, 1000);
      begin
        rollback to sp_z;
      exception
        when others then rollback;
      end;
      pr_log('Z', p_fecha, p_local, p_terminal, null, null, 'ERROR', null, v_msg);
  end pr_procesa_z;

  -- ---------------------------------------------------------------
  -- Punto de entrada
  -- ---------------------------------------------------------------
  procedure prc_cierre_automatico (p_usuario   in varchar2 default 'PROC_CIERRE_AUTO',
                                   p_max_cajas in number   default null) is
    v_dias  number;
    v_n     number := 0;
    v_terms t_terminales;
    v_key   varchar2(60);
    v_fecha date;
    v_local number;
    v_term  number;
  begin
    g_usuario := nvl(substr(p_usuario, 1, 50), c_usuario_def);
    g_dec     := to_number(fn_param('CA_DECIMAL', '0'));
    v_dias    := to_number(fn_param('CA_DIAS', '30'));
    select SEQ_VTA_FACOLOG_CIERRE_AUTO.nextval into g_ejecucion from dual;

    -- Interruptores independientes: CA_DI_ACTIVO (T1) y CA_ACTIVO (T2).
    -- Si ambos estan apagados no se hace nada.
    if fn_param('CA_ACTIVO', 'N') <> 'S' and fn_param('CA_DI_ACTIVO', 'N') <> 'S' then
      pr_log('-', null, null, null, null, null, 'INACTIVO', null, 'Parametros 1502 CA_ACTIVO y CA_DI_ACTIVO distintos de S');
      return;
    end if;
    pr_log('-', null, null, null, null, null, 'INICIO', null, 'Usuario ' || g_usuario);

    -- Sobres sin cierre Y: no se pueden asociar a una caja.
    -- PRV_CIERREY es NUMBER(2) NOT NULL DEFAULT 0 en VTA_FACOPRD: 0 = sin Y.
    update VTA_FACOPRD_CIERRE q
       set q.pcr_estado = 'O', q.pcr_resultado = 'SIN_CIERREY',
           q.pcr_mensaje = 'Sobre sin numero de cierre Y', q.pcr_fechaproc = sysdate,
           q.pcr_ejecucion = g_ejecucion
     where q.pcr_estado = 'P' and nvl(q.prv_cierrey, 0) = 0;

    -- Pendientes mas antiguas que CA_DIAS: se dejan de reevaluar
    update VTA_FACOPRD_CIERRE q
       set q.pcr_estado = 'V', q.pcr_resultado = 'VENCIDA', q.pcr_fechaproc = sysdate,
           q.pcr_ejecucion = g_ejecucion
     where q.pcr_estado = 'P' and q.prv_fechavta < trunc(sysdate) - v_dias;
    commit;

    -- T1 (FSCC-12957): compensacion automatica de DI sobre las mismas cajas
    -- pendientes de la cola, ANTES del cierre (diagrama general: T1 -> T2).
    -- T1 revisa su propio interruptor (CA_DI_ACTIVO) y registra en el mismo
    -- log con log_proceso = 'T1'. Un error en T1 no impide ejecutar T2.
    begin
      PKG_F8_FACO_COMPENSA_DI.prc_compensa_di(p_ejecucion => g_ejecucion,
                                              p_max_cajas => p_max_cajas);
    exception
      when others then
        pr_log('-', null, null, null, null, null, 'ERROR', null,
               'Fallo T1 (PKG_F8_FACO_COMPENSA_DI): ' || substr(sqlerrm, 1, 900));
    end;

    -- T2 apagado: solo corrio T1
    if fn_param('CA_ACTIVO', 'N') <> 'S' then
      pr_log('-', null, null, null, null, null, 'INACTIVO', null, 'Parametro 1502 CA_ACTIVO distinto de S: solo se ejecuto T1');
      return;
    end if;

    -- Cierres Y de la cola (incluye los que ya tenian DR 0 y las compensadas por T1)
    for c in (select q.prv_fechavta f, q.prv_local l, q.prv_terminal t, q.prv_cierrey y
                from VTA_FACOPRD_CIERRE q
               where q.pcr_estado = 'P'
               group by q.prv_fechavta, q.prv_local, q.prv_terminal, q.prv_cierrey
               order by 1, 2, 3, 4) loop
      exit when p_max_cajas is not null and v_n >= p_max_cajas;
      v_n := v_n + 1;
      pr_procesa_y(c.f, c.l, c.t, c.y);
      v_terms(to_char(c.f, 'yyyymmdd') || '|' || c.l || '|' || c.t) := 'S';
    end loop;

    -- Z de los terminal-dia tocados
    v_key := v_terms.first;
    while v_key is not null loop
      v_fecha := to_date(substr(v_key, 1, 8), 'yyyymmdd');
      v_local := to_number(substr(v_key, 10, instr(v_key, '|', 1, 2) - 10));
      v_term  := to_number(substr(v_key, instr(v_key, '|', 1, 2) + 1));
      pr_procesa_z(v_fecha, v_local, v_term);
      v_key := v_terms.next(v_key);
    end loop;

    pr_log('-', null, null, null, null, null, 'FIN', null, 'Cierres Y evaluados: ' || v_n);
  exception
    when others then
      rollback;
      pr_log('-', null, null, null, null, null, 'ERROR', null, sqlerrm);
      raise;
  end prc_cierre_automatico;

end PKG_F8_FACO_CIERRE_AUTO;
/

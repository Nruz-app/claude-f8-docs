# FCDVT-14: carga masiva de cierres F8 (Z / Y) desde Excel

Índice del requerimiento. Para retomar, empezar por aquí.

## 1. Requerimiento

- **Fuente**: [`Requerimiento-FCDVT-14/DF-SCC-vf_24.03.2025 Ingreso Cierre de caja F8.xlsx`](Requerimiento-FCDVT-14/) (DF-SCC del 24-03-2025).
- **Iniciativa**: "CARGA MASIVA CIERRES F8". Tipo Nuevo. Negocio Falabella Retail y Tottus. Países Chile y Colombia.
- **Personas**: solicitante Paulo Arrieta; gerente de área Cristian Zúñiga; gerencia Pablo Aguirre Rigo-Righi.
- **Sistemas impactados**: F8, LV y Tesorería = sí; CMP y SCC = no.
  - Las hojas SCC, Estructura venta/liquid, Archivo de salida, Backbone y Enriquecimiento son la plantilla genérica de conciliación y no aplican.
  - Única nota a respetar (comentario de J. Carrillo): **no se debe modificar la llave de pareo de conciliación**.
- **Qué se pide**: una pantalla en F8 que cargue cierres de caja desde un Excel, con totales por tipo de documento y por medio de pago. Reemplaza la digitación manual de la Z (`Form19`) y de la Y (`Form19Y`).
- **Criterios de aceptación**:
  1. Template Excel con la venta y las formas de pago → **INSERT** del cierre.
  2. Opción de **UPDATE** de montos de un cierre existente, sin cargarlo de cero.
  3. Validación igual que en F8: alerta de descuadratura (documentos ≠ medios de pago) y **no graba** lo descuadrado.
  4. Switch para cargar solo la Z o también la Y, según negocio y país.
  5. **Log de auditoría** al final de cada carga. Extra posible: un reporte de auditoría.
  6. Los cierres cargados deben comportarse igual que los que vienen de la caja y reflejarse en el **LVTA**.
- **Alcance por empresa**:

  | Empresa | `Flg_Pais$` | Z | Y | Columnas de concepto en el template |
  |---|---|---|---|---|
  | Falabella Chile | `""` / `CHI` | Sí | No | ~110 |
  | Tottus Chile | `SFCL` | Sí | Sí | ~80 |
  | Falabella Colombia | `FACO` | Sí | Sí | ~50 |

- **Template** (hoja F8-LV-CMP-TES, filas 30-60). Tiene un bloque de "ingreso" y otro de "update" por empresa.
  - Columnas fijas: Fecha (serial Excel; 46294 = 30-09-2026), Local, Terminal, N° de cierre de Y, Hora, Secuencia, N° Boleta, Vendedor, Cont. Reposición, Tipo (`Z`/`Y`) y Tipo_carga (`INGRESAR`/`Modificar`).
  - El resto de las columnas son los conceptos de la Z, con las glosas de `vta_paint_z.vtaglosa_z` del país.
  - El bloque update trae solo Fecha, Local, Terminal, Tipo, Tipo_carga y los montos.
  - **Inconsistencias del template** (confirmar con negocio):
    - En FACO, el bloque de ingreso no tiene la columna `Tipo_carga`.
    - En el update de FACO, las filas Y no traen fecha, local ni terminal.
    - En FACO, el N° de Y viene vacío aunque haya dos filas Y.
    - Hay glosas repetidas en distintas secciones (EFECTIVO, CMR, TRANSBANK, REC TELEF, ENTRADAS…), así que mapear por glosa es ambiguo.
    - Algunas celdas traen `-` en vez de 0.

## 2. Estado

**Análisis** (16-10-2026). No hay cambios en `FTEPROD/` ni en la base. Faltan las respuestas de negocio (§7) y correr los prechecks en test.

## 3. Artefactos

| Archivo | Qué es |
|---|---|
| `docs/Requerimiento-FCDVT-14/DF-SCC-vf_24.03.2025 Ingreso Cierre de caja F8.xlsx` | Especificación funcional (fuente) |
| `docs/README_FCDVT-14.md` | Este índice |
| `docs/FCDVT-14/plantilla_carga_Y_FACO.csv` | Plantilla CSV (`;`, 54 columnas, una fila por Y) para la carga masiva de **inserción** de Y de FACO, con 3 filas ilustrativas |
| `docs/FCDVT-14/FORMATO_CARGA_Y_FACO.md` | Especificación del CSV: reglas, columna por columna con su `vta_cmp_asoc` y tabla destino, validaciones, qué inserta y pendientes |
| `docs/sql/FCDVT-14/00_prechecks.sql` | Consultas de solo lectura: `vta_paint_z` por empresa, glosas duplicadas, columnas de libvta/zzz/termstat(y), secuencias, tablas de log, menú, volumen |

## 4. Cómo funciona hoy (verificado en el código)

### 4.1 Pantallas y menú

- **Z**: `Form19.frm`. Se abre con el botón `zz` (Button16) en `MDIForm1.frm:1640`. Perú usa `Form19_2` y Argentina `Form19_3`.
- **Y**: `Form19Y.frm`. Se abre con el botón `YYYY` (Button15) en `MDIForm1.frm:1633`. Solo existe para ARG, SFCL, FACO y HTPE.
- **Contexto**: local y terminal se toman de `FormVariable.Combo2/Combo3`; la fecha, de `FormVariable.DTPicker1`. No usan `Gfecha`/`Glocal`.
- **Menú propuesto**: un `ButtonMenu2` en Button16, al final de la colección, para no mover `ZLV`.
  - Necesita un `Case` en `Toolbar1_ButtonMenuClick` y una rama `ElseIf numero = <código>` en `SubBuscarOpcionMenu` **antes** del `Else` de `MDIForm1.frm:1459`.
  - Si el código cae en el `Else` genérico con `numero > 42`, se dispara un error que corta el bucle de permisos.
  - Hoy el dropdown de Button16 solo se activa en MAPE/MPAM/SPOR, así que hay que habilitarlo también en CHI, SFCL y FACO.

### 4.2 Conceptos de la Z / Y

```sql
select z.vtaglosa_z, z.vta_cmp_asoc, decode(z.vta_pop_up,null,0,z.vta_pop_up) pop_up
  from vta_paint_z z where z.vta_localiz = '<Flg_Pais$ | CHI>' order by z.vta_order_z
```

- `vta_cmp_asoc` es la columna destino. Si contiene `VTA_`, va a `vta_<pfx>libvta`; si no, va a `vta_<pfx>zzz`.
- `pop_up`: 0 = editable; 1 = título; 2 = separador; 3 = total calculado (se graba).
- **Los documentos de libvta se toman por posición fija de fila, y esa posición varía por país.**
  - Chile (Form19): fila 2 = boletas, 3 = NC, 4 = factura, 5 = ND, 6 = guías, 7 = total.
  - FACO: total en la fila 5.
  - SFCL (Form19Y): total en la fila 7.
  - Recaudación Chile: filas 58+96 y 59+97. Hay una inconsistencia con `KeyPress`, que usa las filas 62 y 75.
- Los totales calculados se recalculan en `Grid1_KeyPress` (Form19 :1998-2065; Form19Y :2552-2567).

### 4.3 Qué graba la Z (`Form19.GrabaZZZ`, :371)

No distingue alta de modificación: siempre borra y vuelve a insertar. Todo se confirma solo (no hay `BeginTrans`).

1. `LeeZactual`: conserva `bolinicial`, `nrollo` y `crepo_inicial` de la Z anterior.
2. Techkey: `VTA_TEC_SEC.nextval` en Chile; `SEQ_VTA_<pfx>TEC.nextval` en SFCL y FACO.
3. `delete vta_<pfx>libvta where fecha/local/terminal and vta_tiporeg in ('F8'[, 'Y' fuera de Chile])`. **En SFCL y FACO esto borra todas las Y del terminal-día.**
4. `insert vta_<pfx>libvta` con `tiporeg='F8'`, `vta_secuencia=99`, `estado='A'`, `tipof8='N'`, documentos, hora, secuencia SRX, boleta final, vendedor, contador de reposición y techkey. No graba el usuario.
5. `insert vta_<pfx>zzz (rec_techkey, rec_fechaproceso, <cmp_asoc pop_up 0/3 sin VTA_>)`. La zzz anterior queda huérfana.
6. Si no existe `termstat`: `insert ... ter_estado=-1, 'INGRESO MANUAL DE CIERRE', LOGINUSER`. En SFCL, FACO y HTPE además se borran todas las `termstaty` del terminal-día.
7. Validador ZZZ (`FuncMontoValidaZZZ`, `Módulo1.bas:4105`):
   - Chile: `update zzz set rec_mdiferenciaz=<dif>`.
   - SFCL: muestra "Z descuadrada" **después** de grabar.
8. Solo SFCL: `GrabaYprima` crea automáticamente la Y1 (libvta 'Y'/1 y termstaty).

### 4.4 Ingreso de Y: `Form19Y.frm` en detalle

Archivo real `FTEPROD/Form19Y.frm` (2.646 líneas, `VB_Name` Form19Y). Análisis del 16-10-2026, sin cambios.

**Apertura.** Botón `YYYY` (`MDIForm1.frm:1633`), solo en ARG, SFCL, FACO y HTPE; se abre modal. Al cerrar, si el terminal no está cerrado (`lblEstado.Tag <> 1`) y la ventana activa es Form3/Form3Y, ejecuta `FormVariable.ProcesoConsulta`. La única variable del módulo es `VF_ExisteTerminaY` (True = modificar una Y existente).

**Grid0, IDENTIFICACION** (`definegrid`, :291):

| Fila | Concepto | Valor inicial |
|---|---|---|
| 1 | FECHA | `DTPicker1` = `FormVariable.DTPicker1` |
| 2 | LOCAL | `FormVariable.Combo2` |
| 3 | TERMINAL | `FormVariable.Combo3` |
| 4 | N° DE CIERRE DE Y | 0 |
| 5 | HORA | Hora actual `hh:mm` (no editable) |
| 6-9 | SECUENCIA, N° BOLETA, VENDEDOR, CONT. REPOSICION | Vacíos |

- `Grid0_KeyPress` (:1897) acepta solo dígitos, `:` y retroceso. LOCAL y TERMINAL se pueden editar. Cualquier tecla limpia Grid1 y vuelve a habilitar "Validar Identificación".
- Defecto visual: `DTPicker1` tiene posición fija y, como `definegrid1` pone `Grid0.row = 2`, la grilla se desplaza una fila. El picker queda **tapando la fila LOCAL** y la fila FECHA queda oculta.

**Grid1, DETALLE DE MONTOS** (`definegrid1`, :335). Columnas: 0 Concepto, 1 Monto, 2 pop_up (oculta), 3 `vta_cmp_asoc` (oculta), 4 Valor Z, 5 Sumatoria S(Y), 6 Diferencia (Z − S(Y)).

**"Validar Identificación"** (`Command3_Click`, :1595):
1. La fecha debe ser menor que `LeeFechaServidor` ("no se puede generar un Z"). También se valida en `DTPicker1_LostFocus`.
2. `Oklt` (:370): terminal vigente en `vta_<pfx>terminales`. Usa `FormVariable.DTPicker1`, no el picker propio. MAPE/MPAM/SPOR usan `LeeVendedor`.
3. `Est_TermStat(…, "")`: la **Z** (`termstat`) no debe estar en estado 1/2.
4. Obligatorios: N° Y, Hora, Secuencia, Boleta, Vendedor, Cont. Reposición.
5. `FuncValidNumY` (:1691) cuenta `libvta 'Y'` (estado 'A') unida a `zzz` y `termstaty` (`ter_cierrey = vta_secuencia`) para el N° Y.
   - Si existe → **modificación**, se mantiene el número.
   - Si no → **alta**, y el número se **reemplaza** por `FuncBuscaNumSecY` (:1743) = `max(vta_secuencia)+1`. El usuario no puede elegir el número de una Y nueva. Si la consulta falla, devuelve **−1** y se grabaría así.
   - Una Y en `libvta` sin `zzz` o sin `termstaty` no cuenta como existente.
6. Llena Grid1 (`SubDefineDetalleMonto`), habilita Aceptar y deshabilita Validar.

**Origen de los valores** (`SubDefineDetalleMonto`, :969). Una fila de Grid1 por fila de `vta_paint_z` del país, en orden `vta_order_z`:
- pop_up 1/2 (título/separador): Monto en blanco.
- pop_up 0/3:
  - **Monto:** si se modifica, `FuncValorDelCampo(campo,'Y',n)` (:1843) = `sum(campo)` de `libvta 'Y'` + `zzz` + `termstaty` con secuencia n. Si es alta, 0.
  - **Valor Z:** `FuncBuscaValorCampo(campo,'F8')` (:1789) = `sum(campo)` de `libvta 'F8'` + `zzz` + `termstat`. Da 0 si la Z no está cargada.
  - **Σ Y:** en modificación, las otras Y (`termstaty`, secuencia ≠ n). En alta, todas las Y del día unidas a `termstat` de la Z, que debe existir.
  - **Diferencia** = Z − (ΣY + Monto). Solo informativa.
- Colores: pop_up 1 beige (`&HD0EDFB`), pop_up 3 verde (`&HA4E8CB`).

**Edición** (`Grid1_KeyPress`, :1928). Solo la columna 1 de filas con pop_up 0. Acepta dígitos, una coma decimal, retroceso y `-` (cambia el signo). Recalcula la diferencia de la fila editada. Totales por posición fija:
- FACO: fila 5 (TOTALES) = 2+3+4; fila 29 = 30..34.
- SFCL: fila 7 = 2..6.
- La diferencia de una fila total no se recalcula cuando el total cambia.

**Aceptar** (`Command1_Click`, :1430):
1. `revisa_grid`: los vacíos pasan a 0.
2. Repite `Oklt`, `Est_TermStat` de la Z y los obligatorios.
3. `Est_TermStat(…, N°Y)`: la **Y** (`termstaty` + `ter_cierrey`) no debe estar cerrada.
4. **Solo ARG valida cuadratura** (venta contra formas de pago, y tarjeta contra administradoras). **En FACO y SFCL no hay ninguna validación de cuadratura**, ni documentos contra formas de pago ni Z = ΣY.
5. Confirmación "¿Esta seguro de Incorporar el Nuevo cierre de y para este Terminal?" → `GrabaZZZ`.

**Grabado** (`GrabaZZZ`, :452). Sin transacción y sin mensaje de éxito; al terminar se cierra el formulario.
1. `LeeZactual` (:419): `bolinicial`, `nrollo` y `crepo_inicial` de la Y n (0 si es nueva). `qbol = N°Boleta − boli + 1`.
2. Techkey `SEQ_VTA_<pfx>TEC.nextval` (:540).
3. `delete vta_<pfx>libvta where … tiporeg='Y' and secuencia=n` (:568). **No borra la `zzz` vieja** (queda huérfana) y no toca `termstaty`.
4. `insert vta_<pfx>libvta` (:628), una rama por país:
   - **FACO** (`Else`, :910): `montobol` = fila 2, `montofac` = 4, `montoncr` = 3, `totalvta` = 5; `estado 'A'`, `tipof8 'N'`, `hora` = HHMM.
   - **SFCL** (:865): igual, más `totalvta` = 7, `mmontondb` = 5, `montoguia` = 6.
   - **Columnas corridas en ambas ramas:**

     | Columna de `libvta` | Recibe |
     |---|---|
     | `bolfinal` | SECUENCIA |
     | `crepo_inicial` / `crepo_final` | VENDEDOR |
     | `secuencia_srx` | SECUENCIA (en SFCL, la HORA) |
     | `vendedor` | N° BOLETA |

     **CONT. REPOSICION no se graba nunca.**
5. `insert vta_<pfx>zzz` con `arma_query_rec` (:229): `rec_techkey`, `rec_fechaproceso` y las columnas `cmp_asoc` de las filas pop_up 0/3 (sin `VTA_`, o con `MVTA_`). En FACO hay antes un `delete zzz` del techkey nuevo, que no tiene efecto.
6. Si `termstaty` no existe (`FuncExisteEst_TermStatY`): `insert termstaty (…, n, -1, 'INGRESO MANUAL POR CIERRE DE Y', LOGINUSER)`.
7. No toca `termstat` (Z), `estatus`, el validador ZZZ ni el cierre automático de FACO.

**Implicancias para la carga masiva:**
- Por cada Y hay que repetir: borrar `libvta` 'Y' n, insertar `libvta`, insertar `zzz` e insertar `termstaty` con −1 si falta. Conviene además borrar la `zzz` vieja y no copiar el corrimiento de columnas.
- Si el Excel no trae el N° de Y (template FACO), se asigna max+1 como hace el formulario.
- La cuadratura que pide el requerimiento no existe hoy para FACO ni SFCL: hay que construirla.
- Para que la Y se vea en la F8 debe quedar unida a `zzz` y `termstaty`, y la Z debe tener `termstat`.

### 4.5 Validaciones actuales

- La fecha debe ser menor que la del servidor (`LeeFechaServidor`).
- El local y el terminal deben existir y estar vigentes en `vta_<pfx>terminales` (`Oklt`).
- El terminal no debe estar cerrado: `Est_TermStat` (`Modulo2.bas:1347`) bloquea los estados 1 y 2 y muestra un MsgBox. Para una carga masiva conviene una variante sin MsgBox.
- Son obligatorios Hora, Secuencia, N° Boleta, Vendedor y Cont. Reposición.
- **Cuadratura**: la calcula `FuncMontoValidaZZZ` con los grupos `vta_paint_z.vta_validadorzzz` 1..7 y su signo (1 venta, 2 recaudación, 3 recaudación 3, 4 otras operaciones, 5 envío de dineros, 6 activación gift card, 7 formas de pago).
  - Se bloquea al **cerrar** el terminal (Form3 :3647, opción de perfil 103).
  - Solo Argentina bloquea antes de grabar.
- No existe validación de período cerrado.

### 4.6 LVTA

La Z es la fila `vta_<pfx>libvta` con `tiporeg='F8'` y `vta_secuencia=99`, en la misma tabla que las filas `LV` del libro. `Form33.DetalleBoletas` compara ambas. Si se graba libvta y zzz igual que Form19/Form19Y, se cumple el criterio "reflejarse en el LVTA".

### 4.7 Patrones reutilizables para la carga Excel

| Patrón | Formulario |
|---|---|
| `Workbooks.Open`, última fila con `End(xlUp)`, mapeo por columna, borrar e insertar | `Form171` (carga masiva de compensaciones) |
| Preview en grilla, filas inválidas en rojo, botón Grabar deshabilitado | `Form133` |
| Validar todo antes de grabar; compensación manual si falla | `Form81` |
| Nombre de archivo y usuario en cada registro | `Form155` |

### 4.8 Log de auditoría

- `InsertaLogSistema` (`LogSistemaF8.bas`) **no se llama en ningún lado**. El próximo ID de módulo libre es el 71.
- No existe log de cargas masivas.
- Modelos para el log nuevo:
  - `VTA_LOG_ING_ZLV` (`Form19_2` :628): usuario, sysdate, acción y documento.
  - `VTA_FACOLOG_CIERRE_AUTO` (`docs/sql/FSCC-12958/02_log.sql`): una ejecución, N filas y un resultado por fila.

## 5. Decisiones de diseño (propuestas, sin confirmar)

- Formulario nuevo (por ejemplo `Form174`), agregado a `recaudacion.vbp`, con el flujo: elegir archivo → preview → validar todo → grabar las filas válidas → log.
- Mapear las columnas del Excel contra `vta_paint_z` del país, por posición del encabezado o por `vta_cmp_asoc` y no por glosa, porque hay glosas duplicadas.
- Grabar con la misma secuencia de sentencias que Form19/Form19Y, para que el cierre sea igual al manual. Corregir en la carga los defectos conocidos: zzz huérfanas y columnas corridas.
- Log en una tabla nueva por ejecución y fila (estilo `VTA_FACOLOG_CIERRE_AUTO`), en todos los prefijos en alcance (`""`, SFCL, FACO).

## 6. Hechos verificados en la base de test

Pendiente: correr `docs/sql/FCDVT-14/00_prechecks.sql`. Referencia previa (FSCC-12901): `VTA_PAINT_Z` de FACO tiene 53 filas en test, 47 campos, signo siempre `+`, grupos ZZZ 1, 2, 3, 6 y 7.

## 7. Preguntas abiertas para negocio

1. **UPDATE**: ¿se conservan Hora, Secuencia, Boleta, Vendedor y Cont. Reposición de la Z existente? En SFCL/FACO, ¿un update de la Z debe **conservar las Y**? Hoy Form19 las borra.
2. **Terminal cerrado** (estado 1/2): ¿se rechaza la fila, o se permite con un perfil especial reabriendo el terminal?
3. **Descuadratura**: ¿qué fórmula se usa, la de grupos ZZZ o la de venta total contra formas de pago? ¿Se rechaza solo la fila o el archivo completo?
4. **Y (SFCL/FACO)**: ¿el N° de Y viene en el Excel o se asigna como max+1? ¿Se valida Z = ΣY?
5. **SFCL**: ¿cargar una Z debe seguir creando la Y1 automática?
6. **Template**: ¿hay un formato oficial por país con encabezados exactos? ¿Qué pasa con las glosas repetidas y con las celdas `-`?
7. **Log**: ¿tabla en la base o archivo? ¿Qué campos? ¿Hace falta la pantalla de reporte de auditoría?
8. **Permisos**: ¿qué perfiles usan la carga?
9. **Falabella Chile**: ¿hay que validar la recaudación contra LV (`VerificaCuadraturaREC`) como hace Form19?

## 8. Cómo retomar

1. Correr `docs/sql/FCDVT-14/00_prechecks.sql` en test (VPN Fortinet; ver `README_FSCC-12901.md` §8) y anotar los resultados en §6.
2. Comparar las columnas del template con `vta_paint_z` de cada empresa (consultas 1 a 4 de los prechecks).
3. Con las respuestas de §7, escribir el diseño detallado (`docs/FCDVT-14_Analisis.md`) y los scripts de log (`docs/sql/FCDVT-14/01..`, `99_rollback.sql`).
4. Antes de tocar `.frm`: respaldo `.bak_FCDVT-14` y edición binaria (Windows-1252 + CRLF).

## 9. Historial

| Fecha | Hito |
|---|---|
| 16-10-2026 | Recepción del DF-SCC. Análisis del requerimiento y del flujo actual de Z/Y (Form19, Form19Y, cargas Excel, menú, log). README y prechecks creados. |
| 16-10-2026 | Análisis detallado de `Form19Y.frm` (ingreso de Y) agregado en §4.4: validaciones, origen de los valores, grabado y defectos (columnas corridas, CONT. REPOSICION no se graba, zzz huérfana, número −1 si falla max+1). |
| 16-10-2026 | Primera tarea acotada: **carga masiva de inserción de Y para FACO**. Se diseña el CSV (`docs/FCDVT-14/`). Las columnas salen de `vta_paint_z` FACO leída en desarrollo (47 filas); 5 conceptos del template quedan por confirmar en test. Sin cambios en formularios ni en la base. |
| 19-10-2026 | `CLAUDE.md` §9 incluye FCDVT-14 entre los requerimientos vigentes (estado: en análisis). Sin otros cambios. |
